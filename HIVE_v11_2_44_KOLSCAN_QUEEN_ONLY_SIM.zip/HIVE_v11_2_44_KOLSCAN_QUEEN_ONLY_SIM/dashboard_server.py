#!/usr/bin/env python3
from __future__ import annotations
import json, csv, time, os
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

PORT = int(os.environ.get('UCF_DASHBOARD_PORT', '8765'))
ROOT = Path('.').resolve()

def read_json(path, default):
    try:
        p=ROOT/path
        if p.exists(): return json.loads(p.read_text(encoding='utf-8'))
    except Exception: pass
    return default

def read_tail(path, n=200):
    p=ROOT/path
    if not p.exists(): return []
    try:
        # Efficient tail for huge JSONL logs. Read from the end in chunks until enough lines are found.
        n = int(n)
        chunk = 65536
        data = b''
        with p.open('rb') as f:
            f.seek(0, os.SEEK_END)
            pos = f.tell()
            while pos > 0 and data.count(b'\n') <= n:
                step = min(chunk, pos)
                pos -= step
                f.seek(pos)
                data = f.read(step) + data
        text = data.decode('utf-8', errors='ignore')
        lines = [ln for ln in text.splitlines() if ln.strip()][-n:]
        out=[]
        for line in lines:
            try: out.append(json.loads(line))
            except Exception: out.append({'raw':line})
        return out
    except Exception: return []

def derived_hive_report(qwg):
    queens = {}
    workers = {}
    states = (qwg or {}).get('mints', {}) if isinstance(qwg, dict) else {}
    for mint, h in states.items():
        if not isinstance(h, dict):
            continue
        for w in h.get('queen_wallets') or []:
            r = queens.setdefault(w, {'wallet': w, 'role': 'queen_live_exit', 'trap_hits': 0, 'queen_sell_sol': 0.0, 'mints': 0})
            r['mints'] += 1
            r['queen_sell_sol'] += float(h.get('queen_sell_sol') or 0)
        # In fresh runs many profitable workers are still role=watch; surface them as live soft workers.
        source_wallets = list(h.get('worker_wallets') or [])
        if not source_wallets and h.get('soft_worker_buys', 0):
            source_wallets = list(h.get('watch_wallets') or [])
        if h.get('hive_state') in ('worker_entry','worker_swarm','watch_surge'):
            for w in source_wallets:
                r = workers.setdefault(w, {'wallet': w, 'role': 'worker_live_accumulator', 'runner_hits': 0, 'buy_sol': 0.0, 'mints': 0})
                r['mints'] += 1
                r['runner_hits'] += 1 if float(h.get('net_hive_sol') or 0) > 0 else 0
                r['buy_sol'] += float(h.get('worker_buy_sol') or h.get('watch_buy_sol') or 0)
    q = sorted(queens.values(), key=lambda x: (x.get('queen_sell_sol',0), x.get('mints',0)), reverse=True)
    w = sorted(workers.values(), key=lambda x: (x.get('buy_sol',0), x.get('runner_hits',0)), reverse=True)
    return q[:25], w[:25]

def read_trades():
    """Read trades from both the new fee-aware schema and older corrupted HIVE schemas."""
    p=ROOT/'wallet_predator_trades.csv'
    if not p.exists(): return []
    intended=['ts','side','mint','setup','sol','mc','gross_pnl_sol','estimated_cost_sol','pnl_sol','gross_pnl_pct','net_pnl_pct','reason','score','sig_or_error']
    old11=['ts','side','mint','setup','sol','mc','pnl_sol','pnl_pct','reason','score','sig_or_error']
    out=[]
    try:
        import csv as _csv
        with p.open(newline='',encoding='utf-8',errors='ignore') as f:
            rr=_csv.reader(f)
            hdr=next(rr, [])
            for row in rr:
                if not row: continue
                if hdr == intended and len(row) >= len(intended):
                    d=dict(zip(intended,row))
                elif len(row) >= 11:
                    # Older builds had a 7-column header but appended 11 fields.
                    d=dict(zip(old11,row[:11]))
                    gross=_num(d.get('pnl_sol'))
                    cost=_estimate_trade_cost(d.get('sol')) if 'SELL' in str(d.get('side','')) else 0.0
                    d['gross_pnl_sol']=str(gross)
                    d['gross_pnl_pct']=d.get('pnl_pct','0')
                    d['estimated_cost_sol']=str(cost)
                    d['pnl_sol']=str(gross-cost)
                    sold=max(1e-12,_num(d.get('sol')))
                    d['net_pnl_pct']=str((gross-cost)/sold)
                else:
                    d=dict(zip(hdr,row))
                out.append(d)
        return out[-300:]
    except Exception:
        return []

def _num(x, default=0.0):
    try:
        if x is None or x=='': return default
        return float(x)
    except Exception:
        return default

def _estimate_trade_cost(sol):
    cfg=read_json(Path('config.json'), {})
    bps=_num(cfg.get('ESTIMATED_ROUND_TRIP_COST_BPS'), 350.0)
    fixed=_num(cfg.get('ESTIMATED_ROUND_TRIP_FIXED_SOL'), _num(cfg.get('PRIORITY_FEE_SOL'), 0.0006)*2.0)
    return max(0.0, _num(sol))*(bps/10000.0)+fixed



def active_positions_view():
    """Return open positions with full mint CAs and copy-friendly fields for the dashboard."""
    cfg = read_json(Path('config.json'), {})
    pos = read_json(Path(cfg.get('POSITIONS_FILE', 'wallet_predator_positions.json')), {}) or {}
    now = int(time.time())
    rows = []
    if isinstance(pos, dict):
        for mint, row in pos.items():
            if not isinstance(row, dict):
                row = {}
            entry_ts = int(_num(row.get('entry_ts') or row.get('ts'), 0))
            entry_mc = _num(row.get('entry_mc'), 0.0)
            last_mc = _num(row.get('last_mc') or row.get('current_mc'), entry_mc)
            high_mc = _num(row.get('high_mc'), max(entry_mc, last_mc))
            pnl_pct = ((last_mc / entry_mc) - 1.0) if entry_mc > 0 and last_mc > 0 else 0.0
            high_pct = ((high_mc / entry_mc) - 1.0) if entry_mc > 0 and high_mc > 0 else 0.0
            rows.append({
                'mint': row.get('mint') or mint,
                'setup': row.get('setup') or '',
                'entry_ts': entry_ts,
                'hold_time_sec': max(0, now - entry_ts) if entry_ts else 0,
                'entry_mc': entry_mc,
                'last_mc': last_mc,
                'high_mc': high_mc,
                'pnl_pct': round(pnl_pct, 6),
                'high_pct': round(high_pct, 6),
                'sol': _num(row.get('sol'), 0.0),
                'remaining_pct': _num(row.get('remaining_pct'), 1.0),
                'score': _num(row.get('score'), 0.0),
                'reason': row.get('reason') or '',
                'sig': row.get('sig') or row.get('buy_sig') or '',
                'pending_live_sell': bool(row.get('pending_live_sell')),
                'wallet_summary': row.get('wallet_summary') or {},
            })
    rows.sort(key=lambda x: x.get('entry_ts') or 0, reverse=True)
    return rows


def _wallet_add(rows, wallet, source, role='', score=0.0, win_rate=None, pnl_edge=None, samples=0, mints=0, notes=''):
    wallet = str(wallet or '').strip()
    if not wallet:
        return
    d = rows.setdefault(wallet, {
        'wallet': wallet,
        'sources': [],
        'roles': set(),
        'score': 0.0,
        'win_rate': None,
        'pnl_edge_pct': None,
        'samples': 0,
        'mints': 0,
        'notes': [],
        'last_seen_ts': 0,
        'last_seen_age_sec': None,
        'recent_buy_count': 0,
    })
    if source and source not in d['sources']:
        d['sources'].append(source)
    if role:
        d['roles'].add(str(role))
    d['score'] += _num(score, 0.0)
    if win_rate is not None:
        d['win_rate'] = max(_num(d['win_rate'], 0.0), _num(win_rate, 0.0)) if d['win_rate'] is not None else _num(win_rate, 0.0)
    if pnl_edge is not None:
        d['pnl_edge_pct'] = max(_num(d['pnl_edge_pct'], -999.0), _num(pnl_edge, 0.0)) if d['pnl_edge_pct'] is not None else _num(pnl_edge, 0.0)
    d['samples'] += int(_num(samples, 0))
    d['mints'] += int(_num(mints, 0))
    if notes:
        d['notes'].append(str(notes))


def most_profitable_wallets(limit=50):
    """Rank the best recorded wallets from mined copy-buy, worker, and profile files.

    The bot does not always store realized wallet-level PnL for external wallets, so this
    combines the strongest available profitability evidence: copy-buy win rate/edge,
    positive cycle net SOL, worker accumulator score, and alpha/watch profile score.
    Dump-risk, sell-near-high, and exit-warning wallets are excluded from the positive list.
    """
    swarm = read_json(Path('swarm_edge_profiles.json'), {}) or {}
    queen = read_json(Path('queen_hive_report.json'), {}) or {}
    profiles = read_json(Path('wallet_predator_profiles.json'), {}) or {}
    rows = {}
    bad_roles = {'dump_risk', 'sell_near_high', 'exit_warning_wallet', 'queen_live_exit'}

    for w in swarm.get('copy_buy_wallets') or []:
        if not isinstance(w, dict):
            continue
        wr = _num(w.get('win_rate'), 0.0)
        edge = _num(w.get('fee_adjusted_edge_pct'), _num(w.get('avg_first_touch_return_pct'), 0.0))
        samples = int(_num(w.get('samples'), 0))
        mints = int(_num(w.get('mints'), 0))
        score = 100.0 * wr + 250.0 * edge + min(50.0, samples * 2.0) + min(25.0, mints * 3.0)
        _wallet_add(rows, w.get('wallet'), 'swarm_edge_profiles.copy_buy_wallets', w.get('role') or 'copy_buy_edge', score, wr, edge, samples, mints, 'mined copy-buy wallet')
        rr = rows.get(str(w.get('wallet') or '').strip())
        if rr is not None:
            rr['last_seen_ts'] = max(int(_num(rr.get('last_seen_ts'), 0)), int(_num(w.get('last_seen_ts'), 0)))
            rr['last_seen_age_sec'] = w.get('last_seen_age_sec')
            rr['recent_buy_count'] = max(int(_num(rr.get('recent_buy_count'), 0)), int(_num(w.get('recent_buy_count'), 0)))
            if int(_num(w.get('recent_buy_count'), 0)) > 0:
                rr['notes'].append(f"recent_buys={int(_num(w.get('recent_buy_count'),0))} last_age_sec={int(_num(w.get('last_seen_age_sec'),0))}")

    for w in swarm.get('cycle_wallets') or []:
        if not isinstance(w, dict):
            continue
        net = _num(w.get('net_sol'), 0.0)
        if net <= 0:
            continue
        buys = max(1.0, _num(w.get('buy_count'), 0.0))
        sells = _num(w.get('sell_count'), 0.0)
        wr_proxy = min(1.0, max(0.0, buys / max(1.0, buys + sells)))
        edge = net / max(1.0, _num(w.get('buy_sol'), 1.0))
        score = 80.0 + min(100.0, net * 3.0) + min(80.0, edge * 200.0) + min(40.0, _num(w.get('mints'), 0.0))
        _wallet_add(rows, w.get('wallet'), 'swarm_edge_profiles.cycle_wallets', 'positive_cycle_wallet', score, wr_proxy, edge, _num(w.get('buy_count'), 0), _num(w.get('mints'), 0), f'positive net_sol={net:.4f}')
        rr = rows.get(str(w.get('wallet') or '').strip())
        if rr is not None:
            rr['last_seen_ts'] = max(int(_num(rr.get('last_seen_ts'), 0)), int(_num(w.get('last_seen_ts'), 0)))
            rr['last_seen_age_sec'] = w.get('last_seen_age_sec')
            rr['recent_buy_count'] = max(int(_num(rr.get('recent_buy_count'), 0)), int(_num(w.get('recent_buy_count'), 0)))

    for w in queen.get('worker_accumulators') or []:
        if not isinstance(w, dict):
            continue
        role = str(w.get('role') or 'worker_accumulator')
        if role in bad_roles:
            continue
        worker_score = _num(w.get('worker_score'), _num(w.get('score'), 0.0))
        buy_sol = _num(w.get('worker_buy_sol'), _num(w.get('buy_sol'), 0.0))
        runs = _num(w.get('runner_hits'), 0.0)
        if worker_score < 0 and runs <= 0:
            continue
        score = max(0.0, worker_score) + min(80.0, buy_sol) + min(60.0, runs * 2.0)
        _wallet_add(rows, w.get('wallet'), 'queen_hive_report.worker_accumulators', role, score, None, None, runs, w.get('seen_mints') or w.get('mints') or 0, 'worker accumulator')

    for w in profiles.get('top_wallets') or []:
        if not isinstance(w, dict):
            continue
        role = str(w.get('role') or '')
        if role in bad_roles:
            continue
        score0 = _num(w.get('score'), 0.0)
        worker_score = _num(w.get('worker_score'), 0.0)
        runs = _num(w.get('runner_hits'), 0.0)
        if role not in ('alpha', 'flipper', 'watch', 'worker_accumulator', 'copy_buy_edge') and worker_score <= 0:
            continue
        score = max(0.0, score0) + max(0.0, worker_score) + min(60.0, runs * 1.5)
        _wallet_add(rows, w.get('wallet'), 'wallet_predator_profiles.top_wallets', role or 'profile_positive', score, None, None, runs, w.get('seen_mints') or 0, 'positive profile role')

    out = []
    for d in rows.values():
        role_list = sorted(d.pop('roles'))
        d['roles'] = role_list
        # A final normalized rank that rewards multiple independent sources plus fresh SIM evidence.
        recency_bonus = min(35.0, int(_num(d.get('recent_buy_count'), 0)) * 7.0)
        if d.get('last_seen_age_sec') is not None and _num(d.get('last_seen_age_sec'), 999999) <= 900:
            recency_bonus += 15.0
        d['rank_score'] = round(_num(d.get('score'), 0.0) + 35.0 * max(0, len(d.get('sources') or []) - 1) + recency_bonus, 6)
        d['win_rate'] = None if d.get('win_rate') is None else round(_num(d.get('win_rate'), 0.0), 6)
        d['pnl_edge_pct'] = None if d.get('pnl_edge_pct') is None else round(_num(d.get('pnl_edge_pct'), 0.0), 6)
        d['roles_text'] = ', '.join(role_list)
        d['sources_text'] = ', '.join(d.get('sources') or [])
        d['notes_text'] = '; '.join(d.get('notes') or [])
        out.append(d)
    out.sort(key=lambda x: (x.get('rank_score') or 0, x.get('win_rate') or 0, x.get('samples') or 0, x.get('mints') or 0), reverse=True)
    return out[:int(limit)]


def profitable_wallets_text(limit=50):
    rows = most_profitable_wallets(limit)
    swarm = read_json(Path('swarm_edge_profiles.json'), {}) or {}
    calls = (swarm.get('recent_copy_call_candidates') or [])[:25] if isinstance(swarm, dict) else []
    ts = int(time.time())
    lines = [
        f'THE HIVE - MOST PROFITABLE RECORDED WALLETS',
        f'generated_ts={ts}',
        '',
        'Rank | Wallet | RankScore | WinRate | EdgePct | Samples | Mints | RecentBuys | LastSeenAgeSec | Roles | Sources | Notes',
        '-' * 160,
    ]
    for i, w in enumerate(rows, 1):
        wr = '' if w.get('win_rate') is None else f"{w.get('win_rate')*100:.1f}%"
        edge = '' if w.get('pnl_edge_pct') is None else f"{w.get('pnl_edge_pct')*100:.2f}%"
        last_age = '' if w.get('last_seen_age_sec') is None else str(int(_num(w.get('last_seen_age_sec'), 0)))
        lines.append(f"{i:02d} | {w.get('wallet','')} | {w.get('rank_score',0):.2f} | {wr} | {edge} | {w.get('samples',0)} | {w.get('mints',0)} | {w.get('recent_buy_count',0)} | {last_age} | {w.get('roles_text','')} | {w.get('sources_text','')} | {w.get('notes_text','')}")
    lines.extend(['', 'SIM BEST RECENT COPY/WATCH CALLS', 'Call | Wallet | Mint | Score | AgeSec | WR | Edge | Samples | Reason', '-' * 160])
    for c in calls:
        lines.append(f"{c.get('call_type','')} | {c.get('wallet','')} | {c.get('mint','')} | {_num(c.get('call_score'),0.0):.2f} | {int(_num(c.get('age_from_latest_sec'),0))} | {_num(c.get('profile_win_rate'),0.0)*100:.1f}% | {_num(c.get('profile_fee_edge_pct'),0.0)*100:.2f}% | {int(_num(c.get('profile_samples'),0))} | {c.get('reason','')}")
    return '\n'.join(lines) + '\n'


def write_profitable_wallets_file() -> None:
    try:
        (ROOT / 'MOST_PROFITABLE_WALLETS.txt').write_text(profitable_wallets_text(75), encoding='utf-8')
    except Exception as e:
        try:
            (ROOT / 'profitable_wallet_export_errors.jsonl').open('a', encoding='utf-8').write(json.dumps({'ts': int(time.time()), 'error': str(e)}) + '\n')
        except Exception:
            pass


def hot_sim_plays_view():
    cfg = read_json(Path('config.json'), {})
    hot_file = Path(cfg.get('HOT_SIM_PLAYS_FILE', 'HOT_SIM_PLAYS.json'))
    hot = read_json(hot_file, {}) or {}
    # If dashboard starts before the miner wrote the file, or the WSS tape changed
    # after the file was written, compute once from the current SIM tape.
    try:
        events_file = Path(cfg.get('LIVE_WALLET_EVENTS_FILE', 'live_wallet_events.jsonl'))
        stale = False
        if not hot:
            stale = True
        elif events_file.exists() and hot_file.exists() and events_file.stat().st_mtime > hot_file.stat().st_mtime + 2:
            stale = True
        if stale:
            from live_money_flow_ranker import write_hot_sim_plays
            hot = write_hot_sim_plays(cfg)
    except Exception as e:
        hot = {'ts': int(time.time()), 'hot_plays': [], 'recent_profit_wallets': [], 'error': str(e)}
    return hot


def win_rate_optimizer_view():
    cfg = read_json(Path('config.json'), {})
    path = Path(cfg.get('WIN_RATE_OPTIMIZER_FILE', 'WIN_RATE_OPTIMIZER_REPORT.json'))
    report = read_json(path, {}) or {}
    if not report:
        try:
            from live_money_flow_ranker import write_hot_sim_plays
            hot = write_hot_sim_plays(cfg)
            report = hot.get('win_rate_optimizer') or {}
        except Exception as e:
            report = {'ts': int(time.time()), 'error': str(e)}
    return report


def _file_health_row(name, optional=False, json_ok_empty=True):
    name = str(name or '').strip()
    now = time.time()
    p = ROOT / name
    if not name:
        return {'file': name, 'exists': False, 'bytes': 0, 'age_sec': None, 'populating': False, 'optional': optional, 'status': 'not_configured'}
    if not p.exists():
        return {'file': name, 'exists': False, 'bytes': 0, 'age_sec': None, 'populating': False, 'optional': optional, 'status': 'waiting' if optional else 'missing'}
    size = p.stat().st_size
    suffix = p.suffix.lower()
    populating = size > 0 if suffix in ('.jsonl', '.csv', '.txt') else size > 2
    if json_ok_empty and suffix == '.json' and size >= 2:
        populating = True
    return {'file': name, 'exists': True, 'bytes': size, 'age_sec': int(now - p.stat().st_mtime), 'populating': bool(populating), 'optional': optional, 'status': 'ok' if populating else 'empty'}


def hive_ai_view():
    cfg = read_json(Path('config.json'), {})
    scores_file = cfg.get('HIVE_AI_SCORES_FILE', 'hive_ai_scores.json')
    scores = read_json(Path(scores_file), {}) or {}
    grades = read_tail(Path('hive_ai_trade_grades.jsonl'), 120)
    blocks = read_tail(Path('hive_ai_blocks.jsonl'), 120)
    auto_runs = read_tail(Path('hive_ai_auto_runs.jsonl'), 80)
    recent_grades = []
    for g in grades[-80:]:
        if not isinstance(g, dict):
            continue
        recent_grades.append({
            'ts': g.get('ts'),
            'mint': g.get('mint'),
            'setup': g.get('setup'),
            'grade': g.get('grade'),
            'entry_score': g.get('entry_score'),
            'danger_score': g.get('danger_score'),
            'runner_score': g.get('runner_score'),
            'flags': g.get('flags') or [],
        })
    recent_blocks = []
    for b in blocks[-80:]:
        if not isinstance(b, dict):
            continue
        recent_blocks.append({
            'ts': b.get('ts'),
            'mint': b.get('mint'),
            'setup': b.get('setup'),
            'reason': b.get('reason'),
            'grade': ((b.get('ai') or {}).get('grade') if isinstance(b.get('ai'), dict) else None),
            'danger_score': ((b.get('ai') or {}).get('danger_score') if isinstance(b.get('ai'), dict) else None),
            'flags': ((b.get('ai') or {}).get('flags') if isinstance(b.get('ai'), dict) else []),
        })
    return {
        'ts': int(time.time()),
        'enabled': bool(cfg.get('HIVE_AI_ENABLED', True)),
        'can_enter': bool(cfg.get('AI_CAN_ENTER_TRADES', False)),
        'can_block': bool(cfg.get('AI_CAN_BLOCK_TRADES', True)),
        'can_rank': bool(cfg.get('AI_CAN_RANK_TRADES', True)),
        'soft_override': bool(cfg.get('HIVE_AI_ALLOW_SOFT_OVERRIDE', False)),
        'require_ab_grade': bool(cfg.get('HIVE_AI_REQUIRE_AB_GRADE', True)),
        'allowed_setups': cfg.get('HIVE_AI_ALLOWED_SETUPS', ''),
        'blocked_setups': cfg.get('HIVE_AI_BLOCKED_SETUPS', ''),
        'scores_file': scores_file,
        'scores': scores,
        'recent_grades': recent_grades,
        'recent_blocks': recent_blocks,
        'auto_runs': auto_runs,
        'file_health': [
            _file_health_row(scores_file, optional=True),
            _file_health_row('hive_ai_trade_grades.jsonl', optional=True),
            _file_health_row('hive_ai_blocks.jsonl', optional=True),
            _file_health_row('hive_ai_auto_runs.jsonl', optional=True),
        ]
    }


def output_file_health():
    cfg = read_json(Path('config.json'), {})
    required = [
        cfg.get('HOT_SIM_PLAYS_FILE','HOT_SIM_PLAYS.json'),
        cfg.get('RECENT_PROFIT_WALLETS_FILE','RECENT_PROFIT_WALLETS.json'),
        cfg.get('WIN_RATE_OPTIMIZER_FILE','WIN_RATE_OPTIMIZER_REPORT.json'),
        cfg.get('TRADES_FILE','wallet_predator_trades.csv'),
        cfg.get('POSITIONS_FILE','wallet_predator_positions.json'),
        cfg.get('HIVE_AI_SCORES_FILE','hive_ai_scores.json'),
    ]
    optional = [
        cfg.get('RECENT_COPY_CALL_FILE','SIM_BEST_COPY_CALLS.json'),
        'MOST_PROFITABLE_WALLETS.txt',
        cfg.get('SWARM_EDGE_PROFILE_FILE','swarm_edge_profiles.json'),
        cfg.get('PROFILE_EXPORT_FILE','wallet_predator_profiles.json'),
        cfg.get('QUEEN_WORKER_GRAPH_FILE','queen_worker_graph_state.json'),
        'position_lifecycle.jsonl',
        'wallet_predator_decisions.jsonl',
        'live_wallet_events.jsonl',
        cfg.get('BUY_SELL_ONLY_JSONL','buy_sell_only.jsonl'),
        cfg.get('BUY_SELL_ONLY_CSV','buy_sell_only.csv'),
        'hive_ai_trade_grades.jsonl',
        'hive_ai_blocks.jsonl',
        'hive_ai_auto_runs.jsonl',
        'runtime_errors.jsonl',
        'strict_edge_blocks.jsonl',
        'early_creation_snipe_candidates.jsonl',
        'strict_edge_exit_events.jsonl',
        'force_max_hold_exits.jsonl',
        cfg.get('CREATOR_HISTORY_FILE', 'creator_history.json'),
        cfg.get('CREATOR_FUNDING_GRAPH_FILE', 'funding_graph.json'),
        cfg.get('PENDING_TOKEN_WATCH_FILE', 'pending_token_watch.json'),
    ]
    seen=set(); rows=[]
    for name in required:
        if name and name not in seen:
            rows.append(_file_health_row(name, optional=False)); seen.add(name)
    for name in optional:
        if name and name not in seen:
            rows.append(_file_health_row(name, optional=True)); seen.add(name)
    return rows


def engine_status_view():
    """Freshness/readiness view so the dashboard cannot hide a dead engine."""
    now = int(time.time())
    cfg = read_json(Path('config.json'), {})
    def age_for(path):
        p = ROOT / str(path)
        if not p.exists() or p.stat().st_size <= 0:
            return None
        return int(now - p.stat().st_mtime)
    events = read_tail(Path(cfg.get('LIVE_WALLET_EVENTS_FILE', 'live_wallet_events.jsonl')), 200)
    decisions = read_tail(Path('wallet_predator_decisions.jsonl'), 200)
    trades = read_trades()
    runtime = read_tail(Path('runtime_errors.jsonl'), 50)
    last_event = next((e for e in reversed(events) if isinstance(e, dict)), {})
    last_decision = next((d for d in reversed(decisions) if isinstance(d, dict)), {})
    last_trade = next((t for t in reversed(trades) if isinstance(t, dict)), {})
    approvals = [d for d in decisions if isinstance(d, dict) and d.get('approved')]
    blocks = [d for d in decisions if isinstance(d, dict) and not d.get('approved')]
    event_age = age_for(cfg.get('LIVE_WALLET_EVENTS_FILE', 'live_wallet_events.jsonl'))
    decision_age = age_for('wallet_predator_decisions.jsonl')
    trade_age = age_for(cfg.get('TRADES_FILE','wallet_predator_trades.csv'))
    engine_fresh = (event_age is not None and event_age <= 30) or (decision_age is not None and decision_age <= 30)
    return {
        'ts': now,
        'bot_build': cfg.get('BOT_BUILD') or cfg.get('bot_build') or 'unknown',
        'profile': cfg.get('TRADING_PROFILE', ''),
        'strict_edge_mode': bool(cfg.get('STRICT_EDGE_MODE', False)),
        'engine_fresh': bool(engine_fresh),
        'status': 'ENGINE FEED ONLINE' if engine_fresh else 'DASHBOARD ONLINE / ENGINE STALE OR OFF',
        'live_events_age_sec': event_age,
        'decisions_age_sec': decision_age,
        'trades_age_sec': trade_age,
        'recent_event_count': len(events),
        'recent_decision_count': len(decisions),
        'recent_approvals': len(approvals),
        'recent_blocks': len(blocks),
        'last_event': last_event,
        'last_decision': last_decision,
        'last_trade': last_trade,
        'last_block_reason': (blocks[-1].get('reason') if blocks else ''),
        'runtime_error_count': len(runtime),
        'runtime_errors': runtime[-10:],
    }

def data_links_view():
    """All dashboard links/endpoints with population status and fallback notes."""
    links = [
        {'label':'Summary API','url':'/api/summary','file':'virtual','producer':'dashboard_server.summary'},
        {'label':'Engine Status','url':'/api/engine_status','file':'live_wallet_events.jsonl / wallet_predator_decisions.jsonl','producer':'main.py trading loop'},
        {'label':'Hot SIM Plays','url':'/api/hot_sim_plays','file':'HOT_SIM_PLAYS.json','producer':'live_money_flow_ranker.write_hot_sim_plays fallback'},
        {'label':'Win-Rate Optimizer','url':'/api/win_rate_optimizer','file':'WIN_RATE_OPTIMIZER_REPORT.json','producer':'win_rate_optimizer.py / live_money_flow_ranker fallback'},
        {'label':'Hive AI','url':'/api/hive_ai','file':'hive_ai_scores.json / hive_ai_trade_grades.jsonl / hive_ai_blocks.jsonl','producer':'hive_ai_sidecar.py + strategy.py'},
        {'label':'Creator Intel','url':'/api/creator_intel','file':'creator_history.json / funding_graph.json','producer':'creator_tracker.py / funding_graph_builder.py / WSS fallback from new_token_events.jsonl'},
        {'label':'Follow Money','url':'/api/follow_money','file':'FOLLOW_MONEY_GRAPH.json / FOLLOW_MONEY_WATCHLIST.json','producer':'follow_money_graph.py'},
        {'label':'Profitable Wallets JSON','url':'/api/profitable_wallets','file':'MOST_PROFITABLE_WALLETS.txt','producer':'dashboard export function'},
        {'label':'Profitable Wallets TXT','url':'/profitable_wallets.txt','file':'MOST_PROFITABLE_WALLETS.txt','producer':'dashboard export function'},
        {'label':'Output File Health','url':'/api/output_file_health','file':'multiple','producer':'dashboard_server.output_file_health'},
    ]
    health = {r.get('file'): r for r in output_file_health()}
    for link in links:
        f = link.get('file','')
        row = health.get(f) if f in health else None
        link['status'] = (row or {}).get('status', 'virtual' if f in ('virtual','multiple') or '/' in f else 'check')
        link['bytes'] = (row or {}).get('bytes')
        link['age_sec'] = (row or {}).get('age_sec')
    return {'ts': int(time.time()), 'links': links, 'file_health': output_file_health()}

def summary():
    cfg = read_json(Path('config.json'), {})
    intel=read_json(Path('ucf_upgrade_intel.json'), {})
    perf=read_json(Path('performance_intel.json'), {})
    pos=read_json(Path(cfg.get('POSITIONS_FILE','wallet_predator_positions.json')), {})
    profiles=read_json(Path('wallet_predator_profiles.json'), {})
    swarm_profiles=read_json(Path('swarm_edge_profiles.json'), {})
    queen=read_json(Path('queen_hive_report.json'), {})
    qwg=read_json(Path('queen_worker_graph_state.json'), {})
    fallback_queens, fallback_workers = derived_hive_report(qwg)
    risk=read_json(Path('live_risk_state.json'), {})
    trades=read_trades()
    real_sell_sides={'LIVE_SELL','PAPER_SELL'}
    sells=[t for t in trades if (t.get('side') or '') in real_sell_sides]
    sell_fails=[t for t in trades if 'SELL_FAIL' in (t.get('side') or '')]
    buys=[t for t in trades if (t.get('side') or '') in ('LIVE_BUY','PAPER_BUY')]
    pnl=sum(_num(t.get('pnl_sol')) for t in sells)
    gross_pnl=sum(_num(t.get('gross_pnl_sol'), _num(t.get('pnl_sol'))) for t in sells)
    est_cost=sum(_num(t.get('estimated_cost_sol')) for t in sells)
    wins=sum(1 for t in sells if _num(t.get('pnl_sol'))>0)
    by_setup={}
    for t in sells:
        setup=t.get('setup') or 'unknown'
        d=by_setup.setdefault(setup, {'sells':0,'pnl':0.0,'wins':0})
        d['sells']+=1; d['pnl']+=_num(t.get('pnl_sol')); d['wins']+=1 if _num(t.get('pnl_sol'))>0 else 0
    boot_ts = 0
    try:
        boot_ts = int((intel.get('boot_proof') or {}).get('process_start_ts') or 0)
    except Exception:
        boot_ts = 0
    runtime_errors = read_tail(Path('runtime_errors.jsonl'), 200)
    if boot_ts:
        runtime_errors = [e for e in runtime_errors if int(e.get('ts') or 0) >= boot_ts]
    wallet_balances = read_tail(Path('live_wallet_sol_balance.jsonl'), 500)
    clean_balances = [b for b in wallet_balances if isinstance(b, dict) and b.get('sol_balance') is not None]
    wallet_session_delta = None
    if clean_balances:
        wallet_session_delta = round(_num(clean_balances[-1].get('sol_balance')) - _num(clean_balances[0].get('sol_balance')), 9)
    write_profitable_wallets_file()
    hot_sim = hot_sim_plays_view()
    return {
        'ts': int(time.time()),
        'engine_status': engine_status_view(),
        'data_links': data_links_view(),
        'hot_sim_plays': hot_sim,
        'win_rate_optimizer': win_rate_optimizer_view(),
        'output_file_health': output_file_health(),
        'intel': intel,
        'performance': perf,
        'positions': pos,
        'active_positions': active_positions_view(),
        'profitable_wallets': most_profitable_wallets(50),
        'profitable_wallets_file': 'MOST_PROFITABLE_WALLETS.txt',
        'recent_copy_call_candidates': (swarm_profiles.get('recent_copy_call_candidates') or [])[:80] if isinstance(swarm_profiles, dict) else [],
        'profile_role_counts': profiles.get('role_counts',{}),
        'top_wallets': profiles.get('top_wallets',[])[:25],
        'swarm_edge_profiles': swarm_profiles,
        'swarm_edge_auto_candidates': read_tail(Path('swarm_edge_auto_candidates.jsonl'), 50),
        'swarm_edge_exit_warning_events': read_tail(Path('swarm_edge_exit_warning_events.jsonl'), 50),
        'queen_candidates': (queen.get('queen_candidates') or fallback_queens)[:25],
        'worker_accumulators': (queen.get('worker_accumulators') or fallback_workers)[:25],
        'queen_worker_graph': qwg,
        'live_risk_state': risk,
        'trade_stats': {'buys':len(buys),'sells':len(sells),'sell_fails':len(sell_fails),'pnl_sol':round(pnl,9),'gross_pnl_sol':round(gross_pnl,9),'estimated_cost_sol':round(est_cost,9),'wallet_session_delta_sol':wallet_session_delta,'win_rate':round(wins/max(1,len(sells)),3),'by_setup':by_setup},
        'recent_trades': trades[-80:],
        'recent_decisions': read_tail(Path('wallet_predator_decisions.jsonl'), 120),
        'recent_lifecycle': read_tail(Path('position_lifecycle.jsonl'), 120),
        'runtime_errors': runtime_errors[-50:],
        'queen_dump_recovery_candidates': read_tail(Path('queen_dump_recovery_candidates.jsonl'), 50),
        'queen_cycle_ride_candidates': read_tail(Path('queen_cycle_ride_candidates.jsonl'), 50),
        'live_wallet_sol_balance': read_tail(Path('live_wallet_sol_balance.jsonl'), 25),
        'creator_intel': creator_intel(),
        'follow_money': follow_money_view(),
        'hive_ai': hive_ai_view(),
    }



def follow_money_view():
    cfg = read_json(Path('config.json'), {})
    graph = read_json(Path(cfg.get('FOLLOW_MONEY_GRAPH_FILE', 'FOLLOW_MONEY_GRAPH.json')), {})
    watch = read_json(Path(cfg.get('FOLLOW_MONEY_WATCHLIST_FILE', 'FOLLOW_MONEY_WATCHLIST.json')), {})
    return {
        'ts': graph.get('ts'),
        'inputs': graph.get('inputs', {}),
        'entry_wallets': (graph.get('entry_wallets') or [])[:50],
        'exit_wallets': (graph.get('exit_wallets') or [])[:50],
        'creator_wallets': (graph.get('creator_wallets') or [])[:30],
        'hot_creation_mints': (graph.get('hot_creation_mints') or [])[:50],
        'watchlist_file': cfg.get('FOLLOW_MONEY_WATCHLIST_FILE', 'FOLLOW_MONEY_WATCHLIST.json'),
        'text_file': cfg.get('FOLLOW_MONEY_TEXT_FILE', 'FOLLOW_MONEY_WATCHLIST.txt'),
        'watch_counts': {
            'entry_wallets': len(watch.get('entry_wallets') or []),
            'exit_wallets': len(watch.get('exit_wallets') or []),
            'creator_wallets': len(watch.get('creator_wallets') or []),
        }
    }


def creator_intel_from_wss(limit=30):
    """WSS-only Creator Intel fallback.

    creator_tracker.py needs RPC_URL to enrich creators/funding clusters. In SIM with
    blank RPC, creator_history.json stays empty, but new_token_events.jsonl still
    has create events with wallet + mint. This builds useful dashboard creator
    cards from that WSS tape so the panel never looks dead.
    """
    now = int(time.time())
    creates = read_tail(Path('new_token_events.jsonl'), 5000)
    live = read_tail(Path('live_wallet_events.jsonl'), 5000)
    trades = read_trades()
    by_creator = {}
    by_mint_live = {}
    for e in live:
        if not isinstance(e, dict):
            continue
        m = e.get('mint') or ''
        if not m:
            continue
        row = by_mint_live.setdefault(m, {'buy_sol': 0.0, 'sell_sol': 0.0, 'buys': 0, 'sells': 0, 'buyers': set(), 'sellers': set(), 'last_mc': 0.0, 'high_mc': 0.0, 'last_ts': 0})
        sol = _num(e.get('sol'), 0.0)
        side = str(e.get('side') or '').lower()
        if side == 'buy':
            row['buy_sol'] += sol; row['buys'] += 1; row['buyers'].add(e.get('wallet') or '')
        elif side == 'sell':
            row['sell_sol'] += sol; row['sells'] += 1; row['sellers'].add(e.get('wallet') or '')
        mc = _num(e.get('mc'), 0.0)
        row['last_mc'] = mc or row['last_mc']
        row['high_mc'] = max(row.get('high_mc') or 0.0, mc)
        row['last_ts'] = max(int(_num(row.get('last_ts'), 0)), int(_num(e.get('ts'), 0)))
    for c in creates:
        if not isinstance(c, dict) or c.get('raw_type') not in ('create', 'new_token', 'token_create'):
            continue
        creator = str(c.get('wallet') or c.get('creator') or c.get('traderPublicKey') or '').strip()
        mint = str(c.get('mint') or '').strip()
        if not creator or not mint:
            continue
        r = by_creator.setdefault(creator, {'creator': creator, 'token_count': 0, 'recent_tokens': [], 'buy_sol': 0.0, 'sell_sol': 0.0, 'buys': 0, 'sells': 0, 'unique_buyers': 0, 'max_pump_sum': 0.0, 'updated_ts': 0})
        r['token_count'] += 1
        live_row = by_mint_live.get(mint, {})
        create_mc = _num(c.get('mc'), 0.0)
        high_mc = _num(live_row.get('high_mc'), create_mc)
        max_pump = ((high_mc / create_mc) - 1.0) if create_mc > 0 and high_mc > 0 else 0.0
        r['max_pump_sum'] += max(0.0, max_pump)
        r['buy_sol'] += _num(live_row.get('buy_sol'), 0.0)
        r['sell_sol'] += _num(live_row.get('sell_sol'), 0.0)
        r['buys'] += int(_num(live_row.get('buys'), 0))
        r['sells'] += int(_num(live_row.get('sells'), 0))
        r['unique_buyers'] += len(live_row.get('buyers') or [])
        r['updated_ts'] = max(int(_num(r.get('updated_ts'), 0)), int(_num(c.get('ts'), 0)), int(_num(live_row.get('last_ts'), 0)))
        our = [x for x in trades if x.get('mint') == mint]
        entry = next((x for x in our if str(x.get('side') or '').endswith('BUY')), None)
        exit_ = next((x for x in reversed(our) if str(x.get('side') or '').endswith('SELL')), None)
        r['recent_tokens'].append({
            'mint': mint,
            'creation_ts': c.get('ts'),
            'create_mc': create_mc,
            'last_mc': _num(live_row.get('last_mc'), 0.0),
            'high_mc': high_mc,
            'max_pump_pct': round(max_pump, 6),
            'buy_sol': round(_num(live_row.get('buy_sol'), 0.0), 6),
            'sell_sol': round(_num(live_row.get('sell_sol'), 0.0), 6),
            'unique_buyers': len(live_row.get('buyers') or []),
            'our_entry': entry,
            'our_exit': exit_,
        })
    rows = []
    for r in by_creator.values():
        avg_pump = r['max_pump_sum'] / max(1, r['token_count'])
        sell_buy = r['sell_sol'] / max(1e-9, r['buy_sol'])
        score = min(80.0, r['token_count'] * 8.0) + min(100.0, avg_pump * 75.0) + min(80.0, r['buy_sol'] * 2.0) - min(80.0, sell_buy * 45.0)
        toks = sorted(r['recent_tokens'], key=lambda x: x.get('creation_ts') or 0, reverse=True)[:10]
        rows.append({
            'creator': r['creator'],
            'score': round(max(0.0, score), 4),
            'token_count': r['token_count'],
            'controller_wallet': '',
            'cluster_members': [r['creator']],
            'recent_tokens': toks,
            'updated_ts': r['updated_ts'],
            'wss_buy_sol': round(r['buy_sol'], 6),
            'wss_sell_sol': round(r['sell_sol'], 6),
            'wss_sell_buy_ratio': round(sell_buy, 6),
            'avg_max_pump_pct': round(avg_pump, 6),
        })
    rows.sort(key=lambda x: (x.get('score') or 0, x.get('updated_ts') or 0), reverse=True)
    warnings = read_tail(Path('creator_tracker_warnings.jsonl'), 80)
    warning_counts = {}
    for w in warnings:
        if isinstance(w, dict):
            k = w.get('error') or w.get('warning') or 'warning'
            warning_counts[k] = warning_counts.get(k, 0) + 1
    return {
        'ts': now,
        'source': 'wss_fallback_new_token_events',
        'cluster_active_now': False,
        'top_creators': rows[:int(limit)],
        'funding_graph': read_json(Path('funding_graph.json'), {'creators': {}, 'controllers': {}, 'mints': {}}),
        'cluster_map': read_json(Path('cluster_map.json'), {}),
        'pending_token_watch': read_json(Path('pending_token_watch.json'), {}),
        'controller_alerts': read_tail(Path('controller_alerts.jsonl'), 50),
        'warning': 'RPC_URL is blank, so dashboard is using WSS create-event fallback. Add RPC_URL to enable enriched funding/cluster intel.',
        'creator_tracker_warning_counts': warning_counts,
    }

def creator_intel():
    cfg = read_json(Path('config.json'), {})
    hist = read_json(Path(cfg.get('CREATOR_HISTORY_FILE', 'creator_history.json')), {'creators': {}, 'mints': {}})
    graph = read_json(Path(cfg.get('CREATOR_FUNDING_GRAPH_FILE', 'funding_graph.json')), {'creators': {}, 'controllers': {}, 'mints': {}})
    if not (hist.get('creators') or hist.get('mints')):
        return creator_intel_from_wss(30)
    cluster_map = read_json(Path('cluster_map.json'), {})
    pending_watch = read_json(Path(cfg.get('PENDING_TOKEN_WATCH_FILE', 'pending_token_watch.json')), {})
    controller_alerts = read_tail(Path('controller_alerts.jsonl'), 100)
    trades = read_trades()
    live_events = read_tail(Path('live_wallet_events.jsonl'), 1000)
    now = int(time.time())
    cluster_wallets = set()
    for c, row in (graph.get('creators') or {}).items():
        cluster_wallets.add(c)
        if isinstance(row, dict) and row.get('controller'):
            cluster_wallets.add(row.get('controller'))
    for ctrl, row in (graph.get('controllers') or {}).items():
        cluster_wallets.add(ctrl)
        if isinstance(row, dict):
            cluster_wallets.update((row.get('funded_wallets') or {}).keys())
    for w, row in graph.items():
        if isinstance(row, dict) and row.get('cluster_id'):
            cluster_wallets.add(w)
            cluster_wallets.update(row.get('siblings') or [])
            cluster_wallets.update(row.get('funded_wallets') or [])
    for cid, row in (cluster_map or {}).items():
        if isinstance(row, dict):
            cluster_wallets.update(row.get('members') or [])
    cluster_active_now = any(
        isinstance(e, dict) and (now - int(_num(e.get('ts'), 0))) <= 60 and str(e.get('side') or '').lower() == 'buy' and str(e.get('wallet') or '') in cluster_wallets
        for e in live_events
    )

    def creator_score(tokens):
        tokens = [t for t in tokens if isinstance(t, dict)]
        if not tokens:
            return 0.0
        prior = max(0, len(tokens)-1)
        score = min(60.0, prior * 15.0)
        avg_pump = sum(max(0.0, _num(t.get('max_pump_pct'))) for t in tokens) / max(1, len(tokens))
        score += min(80.0, avg_pump * 40.0)
        buy_rate = sum(1 for t in tokens if t.get('creator_bought_at_creation') or t.get('creator_self_buy')) / max(1, len(tokens))
        score += min(80.0, buy_rate * 80.0)
        dumps = [_num(t.get('time_to_dump_sec')) for t in tokens if t.get('time_to_dump_sec') not in (None, '')]
        if dumps and sum(dumps)/max(1,len(dumps)) < 30.0:
            score -= 30.0
        return max(0.0, min(200.0, score))

    def cluster_for_creator(creator):
        out = set([creator]) if creator else set()
        cinfo = (graph.get('creators') or {}).get(creator) or {}
        ctrl = cinfo.get('controller') if isinstance(cinfo, dict) else ''
        if not ctrl and isinstance(graph.get(creator), dict):
            ctrl = (graph.get(creator) or {}).get('controller')
        cid = ((graph.get(creator) or {}).get('cluster_id') if isinstance(graph.get(creator), dict) else '') or ''
        if cid and isinstance(cluster_map.get(cid), dict):
            out.update(cluster_map.get(cid, {}).get('members') or [])
            if cluster_map.get(cid, {}).get('controller'):
                out.add(cluster_map.get(cid, {}).get('controller'))
        if ctrl:
            out.add(ctrl)
            funded = (((graph.get('controllers') or {}).get(ctrl) or {}).get('funded_wallets') or {})
            out.update(funded.keys())
        if isinstance(graph.get(creator), dict):
            out.update((graph.get(creator) or {}).get('siblings') or [])
            out.update((graph.get(creator) or {}).get('funded_wallets') or [])
        return sorted(w for w in out if w)

    rows = []
    for creator, row in (hist.get('creators') or {}).items():
        if not isinstance(row, dict):
            continue
        tokens = [t for t in (row.get('tokens') or []) if isinstance(t, dict)]
        recent = []
        for t in tokens[-10:]:
            mint = t.get('mint') or ''
            our = [x for x in trades if x.get('mint') == mint]
            entry = next((x for x in our if str(x.get('side') or '').endswith('BUY')), None)
            exit_ = next((x for x in reversed(our) if str(x.get('side') or '').endswith('SELL')), None)
            recent.append({
                'mint': mint,
                'creation_ts': t.get('ts'),
                'max_pump_pct': t.get('max_pump_pct', 0),
                'time_to_dump_sec': t.get('time_to_dump_sec'),
                'our_entry': entry,
                'our_exit': exit_,
            })
        rows.append({
            'creator': creator,
            'score': round(creator_score(tokens), 4),
            'token_count': len(tokens),
            'controller_wallet': (((graph.get('creators') or {}).get(creator) or {}).get('controller') or ((graph.get(creator) or {}).get('controller') if isinstance(graph.get(creator), dict) else '')),
            'cluster_members': cluster_for_creator(creator),
            'recent_tokens': recent,
            'updated_ts': row.get('updated_ts', 0),
        })
    rows.sort(key=lambda x: (x.get('score') or 0, x.get('token_count') or 0, x.get('updated_ts') or 0), reverse=True)
    return {'ts': now, 'cluster_active_now': cluster_active_now, 'top_creators': rows[:20], 'funding_graph': graph, 'cluster_map': cluster_map, 'pending_token_watch': pending_watch, 'controller_alerts': controller_alerts[-50:]}

HTML="""<!doctype html><html><head><meta charset="utf-8"><title>UCF Wallet Predator</title><style>
@keyframes scan{0%{background-position:0 0}100%{background-position:0 18px}}@keyframes pulse{0%,100%{text-shadow:0 0 9px #009dff88,0 0 18px #ff003c44}50%{text-shadow:0 0 16px #ff003caa,0 0 26px #009dffaa}}*{box-sizing:border-box}body{font-family:Consolas,Monaco,'Courier New',monospace;background:radial-gradient(circle at 20% 0%,#081a2a 0,#06080d 35%,#020307 100%);color:#d9efff;margin:0;padding:18px;min-height:100vh;position:relative}body:before{content:'';position:fixed;inset:0;pointer-events:none;background:linear-gradient(180deg,rgba(255,255,255,.035) 50%,rgba(0,0,0,.04) 50%);background-size:100% 4px;mix-blend-mode:overlay}body:after{content:'';position:fixed;inset:0;pointer-events:none;background:radial-gradient(circle at 75% 12%,rgba(0,157,255,.14),transparent 30%),radial-gradient(circle at 10% 85%,rgba(255,0,60,.12),transparent 25%)}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(560px,1fr));gap:12px}.card{background:linear-gradient(135deg,rgba(9,18,30,.96),rgba(18,5,14,.92));border:1px solid #0b8bff88;border-left:3px solid #ff003caa;border-radius:4px;padding:14px;box-shadow:0 0 22px #008cff22, inset 0 0 24px #ff00300f;overflow:auto;position:relative}.card:before{content:'SYS';position:absolute;right:10px;top:6px;color:#ff003c55;font-size:10px;letter-spacing:2px}h1{margin:0 0 12px;color:#e6f7ff;letter-spacing:1px;animation:pulse 2.8s infinite}.big{font-size:28px;font-weight:900;color:#5cc8ff}.ok{color:#38ffb0}.bad{color:#ff335d}.warn{color:#ffd35c}.muted{color:#7fa6c9}a{color:#5cc8ff}table{width:100%;border-collapse:collapse;font-size:13px;table-layout:auto;background:#02060a99}td,th{border-bottom:1px solid #123b5a;padding:6px;text-align:left;vertical-align:top}th{color:#ff4d73;text-transform:uppercase;letter-spacing:.08em}code{white-space:pre-wrap;color:#b9d7ff}.ca{font-family:Consolas,monospace;font-size:12px;word-break:break-all;overflow-wrap:anywhere;white-space:normal;user-select:all;max-width:none;display:inline;color:#b8e7ff}.pill{display:block;padding:6px 8px;border-radius:3px;background:linear-gradient(90deg,#061827,#190711);border:1px solid #164b70;margin:4px 0;white-space:normal;box-shadow:inset 0 0 14px #009dff0c}.copybtn{font-size:11px;margin-left:6px;background:#071f32;color:#e7f0ff;border:1px solid #1e8fd1;border-radius:3px;padding:2px 5px;cursor:pointer}.copybtn:hover{background:#2a0712;border-color:#ff335d}textarea{width:100%;height:70px;background:#02060a;color:#d7e8ff;border:1px solid #16537c;border-radius:3px}.terminal{font-size:12px;line-height:1.35;color:#9fd7ff}.redline{color:#ff335d}.blueline{color:#5cc8ff}.statusOnline{color:#38ffb0}.statusOffline{color:#ff335d}</style></head><body>
<h1>HIVE v11.2.41 STRICT EDGE TERMINAL <span class="muted" id="build"></span></h1><div class="grid" id="cards"></div><h2>Recent Trades</h2><div id="trades"></div><h2>Recent Decisions</h2><div id="decisions"></div><script>
function cp(x){navigator.clipboard&&navigator.clipboard.writeText(x)}
async function load(){let r=await fetch('/api/summary');let d=await r.json();document.getElementById('build').textContent=d.intel?.bot_build||'';let s=d.trade_stats||{};let pos=Object.keys(d.positions||{}).length;let cards=[['Net PnL SOL',s.pnl_sol,(s.pnl_sol||0)>=0?'ok':'bad'],['Gross PnL SOL',s.gross_pnl_sol||0,''],['Est. fees/slip SOL',s.estimated_cost_sol||0,'bad'],['Wallet session Δ SOL',s.wallet_session_delta_sol??'waiting',(s.wallet_session_delta_sol||0)>=0?'ok':'bad'],['Win rate',s.win_rate,''],['Buys',s.buys,''],['Sells',s.sells,''],['Sell fails',s.sell_fails||0,(s.sell_fails||0)?'bad':'ok'],['Open positions',pos,pos?'ok':''],['Runtime errors',(d.runtime_errors||[]).length,(d.runtime_errors||[]).length?'bad':'ok']];document.getElementById('cards').innerHTML=cards.map(c=>`<div class=card><div class=muted>${c[0]}</div><div class="big ${c[2]}">${c[1]}</div></div>`).join('')+`<div class=card><div class=muted>Roles</div>${Object.entries(d.profile_role_counts||{}).map(x=>`<span class=pill>${x[0]} ${x[1]}</span>`).join('')}</div>`;
let risk=d.live_risk_state||{}; document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Live risk circuit</div><div>PnL: ${risk.realized_pnl_sol||0}</div><div>Buys: ${risk.buy_count||0}</div><div>Hard stops: ${risk.hard_stops||0}</div><div>Consec losses: ${risk.consecutive_losses||0}</div></div>`;
let es=d.engine_status||{}; let stCls=es.engine_fresh?'statusOnline':'statusOffline'; document.getElementById('cards').innerHTML += `<div class=card><div class=muted>SKYNET ENGINE STATUS <a href="/api/engine_status" target="_blank">json</a></div><div class="big ${stCls}">${es.status||'UNKNOWN'}</div><div class=terminal>build: <span class=blueline>${es.bot_build||''}</span><br>profile: <span class=redline>${es.profile||''}</span><br>strict edge: ${es.strict_edge_mode?'ARMED':'off'}<br>WSS age: ${es.live_events_age_sec??'none'}s · decision age: ${es.decisions_age_sec??'none'}s · trade age: ${es.trades_age_sec??'none'}s<br>recent approvals: ${es.recent_approvals||0} · blocks: ${es.recent_blocks||0}<br>last block: <span class=redline>${es.last_block_reason||''}</span></div></div>`;
let dl=d.data_links||{}; let links=(dl.links||[]).map(x=>`<div class=pill><a href="${x.url}" target="_blank">${x.label}</a> <span class=muted>${x.status||''}</span><br><span class=terminal>file: ${x.file||''}<br>producer: ${x.producer||''}${x.age_sec==null?'':'<br>age:'+x.age_sec+'s bytes:'+x.bytes}</span></div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>DATA LINK MATRIX <a href="/api/data_links" target="_blank">json</a></div>${links}</div>`;
let bal=(d.live_wallet_sol_balance||[]).slice(-1)[0]||{}; document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Wallet SOL balance RPC</div><div class=big>${bal.sol_balance??'waiting'}</div><div class=muted>${bal.error||''}</div></div>`;
let ap=d.active_positions||[]; let activeHtml=ap.map(p=>`<div class=pill>🔥 <b>${p.setup||''}</b> hold:${p.hold_time_sec||0}s pnl:${Number((p.pnl_pct||0)*100).toFixed(2)}% high:${Number((p.high_pct||0)*100).toFixed(2)}% sol:${Number(p.sol||0).toFixed(4)}<br>CA:<span class=ca>${p.mint||''}</span><button class=copybtn onclick="cp('${p.mint||''}')">copy CA</button><br>reason:${p.reason||''}</div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Active Trades / Open Mint CAs</div>${activeHtml||'<span class=muted>no active positions</span>'}</div>`;
let hp=d.hot_sim_plays||{}; let hps=(hp.hot_plays||[]).slice(0,18).map((p,i)=>`<div class=pill>${p.play_type==='SIM_BUY_EARLY_CANDIDATE'?'🚀 BUY EARLY SIM':'👀 WATCH'} #${i+1} score:${Number(p.score||0).toFixed(1)} age:${p.token_age_sec||0}s last:${p.last_event_age_sec||0}s mc:${Number(p.last_mc||0).toFixed(1)}<br>CA:<span class=ca>${p.mint||''}</span><button class=copybtn onclick="cp('${p.mint||''}')">copy mint</button><br>buy:${Number(p.recent_buy_sol||0).toFixed(3)} sell:${Number(p.recent_sell_sol||0).toFixed(3)} ratio:${Number(p.recent_sell_buy_ratio||0).toFixed(2)} buyers:${p.unique_recent_buyers||0} profiled:${p.profiled_wallet_buy_count||0}<br><span class=muted>${p.reason||''}</span></div>`).join(''); let hpw=(hp.recent_profit_wallets||[]).slice(0,12).map((w,i)=>`<div class=pill>💸 #${i+1} ${w.action||''} score:${Number(w.score||0).toFixed(1)} buys:${w.recent_buy_count||0} sol:${Number(w.recent_buy_sol||0).toFixed(3)} age:${w.last_seen_age_sec==null?'':w.last_seen_age_sec+'s'}<br>W:<span class=ca>${w.wallet||''}</span><button class=copybtn onclick="cp('${w.wallet||''}')">copy W</button><br>latest mint:<span class=ca>${w.latest_mint||''}</span><button class=copybtn onclick="cp('${w.latest_mint||''}')">copy mint</button><br>WR:${w.profile_win_rate==null?'':Number(w.profile_win_rate*100).toFixed(0)+'%'} edge:${w.profile_edge_pct==null?'':Number(w.profile_edge_pct*100).toFixed(1)+'%'}</div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>FOLLOW THE MONEY: Hot New Stable SIM Plays <a href="/api/hot_sim_plays" target="_blank" style="color:#9fd1ff">json</a></div>${hps||'<span class=muted>waiting for fresh buy-flow tape</span>'}</div><div class=card><div class=muted>Fresh Profit Wallets Active Now</div>${hpw||'<span class=muted>waiting for profiled wallets buying fresh mints</span>'}</div>`;
let wr=d.win_rate_optimizer||{}; let fb=wr.filter_backtest||{}; let wrRows=['current_config','higher_win_rate','very_strict'].map(k=>{let r=fb[k]||{};return `<div class=pill>${k} samples:${r.samples||0} WR:${Number((r.win_rate||0)*100).toFixed(1)}% avgMax:${Number((r.avg_max_gain_pct||0)*100).toFixed(1)}%</div>`}).join(''); let health=(d.output_file_health||[]).map(f=>`<span class="pill ${f.populating?'ok':(f.optional?'':'bad')}">${f.file}: ${f.status||''} ${f.bytes||0}b age:${f.age_sec??''}s</span>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Win-Rate Optimizer <a href="/api/win_rate_optimizer" target="_blank" style="color:#9fd1ff">json</a></div>${wrRows||'<span class=muted>waiting for optimizer</span>'}<br><span class=muted>${(wr.diagnosis||[]).join(' / ')}</span></div><div class=card><div class=muted>Output File Health</div>${health}</div>`;
let ai=d.hive_ai||{}; let aiGrades=(ai.recent_grades||[]).slice(-10).reverse().map(g=>`<div class=pill>${g.grade||'?'} ${g.setup||''} entry:${Number(g.entry_score||0).toFixed(2)} danger:${Number(g.danger_score||0).toFixed(2)}<br>CA:<span class=ca>${g.mint||''}</span><button class=copybtn onclick="cp('${g.mint||''}')">copy CA</button><br>${(g.flags||[]).join(', ')}</div>`).join(''); let aiBlocks=(ai.recent_blocks||[]).slice(-8).reverse().map(b=>`<div class=pill>BLOCK ${b.setup||''} grade:${b.grade||'?'} danger:${Number(b.danger_score||0).toFixed(2)}<br>CA:<span class=ca>${b.mint||''}</span><button class=copybtn onclick="cp('${b.mint||''}')">copy CA</button><br>${b.reason||''}</div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>AI Risk Manager <a href="/api/hive_ai" target="_blank" style="color:#9fd1ff">json</a></div><div>enabled:${ai.enabled} enter:${ai.can_enter} block:${ai.can_block} softOverride:${ai.soft_override}</div><div class=muted>allowed: ${ai.allowed_setups||''}</div>${aiGrades||'<span class=muted>waiting for AI grades</span>'}<br>${aiBlocks||''}</div>`;
let qwg=d.queen_worker_graph||{}; let hiveStates=Object.values(qwg.mints||{}).slice(-12).reverse().map(h=>`<div class=pill><span class=ca>${h.mint||''}</span> ${h.hive_state} W:${h.worker_buys||0} Net:${h.net_hive_sol||0} Qsell:${h.queen_sells||0}</div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Live Hive State</div>${hiveStates||'<span class=muted>waiting</span>'}</div>`;
let ci=d.creator_intel||{}; let cr=(ci.top_creators||[]).slice(0,10).map(x=>`<div class=pill>🧠 creator score:${Number(x.score||0).toFixed(1)} tokens:${x.token_count||0}<br><span class=ca>${x.creator||''}</span><button class=copybtn onclick="cp('${x.creator||''}')">copy creator</button><br>controller:<span class=ca>${x.controller_wallet||''}</span><button class=copybtn onclick="cp('${x.controller_wallet||''}')">copy ctrl</button><br>cluster:${(x.cluster_members||[]).slice(0,5).map(w=>`<span class=ca>${w}</span>`).join('<br>')}</div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Creator Intel / Insider Clusters ${ci.cluster_active_now?'🟢 active now':'⚪ idle'} <a href="/api/creator_intel" target="_blank" style="color:#7edbff">json</a></div><div class=muted>${ci.source||'enriched'} ${ci.warning||''}</div>${cr||'<span class=muted>waiting for repeated creators</span>'}</div>`;
let qdr=(d.queen_dump_recovery_candidates||[]).slice(-8).reverse().map(x=>`<div class=pill>🎯 CA:<span class=ca>${x.mint||''}</span><button class=copybtn onclick="cp('${x.mint||''}')">copy CA</button><br>buys:${x.details?.fresh_buys_after_dump||0} sol:${Number(x.details?.buy_sol_after_dump||0).toFixed(2)} queen:<span class=ca>${x.details?.queen_sell_wallet||''}</span><button class=copybtn onclick="cp('${x.details?.queen_sell_wallet||''}')">copy Q</button></div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Queen dump recovery hits</div>${qdr||'<span class=muted>waiting for queen dump + worker refill</span>'}</div>`;
let qcy=(d.queen_cycle_ride_candidates||[]).slice(-8).reverse().map(x=>`<div class=pill>🐝👑 CA:<span class=ca>${x.mint||''}</span><button class=copybtn onclick="cp('${x.mint||''}')">copy CA</button><br>queen:<span class=ca>${x.details?.queen_wallet||''}</span><button class=copybtn onclick="cp('${x.details?.queen_wallet||''}')">copy Q</button> net:${Number(x.details?.queen_cycle_net_sol||0).toFixed(2)} buys:${x.details?.queen_cycle_buys||0}</div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Queen cycle ride candidates</div>${qcy||'<span class=muted>waiting for positive-net queen buys</span>'}</div>`;
let sp=d.swarm_edge_profiles||{}; let copy=(sp.copy_buy_wallets||[]).slice(0,10).map(w=>`<div class=pill>🧬 copy edge <span class=ca>${w.wallet||''}</span><button class=copybtn onclick="cp('${w.wallet||''}')">copy W</button><br>WR:${Number((w.win_rate||0)*100).toFixed(0)}% edge:${Number((w.fee_adjusted_edge_pct||0)*100).toFixed(1)}% samples:${w.samples||0} mints:${w.mints||0} recent:${w.recent_buy_count||0} age:${w.last_seen_age_sec==null?'':w.last_seen_age_sec+'s'}</div>`).join(''); let exits=(sp.exit_warning_wallets||[]).slice(0,10).map(w=>`<div class=pill>⚠️ exit wallet <span class=ca>${w.wallet||''}</span><button class=copybtn onclick="cp('${w.wallet||''}')">copy W</button><br>drop:${Number((w.drop_rate_after_sell||0)*100).toFixed(0)}% samples:${w.samples||0}</div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Mined copy-buy wallets - full addresses</div>${copy||'<span class=muted>run python swarm_edge_miner.py after data</span>'}</div><div class=card><div class=muted>Mined exit-warning wallets - full addresses</div>${exits||'<span class=muted>run python swarm_edge_miner.py after data</span>'}</div>`;
let calls=(d.recent_copy_call_candidates||[]).slice(0,20).map(c=>`<div class=pill>${c.call_type==='COPY_NOW'?'✅ COPY_NOW':'👀 WATCH'} score:${Number(c.call_score||0).toFixed(1)} age:${c.age_from_latest_sec||0}s WR:${Number((c.profile_win_rate||0)*100).toFixed(0)}% edge:${Number((c.profile_fee_edge_pct||0)*100).toFixed(1)}%<br>W:<span class=ca>${c.wallet||''}</span><button class=copybtn onclick="cp('${c.wallet||''}')">copy W</button><br>M:<span class=ca>${c.mint||''}</span><button class=copybtn onclick="cp('${c.mint||''}')">copy mint</button><br><span class=muted>${c.reason||''}</span></div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>SIM Best Recent Copy/Watch Calls</div>${calls||'<span class=muted>no fresh profiled wallet buys yet</span>'}</div>`;
let pw=(d.profitable_wallets||[]).slice(0,20).map((w,i)=>`<div class=pill>🏆 #${i+1} score:${Number(w.rank_score||0).toFixed(1)} WR:${w.win_rate==null?'':Number(w.win_rate*100).toFixed(1)+'%'} edge:${w.pnl_edge_pct==null?'':Number(w.pnl_edge_pct*100).toFixed(2)+'%'} samples:${w.samples||0} mints:${w.mints||0} recent:${w.recent_buy_count||0} age:${w.last_seen_age_sec==null?'':w.last_seen_age_sec+'s'}<br><span class=ca>${w.wallet||''}</span><button class=copybtn onclick="cp('${w.wallet||''}')">copy wallet</button><br>roles:${w.roles_text||''}<br><span class=muted>${w.notes_text||''}</span></div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Most Profitable Recorded Wallets <a href="/profitable_wallets.txt" target="_blank" style="color:#9fd1ff">open txt</a></div>${pw||'<span class=muted>no profitable wallet profiles yet; run sim + swarm_edge_miner.py</span>'}</div>`;
let se=(d.swarm_edge_auto_candidates||[]).slice(-8).reverse().map(x=>`<div class=pill>🧬 CA:<span class=ca>${x.mint||''}</span><button class=copybtn onclick="cp('${x.mint||''}')">copy CA</button><br>wallet:<span class=ca>${x.details?.wallet||''}</span><button class=copybtn onclick="cp('${x.details?.wallet||''}')">copy W</button> score:${Number(x.score||0).toFixed(1)}</div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Swarm edge auto-ride hits</div>${se||'<span class=muted>waiting for mined wallet context</span>'}</div>`;
let queen=(d.queen_candidates||[]).slice(0,12).map(w=>`<div class=pill>👑 <span class=ca>${w.wallet||''}</span><button class=copybtn onclick="cp('${w.wallet||''}')">copy</button><br>${w.role||''} traps:${w.trap_hits||0} qSell:${Number(w.queen_sell_sol||0).toFixed(2)} score:${Number(w.score||0).toFixed(1)}</div>`).join(''); let workers=(d.worker_accumulators||[]).slice(0,12).map(w=>`<div class=pill>🐝 <span class=ca>${w.wallet||''}</span><button class=copybtn onclick="cp('${w.wallet||''}')">copy</button><br>${w.role||''} runs:${w.runner_hits||0} buy:${Number(w.worker_buy_sol||w.buy_sol||0).toFixed(2)} score:${Number(w.score||0).toFixed(1)}</div>`).join(''); document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Queen candidates - full copyable wallets</div>${queen||'<span class=muted>waiting for queen exits</span>'}</div><div class=card><div class=muted>Worker accumulators - full copyable wallets</div>${workers||'<span class=muted>waiting for worker flow</span>'}</div>`;
let by=s.by_setup||{}; document.getElementById('cards').innerHTML += `<div class=card><div class=muted>Setup PnL</div>${Object.entries(by).map(([k,v])=>`<div class=pill>${k}: ${Number(v.pnl||0).toFixed(4)} / WR ${((v.wins||0)/Math.max(1,v.sells||0)*100).toFixed(0)}%</div>`).join('')}</div>`;
let tr=d.recent_trades||[];document.getElementById('trades').innerHTML='<table><tr><th>side</th><th>setup</th><th>mint</th><th>sol</th><th>net pnl</th><th>gross</th><th>fee/slip</th><th>reason</th></tr>'+tr.slice(-50).reverse().map(t=>`<tr><td>${t.side||''}</td><td>${t.setup||''}</td><td class=ca>${t.mint||''}<button class=copybtn onclick="cp('${t.mint||''}')">copy</button></td><td>${t.sol||''}</td><td>${t.pnl_sol||''}</td><td>${t.gross_pnl_sol||''}</td><td>${t.estimated_cost_sol||''}</td><td>${t.reason||''}</td></tr>`).join('')+'</table>';
let dec=d.recent_decisions||[];document.getElementById('decisions').innerHTML='<table><tr><th>ok</th><th>setup</th><th>mint / CA</th><th>score</th><th>last wallet</th><th>reason</th></tr>'+dec.slice(-80).reverse().map(x=>`<tr><td>${x.approved?'✅':'❌'}</td><td>${x.setup||''}</td><td class=ca>${x.mint||''}<button class=copybtn onclick="cp('${x.mint||''}')">copy CA</button></td><td>${x.score||''}</td><td class=ca>${x.last_event_wallet||x.last_wallet||''}<button class=copybtn onclick="cp('${x.last_event_wallet||x.last_wallet||''}')">copy W</button></td><td>${x.reason||x.raw||''}</td></tr>`).join('')+'</table>';}
load(); setInterval(load,3000);
</script></body></html>"""

class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype='application/json'):
        b=body.encode('utf-8') if isinstance(body,str) else body
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        p=urlparse(self.path).path
        if p=='/' or p=='/dashboard': self._send(200,HTML,'text/html; charset=utf-8')
        elif p=='/api/summary': self._send(200,json.dumps(summary(),indent=2), 'application/json')
        elif p=='/api/engine_status': self._send(200,json.dumps(engine_status_view(),indent=2), 'application/json')
        elif p=='/api/data_links': self._send(200,json.dumps(data_links_view(),indent=2), 'application/json')
        elif p=='/api/creator_intel': self._send(200,json.dumps(creator_intel(),indent=2), 'application/json')
        elif p=='/api/follow_money': self._send(200,json.dumps(follow_money_view(),indent=2), 'application/json')
        elif p=='/api/profitable_wallets': self._send(200,json.dumps({'ts': int(time.time()), 'wallets': most_profitable_wallets(75)}, indent=2), 'application/json')
        elif p=='/api/hot_sim_plays': self._send(200,json.dumps(hot_sim_plays_view(), indent=2), 'application/json')
        elif p=='/api/win_rate_optimizer': self._send(200,json.dumps(win_rate_optimizer_view(), indent=2), 'application/json')
        elif p=='/api/output_file_health': self._send(200,json.dumps(output_file_health(), indent=2), 'application/json')
        elif p=='/api/hive_ai': self._send(200,json.dumps(hive_ai_view(), indent=2), 'application/json')
        elif p=='/profitable_wallets.txt': self._send(200, profitable_wallets_text(75), 'text/plain; charset=utf-8')
        else: self._send(404,'not found','text/plain')

if __name__=='__main__':
    print(f'Dashboard: http://127.0.0.1:{PORT}')
    ThreadingHTTPServer(('127.0.0.1', PORT), Handler).serve_forever()
