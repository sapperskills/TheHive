#!/usr/bin/env python3
"""Export THE HIVE's best recorded wallets to MOST_PROFITABLE_WALLETS.txt.

This is intentionally lightweight: it reuses dashboard_server's ranking logic so the
text export and dashboard panel always agree. Run after SIM/LIVE data collection or
after `python swarm_edge_miner.py` refreshes swarm_edge_profiles.json.
"""
from __future__ import annotations

from pathlib import Path

from dashboard_server import profitable_wallets_text, most_profitable_wallets


def main() -> None:
    out = Path('MOST_PROFITABLE_WALLETS.txt')
    out.write_text(profitable_wallets_text(100), encoding='utf-8')
    rows = most_profitable_wallets(100)
    print(f'Wrote {out.resolve()} with {len(rows)} ranked wallets')
    for i, w in enumerate(rows[:10], 1):
        print(f"{i:02d} {w.get('wallet')} score={w.get('rank_score')} roles={w.get('roles_text')}")


if __name__ == '__main__':
    main()
