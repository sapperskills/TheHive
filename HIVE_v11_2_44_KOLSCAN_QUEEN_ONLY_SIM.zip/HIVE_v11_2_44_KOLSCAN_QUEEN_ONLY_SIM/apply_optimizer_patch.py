#!/usr/bin/env python3
"""Apply the strict optimizer patch after a SIM run.

Default is dry-run so it cannot silently change live config.
Use:
  python apply_optimizer_patch.py --dry-run
  python apply_optimizer_patch.py --apply
"""
from __future__ import annotations
import argparse, json, shutil, time
from pathlib import Path

DEFAULT_PATCH = {
  "MIN_ENTRY_SCORE": 900.0,
  "PRESSURE_RUNNER_MIN_SCORE": 900.0,
  "PRESSURE_RUNNER_MIN_BUY_SOL_RECENT": 15.0,
  "PRESSURE_RUNNER_MAX_SELL_PRESSURE": 0.30,
  "PRESSURE_RUNNER_MAX_SELL_BUY_RATIO": 0.55,
  "PRESSURE_RUNNER_REQUIRE_PRIORITY_CONFIRM": True,
  "PRESSURE_RUNNER_CONFIRM_MODE": "priority_or_extreme_flow",
  "RUNNER_TRAIL_PCT": 0.028,
  "ATH_DROP_EXIT_ENABLED": True,
  "ATH_DROP_EXIT_PCT": 0.025,
  "RUNNER_MAX_HOLD_SEC": 120.0,
  "HOT_PLAY_MAX_SELL_BUY_RATIO": 0.32,
  "HOT_PLAY_MIN_RECENT_BUY_SOL": 0.65,
  "HOT_PLAY_MIN_RECENT_BUYERS": 5,
  "HOT_PLAY_MAX_TOKEN_AGE_SEC": 720,
  "FAST_SNIPER_IDEAL_NET_PCT": 0.05,
  "MAX_OPEN_POSITIONS": 1,
}

def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return default

def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument('--apply', action='store_true', help='actually update config.json')
    ap.add_argument('--dry-run', action='store_true', help='print patch only')
    ap.add_argument('--config', default='config.json')
    ap.add_argument('--report', default='WIN_RATE_OPTIMIZER_REPORT.json')
    args=ap.parse_args()
    cfg_path=Path(args.config)
    cfg=load_json(cfg_path,{})
    report=load_json(Path(args.report),{})
    rec=(report.get('recommended_config_patch') or {}) if isinstance(report,dict) else {}
    patch={**DEFAULT_PATCH, **rec}
    # Force the PnL confirmation values even if an older optimizer report recommends looser values.
    patch.update({
      'MIN_ENTRY_SCORE': 900.0,
      'PRESSURE_RUNNER_MIN_SCORE': 900.0,
      'PRESSURE_RUNNER_MIN_BUY_SOL_RECENT': 15.0,
      'PRESSURE_RUNNER_REQUIRE_PRIORITY_CONFIRM': True,
      'PRESSURE_RUNNER_CONFIRM_MODE': 'priority_or_extreme_flow',
      'RUNNER_TRAIL_PCT': 0.028,
      'HOT_PLAY_MAX_SELL_BUY_RATIO': 0.32,
      'FAST_SNIPER_IDEAL_NET_PCT': 0.05,
    })
    print(json.dumps(patch, indent=2, sort_keys=True))
    if not args.apply:
        print('\nDRY RUN ONLY. Re-run with --apply to write config.json')
        return
    if cfg_path.exists():
        backup=cfg_path.with_suffix('.json.bak_' + str(int(time.time())))
        shutil.copy2(cfg_path, backup)
        print(f'backup: {backup}')
    cfg.update(patch)
    cfg_path.write_text(json.dumps(cfg, indent=2), encoding='utf-8')
    print(f'updated {cfg_path}')

if __name__ == '__main__':
    main()
