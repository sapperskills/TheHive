#!/usr/bin/env python3
from __future__ import annotations
"""Follow-the-money wallet graph miner for THE HIVE.

Builds a bigger wallet web from local logs only:
- creator/dev wallets from creator_wallet_map.jsonl / creator_history.json
- first buyers on newly created mints from live_wallet_events.jsonl / buy_sell_only.jsonl
- dev/creator sell warnings
- copy-buy candidates and exit-only wallets

It is intentionally offline/cheap. It does not call RPC and will never trade by itself.
"""
import argparse, json, time, csv
from pathlib import Path
from typing import Any, Dict, List, Tuple

BAD_ROLES = {'dump_risk','sell_near_high','sell_only','flipper','exit_warning'}
GOOD_ROLES = {'alpha','accumulator','copy_buy_edge','early_dev_buyer','creator_cluster_buyer'}


def now_ts() -> int:
    return int(time.time())


def load_json(path: str | Path, default: Any) -> Any:
    p = Path(path)
    if not p.exists(): return default
    try:
        return json.loads(p.read_text(encoding='utf-8', errors='ignore'))
    except Exception:
        return default


def save_json(path: str | Path, obj: Any) -> None:
    p = Path(path)
    tmp = p.with_suffix(p.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding='utf-8')
    tmp.replace(p)


def iter_jsonl(path: str | Path, max_lines: int = 250_000) -> List[Dict[str, Any]]:
    p = Path(path)
    if not p.exists(): return []
    try:
        lines = p.read_text(encoding='utf-8', errors='ignore').splitlines()
        if max_lines and len(lines) > max_lines:
            lines = lines[-max_lines:]
        out=[]
        for line in lines:
            if not line.strip(): continue
            try:
                obj=json.loads(line)
                if isinstance(obj, dict): out.append(obj)
            except Exception:
                continue
        return out
    except Exception:
        return []


def fnum(x: Any, default: float = 0.0) -> float:
    try:
        if x is None or x == '': return default
        return float(x)
    except Exception:
        return default


def inum(x: Any, default: int = 0) -> int:
    try:
        if x is None or x == '': return default
        return int(float(x))
    except Exception:
        return default


def wallet_row(wallet: str) -> Dict[str, Any]:
    return {
        'wallet': wallet, 'roles': [], 'mints_seen': 0, 'buy_count': 0, 'sell_count': 0,
        'buy_sol': 0.0, 'sell_sol': 0.0, 'net_sol': 0.0,
        'early_buy_count': 0, 'creator_buy_count': 0, 'dev_sell_count': 0,
        'runner_hits': 0, 'trap_hits': 0, 'score': 0.0, 'last_seen_ts': 0,
        'example_mints': []
    }


def add_role(row: Dict[str, Any], role: str) -> None:
    if role and role not in row['roles']:
        row['roles'].append(role)


def read_trade_pnl(path: str | Path) -> Dict[str, Dict[str, Any]]:
    p=Path(path)
    out: Dict[str, Dict[str, Any]] = {}
    if not p.exists(): return out
    try:
        with p.open(newline='', encoding='utf-8', errors='ignore') as f:
            for r in csv.DictReader(f):
                mint=str(r.get('mint') or '')
                if not mint: continue
                row=out.setdefault(mint, {'pnl_sol':0.0,'wins':0,'losses':0,'trades':0,'setups':{}})
                pnl=fnum(r.get('pnl_sol'), 0.0)
                side=str(r.get('side') or '')
                if 'SELL' in side or 'SIM_SELL' in side:
                    row['pnl_sol'] += pnl; row['trades'] += 1
                    if pnl > 0: row['wins'] += 1
                    elif pnl < 0: row['losses'] += 1
                setup=str(r.get('setup') or '')
                if setup: row['setups'][setup]=row['setups'].get(setup,0)+1
    except Exception:
        pass
    return out


def build_graph(cfg: Dict[str, Any]) -> Dict[str, Any]:
    ts=now_ts()
    events = iter_jsonl(cfg.get('LIVE_WALLET_EVENTS_FILE','live_wallet_events.jsonl'), inum(cfg.get('FOLLOW_MONEY_MAX_EVENTS'), 250000))
    clean = iter_jsonl(cfg.get('BUY_SELL_ONLY_JSONL','buy_sell_only.jsonl'), inum(cfg.get('FOLLOW_MONEY_MAX_EVENTS'), 250000))
    # Merge, de-dupe by sig/side/wallet/mint/ts where possible.
    seen=set(); all_events=[]
    for e in events + clean:
        mint=str(e.get('mint') or '')
        wallet=str(e.get('wallet') or e.get('traderPublicKey') or '')
        side=str(e.get('side') or e.get('txType') or '').lower()
        if not mint or not wallet or side not in ('buy','sell'): continue
        key=(e.get('sig') or e.get('signature') or '', mint, wallet, side, inum(e.get('ts'),0))
        if key in seen: continue
        seen.add(key); all_events.append(e)
    all_events.sort(key=lambda e: inum(e.get('ts'), 0))

    creator_map_rows = iter_jsonl(cfg.get('CREATOR_WALLET_MAP_FILE','creator_wallet_map.jsonl'), 100000)
    new_token_rows = iter_jsonl(cfg.get('NEW_TOKEN_EVENTS_FILE','new_token_events.jsonl'), 100000)
    creator_history = load_json(cfg.get('CREATOR_HISTORY_FILE','creator_history.json'), {'creators':{}, 'mints':{}})
    funding_graph = load_json(cfg.get('CREATOR_FUNDING_GRAPH_FILE','funding_graph.json'), {'creators':{}, 'controllers':{}, 'mints':{}})
    wallet_rep = load_json(cfg.get('WALLET_REPUTATION_FILE','wallet_reputation.json'), {'wallets':{}})
    swarm = load_json(cfg.get('SWARM_EDGE_PROFILE_FILE','swarm_edge_profiles.json'), {})
    trade_pnl = read_trade_pnl(cfg.get('TRADES_FILE','wallet_predator_trades.csv'))

    mint_creator: Dict[str,str] = {}
    mint_created_ts: Dict[str,int] = {}
    for r in creator_map_rows + new_token_rows:
        mint=str(r.get('mint') or '')
        creator=str(r.get('creator_wallet') or r.get('creator') or r.get('wallet') or '')
        if mint and creator:
            mint_creator[mint]=creator; mint_created_ts[mint]=inum(r.get('ts'), mint_created_ts.get(mint,0)) or ts
    for m,r in (creator_history.get('mints') or {}).items():
        if isinstance(r, dict) and r.get('creator'):
            mint_creator[str(m)] = str(r.get('creator'))
            mint_created_ts[str(m)] = inum(r.get('ts'), mint_created_ts.get(str(m),0)) or mint_created_ts.get(str(m),0)
    for m,r in (funding_graph.get('mints') or {}).items():
        if isinstance(r, dict) and r.get('creator'):
            mint_creator[str(m)] = str(r.get('creator'))
            mint_created_ts[str(m)] = inum(r.get('ts'), mint_created_ts.get(str(m),0)) or mint_created_ts.get(str(m),0)

    wallets: Dict[str, Dict[str, Any]] = {}
    mints: Dict[str, Dict[str, Any]] = {}
    def W(w: str) -> Dict[str, Any]:
        if w not in wallets: wallets[w]=wallet_row(w)
        return wallets[w]

    # Mark creator/controller roles.
    for mint, creator in mint_creator.items():
        row = mints.setdefault(mint, {'mint': mint, 'creator': creator, 'created_ts': mint_created_ts.get(mint,0), 'first_buyers': [], 'dev_sells': [], 'buy_count':0, 'sell_count':0, 'max_mc':0.0})
        row['creator']=creator
        cw=W(creator); add_role(cw, 'creator'); cw['mints_seen'] += 1
    for creator, r in (funding_graph.get('creators') or {}).items():
        if not isinstance(r, dict): continue
        ctrl=str(r.get('controller') or '')
        if ctrl:
            add_role(W(ctrl), 'controller')
            add_role(W(creator), 'funded_creator')
    for ctrl, r in (funding_graph.get('controllers') or {}).items():
        if isinstance(r, dict):
            add_role(W(str(ctrl)), 'controller')
            for fw in (r.get('funded_wallets') or {}).keys(): add_role(W(str(fw)), 'funded_creator')

    by_mint: Dict[str, List[Dict[str, Any]]] = {}
    for e in all_events:
        by_mint.setdefault(str(e.get('mint')), []).append(e)

    early_window = inum(cfg.get('FOLLOW_MONEY_EARLY_WINDOW_SEC'), 45)
    first_n = inum(cfg.get('FOLLOW_MONEY_FIRST_BUYERS_N'), 12)
    runner_pct = fnum(cfg.get('FOLLOW_MONEY_RUNNER_HIT_PCT'), 0.10)

    for mint, evs in by_mint.items():
        evs.sort(key=lambda e: inum(e.get('ts'), 0))
        creator = mint_creator.get(mint, '')
        created = mint_created_ts.get(mint, inum(evs[0].get('ts'), ts) if evs else 0)
        mrow = mints.setdefault(mint, {'mint': mint, 'creator': creator, 'created_ts': created, 'first_buyers': [], 'dev_sells': [], 'buy_count':0, 'sell_count':0, 'max_mc':0.0})
        mrow['creator']=creator; mrow['created_ts']=created
        max_mc = 0.0
        for e in evs:
            max_mc=max(max_mc, fnum(e.get('mc'), 0.0))
        mrow['max_mc']=max_mc
        buy_i=0
        cluster=set([creator]) if creator else set()
        # Add controller/funded siblings if available.
        cinfo=(funding_graph.get('creators') or {}).get(creator) or {}
        ctrl=str(cinfo.get('controller') or '')
        if ctrl: cluster.add(ctrl)
        funded=(((funding_graph.get('controllers') or {}).get(ctrl) or {}).get('funded_wallets') or {}) if ctrl else {}
        cluster.update(str(x) for x in funded.keys())
        for e in evs:
            w=str(e.get('wallet') or e.get('traderPublicKey') or '')
            side=str(e.get('side') or e.get('txType') or '').lower()
            sol=fnum(e.get('sol'),0.0); ets=inum(e.get('ts'),0); mc=fnum(e.get('mc'),0.0)
            wr=W(w); wr['last_seen_ts']=max(wr.get('last_seen_ts',0), ets)
            if mint not in wr['example_mints'] and len(wr['example_mints'])<8: wr['example_mints'].append(mint)
            if side=='buy':
                buy_i += 1; mrow['buy_count'] += 1; wr['buy_count'] += 1; wr['buy_sol'] += sol; wr['net_sol'] += sol
                if buy_i <= first_n or (created and ets-created <= early_window):
                    wr['early_buy_count'] += 1; add_role(wr, 'early_buyer')
                    mrow['first_buyers'].append({'wallet': w, 'ts': ets, 'sol': sol, 'mc': mc, 'rank': buy_i})
                if w in cluster:
                    wr['creator_buy_count'] += 1; add_role(wr, 'creator_cluster_buyer')
                    if w == creator: add_role(wr, 'creator_self_buyer')
                # crude label: did this buy ever get >= runner_pct upside later?
                if mc > 0 and max_mc >= mc * (1.0 + runner_pct):
                    wr['runner_hits'] += 1
            elif side=='sell':
                mrow['sell_count'] += 1; wr['sell_count'] += 1; wr['sell_sol'] += sol; wr['net_sol'] -= sol
                if w in cluster:
                    wr['dev_sell_count'] += 1; add_role(wr, 'dev_exit_warning')
                    mrow['dev_sells'].append({'wallet': w, 'ts': ets, 'sol': sol, 'mc': mc})

    # Merge existing reputation and swarm data.
    for w, rep in (wallet_rep.get('wallets') or {}).items():
        wr=W(str(w))
        role=str((rep or {}).get('role') or '')
        if role: add_role(wr, role)
        wr['score'] += fnum((rep or {}).get('score'),0.0) * 0.002
        wr['runner_hits'] += inum((rep or {}).get('runner_hits'),0)
        wr['trap_hits'] += inum((rep or {}).get('trap_hits'),0) + inum((rep or {}).get('loss_bait_buys'),0)
    for r in swarm.get('copy_buy_wallets') or []:
        w=str((r or {}).get('wallet') or '')
        if w:
            wr=W(w); add_role(wr, 'copy_buy_edge')
            wr['score'] += fnum((r or {}).get('win_rate'),0.0)*25 + min(inum((r or {}).get('samples'),0),50)*0.3 + fnum((r or {}).get('fee_adjusted_edge_pct'),0.0)*100
    for r in swarm.get('exit_warning_wallets') or []:
        w=str((r or {}).get('wallet') or '')
        if w:
            wr=W(w); add_role(wr, 'exit_warning'); wr['score'] -= 10 + min(inum((r or {}).get('samples'),0),50)*0.2

    entry_wallets=[]; exit_wallets=[]; creators=[]
    for w, wr in wallets.items():
        roles=set(wr.get('roles') or [])
        wr['buy_sol']=round(wr['buy_sol'],6); wr['sell_sol']=round(wr['sell_sol'],6); wr['net_sol']=round(wr['net_sol'],6)
        # score favors repeat early buyers + actual runner hits + net buy; penalizes dev sells/traps.
        score = wr.get('score',0.0)
        score += wr['early_buy_count']*2.4 + wr['creator_buy_count']*4.0 + wr['runner_hits']*1.2 + max(0, wr['net_sol'])*0.5
        score -= wr['dev_sell_count']*6.0 + wr['trap_hits']*0.45
        wr['score']=round(score,3)
        if roles & BAD_ROLES or wr['dev_sell_count']>0:
            exit_wallets.append(wr)
        elif (roles & GOOD_ROLES or wr['early_buy_count'] >= inum(cfg.get('FOLLOW_MONEY_MIN_EARLY_BUYS'),3)) and wr['score'] >= fnum(cfg.get('FOLLOW_MONEY_MIN_ENTRY_WALLET_SCORE'), 8.0):
            entry_wallets.append(wr)
        if 'creator' in roles or 'funded_creator' in roles:
            creators.append(wr)
    entry_wallets.sort(key=lambda r: (r.get('score',0), r.get('runner_hits',0), r.get('early_buy_count',0)), reverse=True)
    exit_wallets.sort(key=lambda r: (r.get('dev_sell_count',0), r.get('score',0)), reverse=True)
    creators.sort(key=lambda r: (r.get('score',0), r.get('mints_seen',0)), reverse=True)

    hot_creation=[]
    for mint, mr in mints.items():
        if mr.get('dev_sells'): continue
        first=mr.get('first_buyers') or []
        good_first=[x for x in first if x.get('wallet') in {r['wallet'] for r in entry_wallets[:200]}]
        if good_first:
            hot_creation.append({'mint': mint, 'creator': mr.get('creator',''), 'created_ts': mr.get('created_ts',0), 'first_vetted_buyers': good_first[:5], 'buy_count': mr.get('buy_count',0), 'max_mc': mr.get('max_mc',0)})
    hot_creation.sort(key=lambda r: (r.get('created_ts',0), len(r.get('first_vetted_buyers') or [])), reverse=True)

    graph={
        'ts': ts,
        'inputs': {'events': len(all_events), 'mints': len(mints), 'wallets': len(wallets), 'creators': len(creators)},
        'entry_wallets': entry_wallets[:inum(cfg.get('FOLLOW_MONEY_ENTRY_WALLET_LIMIT'),200)],
        'exit_wallets': exit_wallets[:inum(cfg.get('FOLLOW_MONEY_EXIT_WALLET_LIMIT'),250)],
        'creator_wallets': creators[:100],
        'hot_creation_mints': hot_creation[:100],
        'mints': dict(list(sorted(mints.items(), key=lambda kv: kv[1].get('created_ts',0), reverse=True))[:500]),
        'trade_pnl_by_mint': trade_pnl,
        'notes': [
            'entry_wallets are candidates for confirmation only, not blind copy authority',
            'exit_wallets/dev_exit_warning should tighten trail or sell when they sell our mint',
            'hot_creation_mints are fresh creations where vetted early buyers appeared and no dev sell was seen locally'
        ]
    }
    return graph


def write_outputs(graph: Dict[str, Any], cfg: Dict[str, Any]) -> None:
    save_json(cfg.get('FOLLOW_MONEY_GRAPH_FILE','FOLLOW_MONEY_GRAPH.json'), graph)
    watch = {
        'ts': graph.get('ts'),
        'entry_wallets': [r['wallet'] for r in graph.get('entry_wallets', [])],
        'exit_wallets': [r['wallet'] for r in graph.get('exit_wallets', [])],
        'creator_wallets': [r['wallet'] for r in graph.get('creator_wallets', [])],
        'hot_creation_mints': graph.get('hot_creation_mints', [])[:50],
    }
    save_json(cfg.get('FOLLOW_MONEY_WATCHLIST_FILE','FOLLOW_MONEY_WATCHLIST.json'), watch)
    lines=['THE HIVE FOLLOW MONEY WATCHLIST', f"ts={graph.get('ts')} events={graph.get('inputs',{}).get('events')} wallets={graph.get('inputs',{}).get('wallets')}", '', 'ENTRY WALLETS']
    for r in graph.get('entry_wallets', [])[:50]:
        lines.append(f"{r['wallet']} score={r.get('score')} roles={','.join(r.get('roles') or [])} early={r.get('early_buy_count')} runners={r.get('runner_hits')} net={r.get('net_sol')}")
    lines.append('\nEXIT / DEV SELL WARNING WALLETS')
    for r in graph.get('exit_wallets', [])[:50]:
        lines.append(f"{r['wallet']} score={r.get('score')} roles={','.join(r.get('roles') or [])} dev_sells={r.get('dev_sell_count')} sells={r.get('sell_count')}")
    lines.append('\nHOT CREATION MINTS')
    for r in graph.get('hot_creation_mints', [])[:50]:
        lines.append(f"{r.get('mint')} creator={r.get('creator')} vetted_first_buyers={len(r.get('first_vetted_buyers') or [])} buys={r.get('buy_count')} max_mc={r.get('max_mc')}")
    Path(cfg.get('FOLLOW_MONEY_TEXT_FILE','FOLLOW_MONEY_WATCHLIST.txt')).write_text('\n'.join(lines), encoding='utf-8')


def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument('--config', default='config.json')
    args=ap.parse_args()
    cfg=load_json(args.config,{})
    graph=build_graph(cfg)
    write_outputs(graph,cfg)
    print(json.dumps({'ok': True, 'inputs': graph.get('inputs'), 'entry_wallets': len(graph.get('entry_wallets',[])), 'exit_wallets': len(graph.get('exit_wallets',[])), 'hot_creation_mints': len(graph.get('hot_creation_mints',[]))}, indent=2))

if __name__ == '__main__':
    main()
