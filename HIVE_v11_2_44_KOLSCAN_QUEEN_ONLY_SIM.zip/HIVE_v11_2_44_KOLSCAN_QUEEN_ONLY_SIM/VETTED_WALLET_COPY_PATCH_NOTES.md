# v11.2.39 Vetted Wallet Copy Upgrade

- Added `priority_copy_wallet_buy` lane.
- Vets high-win-rate wallets against current reputation.
- Blocks `dump_risk`, `sell_near_high`, `sell_only`, and `flipper` wallets from entry.
- Uses danger wallets as exit-only warnings.
- Writes `VETTED_WALLET_REPORT.json`, `VETTED_WALLETS.txt`, and `VETTED_WSS_SIGNAL_WALLETS.json`.

After SIM:

```powershell
python build_vetted_wallet_watchlist.py
python win_rate_optimizer.py
python pnl_edge_miner.py
```
