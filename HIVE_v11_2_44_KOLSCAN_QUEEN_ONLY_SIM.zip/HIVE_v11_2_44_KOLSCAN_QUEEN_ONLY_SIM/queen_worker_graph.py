from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Set
from util import load_json, save_json, append_jsonl, fnum, inum, now_ts

QUEEN_ROLES = {'dump_risk', 'sell_only', 'sell_near_high'}
WORKER_ROLES = {'accumulator', 'alpha'}
NOISE_ROLES = {'watch', 'flipper'}

# ── v11.2.18: hive movement pattern tracker ─────────────────────────────────
# Tracks per-mint sequences of hive states to find the winning counter:
#   worker_swarm (or watch_surge) → queen_exit is the highest-PnL window.
# Also promotes watch wallets to "soft_worker" when they co-move with known
# workers in the same mint window (observed cluster signal).
# ─────────────────────────────────────────────────────────────────────────────

class HivePatternMemory:
    """Track per-mint hive state sequences and compute pattern scores."""
    def __init__(self):
        self.sequences: Dict[str, List[str]] = {}     # mint → ordered state list
        self.watch_sol_by_mint: Dict[str, float] = {} # mint → cumulative watch_buy_sol
        self.queen_precursor: Dict[str, bool] = {}     # mint → had worker/swarm before queen_exit?
        self.window_entries: Dict[str, int] = {}       # mint → how many swarm windows we saw

    def record(self, mint: str, state: str, watch_buy_sol: float, queen_exit: bool) -> None:
        if mint not in self.sequences:
            self.sequences[mint] = []
        self.sequences[mint].append(state)
        self.watch_sol_by_mint[mint] = self.watch_sol_by_mint.get(mint, 0.0) + watch_buy_sol
        if state in ('worker_swarm', 'worker_entry', 'watch_surge'):
            self.window_entries[mint] = self.window_entries.get(mint, 0) + 1
        if queen_exit and mint in self.sequences:
            had_precursor = any(s in ('worker_swarm', 'worker_entry', 'watch_surge')
                                for s in self.sequences[mint][:-1])
            self.queen_precursor[mint] = had_precursor

    def winning_counter_score(self, mint: str, current_state: str) -> float:
        """Return a bonus score when the current state matches winning counter conditions.
        
        Winning counter = worker_swarm / watch_surge active, no queen selling yet.
        History shows worker_swarm → queen_exit in 1–53s, so entering on swarm
        and exiting on queen_shadow is the primary edge.
        """
        score = 0.0
        seq = self.sequences.get(mint, [])
        watch_sol = self.watch_sol_by_mint.get(mint, 0.0)
        # Recent state was watch before swarm — building momentum
        if current_state in ('worker_swarm', 'watch_surge') and 'watch' in seq[-3:]:
            score += 12.0
        # This mint previously had swarm → queen_exit (confirmed pattern)
        if self.queen_precursor.get(mint):
            score += 8.0
        # High watch accumulation on clean mint = crowd is buying before queen arrives
        if watch_sol > 5.0 and current_state != 'queen_exit':
            score += min(watch_sol / 10.0, 10.0)
        return score

    def is_late_queen_entry(self, mint: str) -> bool:
        """True if queen_exit already fired — do not enter."""
        seq = self.sequences.get(mint, [])
        return seq[-1] == 'queen_exit' if seq else False


class QueenWorkerGraph:
    """Classify live wallet flow into queen/worker/hive state.

    v11.2.18 changes
    ─────────────────
    • HivePatternMemory tracks per-mint state sequences to score the
      worker_swarm → queen_exit counter pattern.
    • watch wallets with high sol volume are promoted to 'soft_worker'
      when no true worker/accumulator is identified — so worker_entry_ok
      can fire even when only watch-role wallets are accumulating.
    • watch_surge: new hive state for high-volume watch accumulation before
      any queen sell. Treated the same as worker_swarm for entry decisions.
    • queen_pre_exit_warning: fired one tick before queen_exit to give the
      executor an early tighten signal.
    • Sequence-based winning_counter_score() surfaced in analyze_events()
      output so strategy.py can incorporate it into _hive_entry_bonus().
    """
    def __init__(self, config: Dict[str, Any]):
        self.cfg = config
        data_dir = Path(config.get('DATA_DIR') or '.')
        self.wallet_rep = load_json(data_dir / config.get('WALLET_REPUTATION_FILE','wallet_reputation.json'), {'wallets': {}}) or {'wallets': {}}
        self.queen_report = load_json(data_dir / config.get('QUEEN_HIVE_REPORT_FILE','queen_hive_report.json'), {}) or {}
        self.clusters = load_json(data_dir / config.get('WALLET_CLUSTERS_FILE','wallet_clusters.json'), {'pairs': {}}) or {'pairs': {}}
        self.state_file = str(config.get('QUEEN_WORKER_GRAPH_FILE','queen_worker_graph_state.json'))
        self.decisions_file = str(config.get('QUEEN_WORKER_DECISIONS_FILE','queen_worker_decisions.jsonl'))
        self.queen_wallets: Set[str] = set()
        self.worker_wallets: Set[str] = set()
        for r in self.queen_report.get('queen_candidates') or []:
            w = r.get('wallet')
            if w: self.queen_wallets.add(w)
        for r in self.queen_report.get('worker_accumulators') or []:
            w = r.get('wallet')
            if w: self.worker_wallets.add(w)
        for w, r in (self.wallet_rep.get('wallets') or {}).items():
            role = str(r.get('role') or 'watch')
            if role in QUEEN_ROLES or inum(r.get('trap_hits'),0) > 0 or inum(r.get('sold_near_high'),0) > 0 or inum(r.get('dumped'),0) > 0:
                self.queen_wallets.add(w)
            if role in WORKER_ROLES and inum(r.get('trap_hits'),0) == 0:
                self.worker_wallets.add(w)
        self.adjacent_to_queen: Set[str] = set()
        self._build_queen_adjacency()
        # v11.2.18: hive pattern memory
        self.pattern_memory = HivePatternMemory()
        # v11.2.18: per-mint queen pressure cache for pre_exit_warning
        self._prev_queen_sell_sol: Dict[str, float] = {}

    def _build_queen_adjacency(self) -> None:
        if not self.cfg.get('QUEEN_WORKER_ADJACENCY_ENABLED', True):
            return
        min_pair = inum(self.cfg.get('QUEEN_WORKER_ADJACENCY_MIN_PAIR_COUNT'), 2)
        for pair, count in (self.clusters.get('pairs') or {}).items():
            try:
                if inum(count, 0) < min_pair or '|' not in pair:
                    continue
                a, b = pair.split('|', 1)
                if a in self.queen_wallets and b not in self.queen_wallets:
                    self.adjacent_to_queen.add(b)
                if b in self.queen_wallets and a not in self.queen_wallets:
                    self.adjacent_to_queen.add(a)
            except Exception:
                continue

    def role_for_wallet(self, wallet: str) -> str:
        rep = (self.wallet_rep.get('wallets') or {}).get(wallet, {}) if wallet else {}
        role = str(rep.get('role') or 'watch')
        if wallet in self.queen_wallets and role not in WORKER_ROLES:
            return 'queen_' + role if not role.startswith('queen_') else role
        if wallet in self.worker_wallets:
            return 'worker_' + role if not role.startswith('worker_') else role
        if wallet in self.adjacent_to_queen:
            return 'queen_adjacent_worker'
        return role

    def wallet_scores(self, wallet: str) -> Dict[str, float]:
        rep = (self.wallet_rep.get('wallets') or {}).get(wallet, {}) if wallet else {}
        role = self.role_for_wallet(wallet)
        runner_hits = inum(rep.get('runner_hits'), 0)
        trap_hits = inum(rep.get('trap_hits'), 0)
        sold_high = inum(rep.get('sold_near_high'), 0)
        dumped = inum(rep.get('dumped'), 0)
        early = inum(rep.get('early_buys'), 0)
        base = fnum(rep.get('score'), 0.0)
        worker_score = base + runner_hits*1.2 + early*0.15 - trap_hits*1.3 - dumped*1.5
        queen_score = trap_hits*1.7 + sold_high*0.9 + dumped*2.2 + (25 if 'queen' in role or role in QUEEN_ROLES else 0)
        if role in ('queen_adjacent_worker',) or role.startswith('worker_'):
            worker_score += 12
        return {'worker_score': worker_score, 'queen_score': queen_score}

    def analyze_events(self, mint: str, events: List[Dict[str, Any]], write: bool = True) -> Dict[str, Any]:
        ts = now_ts()
        win = fnum(self.cfg.get('QUEEN_WORKER_WINDOW_SEC'), 20.0)
        recent = [e for e in (events or []) if ts - inum(e.get('ts'), ts) <= win]

        worker_buy_sol = worker_sell_sol = queen_buy_sol = queen_sell_sol = watch_buy_sol = 0.0
        worker_buys = worker_sells = queen_buys = queen_sells = watch_buys = watch_sells = 0
        worker_wallets: Set[str] = set()
        queen_wallets_seen: Set[str] = set()
        watch_wallets: Set[str] = set()
        last_role = 'unknown'; last_wallet = ''; last_side = ''
        worker_score_sum = queen_score_sum = 0.0

        # v11.2.18: soft_worker promotion — watch wallets with ≥ soft_worker_min_sol
        # are treated as workers when no real worker is buying.
        soft_worker_min_sol = fnum(self.cfg.get('SOFT_WORKER_MIN_SOL'), 0.3)
        watch_sol_accum: Dict[str, float] = {}

        for e in recent:
            w = e.get('wallet') or e.get('traderPublicKey') or ''
            side = str(e.get('side') or e.get('txType') or '').lower()
            sol = abs(fnum(e.get('sol') if e.get('sol') is not None else e.get('solAmount'), 0.0))
            role = self.role_for_wallet(w)
            scores = self.wallet_scores(w)
            if w:
                last_wallet = w; last_role = role; last_side = side
            is_queen = role in QUEEN_ROLES or role.startswith('queen_') or scores['queen_score'] >= fnum(self.cfg.get('QUEEN_EXIT_PRESSURE_SCORE'), 1.0)
            is_worker = role.startswith('worker_') or role == 'queen_adjacent_worker' or role in WORKER_ROLES or scores['worker_score'] >= fnum(self.cfg.get('QUEEN_WORKER_MIN_WORKER_SCORE'), 1.0)

            if side == 'buy':
                if is_worker and not is_queen:
                    worker_buys += 1; worker_buy_sol += sol; worker_wallets.add(w); worker_score_sum += scores['worker_score']
                elif is_queen:
                    queen_buys += 1; queen_buy_sol += sol; queen_wallets_seen.add(w); queen_score_sum += scores['queen_score']
                else:
                    watch_buys += 1; watch_buy_sol += sol; watch_wallets.add(w)
                    watch_sol_accum[w] = watch_sol_accum.get(w, 0.0) + sol
            elif side == 'sell':
                if is_queen:
                    queen_sells += 1; queen_sell_sol += sol; queen_wallets_seen.add(w); queen_score_sum += scores['queen_score']
                elif is_worker:
                    worker_sells += 1; worker_sell_sol += sol; worker_wallets.add(w); worker_score_sum += scores['worker_score']
                else:
                    watch_sells += 1; watch_wallets.add(w)

        # v11.2.18: promote high-sol watch wallets to soft_worker when no true worker buying
        soft_worker_buys = 0
        soft_worker_sol = 0.0
        if worker_buys == 0:
            for w, wsol in watch_sol_accum.items():
                if wsol >= soft_worker_min_sol:
                    soft_worker_buys += 1
                    soft_worker_sol += wsol

        effective_worker_buys = worker_buys + soft_worker_buys
        effective_worker_sol = worker_buy_sol + soft_worker_sol

        total_buy_sol = effective_worker_sol + queen_buy_sol + (watch_buy_sol - soft_worker_sol)
        total_sell_sol = worker_sell_sol + queen_sell_sol
        net_worker_sol = effective_worker_sol - worker_sell_sol
        net_hive_sol = total_buy_sol - total_sell_sol
        sell_buy_ratio = total_sell_sol / max(0.000001, total_buy_sol)

        queen_exit_now = queen_sells > 0 and (
            self.cfg.get('QUEEN_EXIT_ANY_KNOWN_QUEEN_SELL', True) or
            queen_sell_sol >= fnum(self.cfg.get('QUEEN_EXIT_MIN_SELL_SOL'), 0.000001)
        )
        hive_flip_exit = sell_buy_ratio >= fnum(self.cfg.get('HIVE_FLIP_NET_SELL_RATIO'), 0.45) and total_sell_sol > 0

        # v11.2.18: worker_entry_ok uses effective (soft-promoted) worker counts
        worker_entry_ok = (
            effective_worker_buys >= inum(self.cfg.get('QUEEN_WORKER_MIN_FRESH_BUYS'), 2) and
            net_worker_sol >= fnum(self.cfg.get('QUEEN_WORKER_MIN_NET_BUY_SOL'), 0.0) and
            not queen_exit_now
        )
        worker_swarm_ok = (
            (effective_worker_buys + watch_buys) >= inum(self.cfg.get('WORKER_SWARM_MIN_BUYS'), 3) and
            len(worker_wallets | watch_wallets) >= inum(self.cfg.get('WORKER_SWARM_MIN_BUYERS'), 3) and
            net_hive_sol >= fnum(self.cfg.get('WORKER_SWARM_MIN_NET_BUY_SOL'), 0.0) and
            queen_sell_sol <= fnum(self.cfg.get('WORKER_SWARM_MAX_QUEEN_SELL_SOL'), 0.0)
        )

        # v11.2.18: watch_surge — high watch volume, no queen selling, clean
        watch_surge_min_sol = fnum(self.cfg.get('WATCH_SURGE_MIN_WATCH_SOL'), 1.5)
        watch_surge_min_buyers = inum(self.cfg.get('WATCH_SURGE_MIN_BUYERS'), 4)
        watch_surge_ok = (
            not queen_exit_now and
            queen_sell_sol == 0.0 and
            watch_buy_sol >= watch_surge_min_sol and
            len(watch_wallets) >= watch_surge_min_buyers and
            self.cfg.get('WATCH_SURGE_ENABLED', True)
        )

        # v11.2.18: queen_pre_exit_warning — queen just started buying (often precedes sell dump)
        prev_queen_sell = self._prev_queen_sell_sol.get(mint, 0.0)
        queen_pre_exit_warning = (
            not queen_exit_now and
            queen_buy_sol > fnum(self.cfg.get('QUEEN_PRE_EXIT_BUY_SOL_THRESHOLD'), 0.5) and
            queen_buys >= inum(self.cfg.get('QUEEN_PRE_EXIT_MIN_QUEEN_BUYS'), 1) and
            self.cfg.get('QUEEN_PRE_EXIT_WARNING_ENABLED', True)
        )
        self._prev_queen_sell_sol[mint] = queen_sell_sol

        # Determine hive state (priority order)
        if queen_exit_now:
            hive_state = 'queen_exit'
        elif hive_flip_exit:
            hive_state = 'hive_flip'
        elif worker_entry_ok:
            hive_state = 'worker_entry'
        elif worker_swarm_ok:
            hive_state = 'worker_swarm'
        elif watch_surge_ok:
            hive_state = 'watch_surge'
        else:
            hive_state = 'watch'

        # v11.2.18: update pattern memory and get winning counter score
        self.pattern_memory.record(mint, hive_state, watch_buy_sol, queen_exit_now)
        winning_counter_score = self.pattern_memory.winning_counter_score(mint, hive_state)
        is_late_queen_entry = self.pattern_memory.is_late_queen_entry(mint)

        out = {
            'ts': ts, 'mint': mint, 'window_sec': win,
            'worker_buys': effective_worker_buys,
            'worker_buys_true': worker_buys,
            'soft_worker_buys': soft_worker_buys,
            'soft_worker_sol': round(soft_worker_sol, 9),
            'worker_sells': worker_sells,
            'queen_buys': queen_buys, 'queen_sells': queen_sells,
            'watch_buys': watch_buys, 'watch_sells': watch_sells,
            'worker_buy_sol': round(effective_worker_sol, 9),
            'worker_sell_sol': round(worker_sell_sol, 9),
            'queen_buy_sol': round(queen_buy_sol, 9),
            'queen_sell_sol': round(queen_sell_sol, 9),
            'watch_buy_sol': round(watch_buy_sol - soft_worker_sol, 9),
            'net_worker_sol': round(net_worker_sol, 9),
            'net_hive_sol': round(net_hive_sol, 9),
            'sell_buy_sol_ratio': round(sell_buy_ratio, 6),
            'worker_wallets': list(worker_wallets)[:20],
            'queen_wallets': list(queen_wallets_seen)[:20],
            'watch_wallets': list(watch_wallets)[:20],
            'last_wallet': last_wallet, 'last_wallet_role': last_role, 'last_side': last_side,
            'worker_score_sum': round(worker_score_sum, 3),
            'queen_score_sum': round(queen_score_sum, 3),
            'worker_entry_ok': worker_entry_ok,
            'worker_swarm_ok': worker_swarm_ok,
            'watch_surge_ok': watch_surge_ok,
            'queen_exit_now': queen_exit_now,
            'hive_flip_exit': hive_flip_exit,
            'queen_pre_exit_warning': queen_pre_exit_warning,
            'hive_state': hive_state,
            # v11.2.18 pattern signals
            'winning_counter_score': round(winning_counter_score, 3),
            'is_late_queen_entry': is_late_queen_entry,
        }
        if write:
            append_jsonl(self.decisions_file, out)
            try:
                state = load_json(self.state_file, {'mints': {}}) or {'mints': {}}
                state.setdefault('mints', {})[mint] = out
                state['updated_ts'] = ts
                save_json(self.state_file, state)
            except Exception:
                pass
        return out
