from __future__ import annotations
import json, csv
from pathlib import Path
from collections import defaultdict

path = Path('buy_sell_only.jsonl')
rows=[]
if path.exists():
    for line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        try:
            e=json.loads(line)
            if isinstance(e,dict): rows.append(e)
        except Exception: pass

by_wallet=defaultdict(lambda:{'buys':0,'sells':0,'buy_sol':0.0,'sell_sol':0.0,'mints':set(),'last_ts':0})
by_mint=defaultdict(lambda:{'buys':0,'sells':0,'buy_sol':0.0,'sell_sol':0.0,'wallets':set(),'last_ts':0})
for e in rows:
    side=str(e.get('side') or '').lower(); w=str(e.get('wallet') or ''); m=str(e.get('mint') or ''); sol=float(e.get('sol') or 0); ts=int(float(e.get('ts') or 0))
    if side not in ('buy','sell'): continue
    bw=by_wallet[w]; bm=by_mint[m]
    bw['mints'].add(m); bw['last_ts']=max(bw['last_ts'],ts)
    bm['wallets'].add(w); bm['last_ts']=max(bm['last_ts'],ts)
    if side=='buy':
        bw['buys']+=1; bw['buy_sol']+=sol; bm['buys']+=1; bm['buy_sol']+=sol
    else:
        bw['sells']+=1; bw['sell_sol']+=sol; bm['sells']+=1; bm['sell_sol']+=sol

def write_csv(p, headers, records):
    with open(p,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=headers); w.writeheader(); w.writerows(records)
wallet_records=[]
for w,s in by_wallet.items():
    wallet_records.append({'wallet':w,'buys':s['buys'],'sells':s['sells'],'buy_sol':round(s['buy_sol'],9),'sell_sol':round(s['sell_sol'],9),'sell_buy_ratio':round(s['sell_sol']/max(s['buy_sol'],1e-9),4),'mints':len(s['mints']),'last_ts':s['last_ts']})
wallet_records.sort(key=lambda r:(r['last_ts'], r['buy_sol']), reverse=True)
mint_records=[]
for m,s in by_mint.items():
    mint_records.append({'mint':m,'buys':s['buys'],'sells':s['sells'],'buy_sol':round(s['buy_sol'],9),'sell_sol':round(s['sell_sol'],9),'sell_buy_ratio':round(s['sell_sol']/max(s['buy_sol'],1e-9),4),'wallets':len(s['wallets']),'last_ts':s['last_ts']})
mint_records.sort(key=lambda r:(r['last_ts'], r['buy_sol']), reverse=True)
write_csv('buy_sell_wallet_summary.csv', ['wallet','buys','sells','buy_sol','sell_sol','sell_buy_ratio','mints','last_ts'], wallet_records)
write_csv('buy_sell_mint_summary.csv', ['mint','buys','sells','buy_sol','sell_sol','sell_buy_ratio','wallets','last_ts'], mint_records)
print(f'events={len(rows)} wallets={len(wallet_records)} mints={len(mint_records)}')
print('wrote buy_sell_wallet_summary.csv and buy_sell_mint_summary.csv')
