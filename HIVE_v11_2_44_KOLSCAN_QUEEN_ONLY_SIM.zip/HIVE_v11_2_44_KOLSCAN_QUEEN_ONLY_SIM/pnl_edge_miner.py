#!/usr/bin/env python3
"""Mine SIM trades for filters that survive fee drag.

Reads position_lifecycle.jsonl + pressure_runner_lift_candidates.jsonl and writes:
- PNL_EDGE_REPORT.json
- PNL_EDGE_CONFIG_PATCH.json

Run: python pnl_edge_miner.py
"""
from __future__ import annotations
import json, itertools, collections, statistics, os, time
from typing import Any, Dict, List

LIFECYCLE = "position_lifecycle.jsonl"
CANDIDATES = "pressure_runner_lift_candidates.jsonl"
OUT_REPORT = "PNL_EDGE_REPORT.json"
OUT_PATCH = "PNL_EDGE_CONFIG_PATCH.json"

def load_jsonl(path: str) -> List[Dict[str, Any]]:
    rows=[]
    if not os.path.exists(path):
        return rows
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except Exception:
                pass
    return rows

def pair_trades(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    open_by=collections.defaultdict(list)
    out=[]
    for r in rows:
        if r.get("event") == "paper_buy":
            open_by[r.get("mint")].append(r)
        elif r.get("event") == "paper_sell":
            mint=r.get("mint")
            buy=open_by.get(mint, [])[:1]
            if buy:
                b=open_by[mint].pop(0)
                out.append({
                    "mint": mint,
                    "buy_ts": b.get("ts"),
                    "sell_ts": r.get("ts"),
                    "hold_sec": (r.get("ts") or 0) - (b.get("ts") or 0),
                    "setup": b.get("setup") or r.get("setup"),
                    "score": float(b.get("score") or 0),
                    "buy_mc": float(b.get("mc") or 0),
                    "sell_mc": float(r.get("mc") or 0),
                    "exit_reason": r.get("reason"),
                    "gross_pnl_pct": float(r.get("gross_pnl_pct") or 0),
                    "net_pnl_pct": float(r.get("pnl_pct") or 0),
                    "pnl_sol": float(r.get("pnl_sol") or 0),
                })
    return out

def attach_features(trades: List[Dict[str, Any]], candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by=collections.defaultdict(list)
    for c in candidates:
        if c.get("mint"):
            by[c["mint"]].append(c)
    for mint in by:
        by[mint].sort(key=lambda x: x.get("ts") or 0)
    out=[]
    for t in trades:
        opts=[c for c in by.get(t["mint"], []) if (c.get("ts") or 0) <= (t.get("buy_ts") or 0)] or by.get(t["mint"], [])[:1]
        c=opts[-1] if opts else {}
        f=c.get("features") or {}
        ws=c.get("wallet_summary") or {}
        row=dict(t)
        for k in ("recent_buys","recent_buyers","recent_sells","buy_sol_recent","sell_sol_recent","sell_pressure","total_sell_buy_ratio","last_event_sol","last_event_age_sec"):
            row[k]=float(f.get(k) or 0)
        for k in ("top_net_buy_sol","top_buy_sol","danger_count","dump_risk_count","sell_near_high_count","sell_only_count","alpha_count","accumulator_count"):
            row[k]=float(ws.get(k) or 0)
        row["pumpfun_mint"] = str(t.get("mint") or "").endswith("pump")
        out.append(row)
    return out

def eval_filter(rows, filt):
    selected=[]
    for x in rows:
        if not x.get("pumpfun_mint") and filt.get("require_pumpfun", True): continue
        if x["score"] < filt["min_score"]: continue
        if x["recent_buys"] < filt["min_recent_buys"]: continue
        if x["recent_buyers"] < filt["min_recent_buyers"]: continue
        if x["buy_sol_recent"] < filt["min_buy_sol_recent"]: continue
        if x["buy_sol_recent"] > filt["max_buy_sol_recent"]: continue
        if x["last_event_sol"] > filt["max_last_event_sol"]: continue
        if x["sell_pressure"] > filt["max_sell_pressure"]: continue
        if x["total_sell_buy_ratio"] > filt["max_sell_buy_ratio"]: continue
        if x["top_net_buy_sol"] < filt["min_top_net_buy_sol"]: continue
        if x["danger_count"] > filt["max_danger_count"]: continue
        if x["dump_risk_count"] > filt["max_dump_risk_count"]: continue
        selected.append(x)
    if not selected:
        return None
    return {
        "samples": len(selected),
        "wins": sum(1 for x in selected if x["net_pnl_pct"] > 0),
        "win_rate": round(sum(1 for x in selected if x["net_pnl_pct"] > 0) / len(selected), 4),
        "avg_net_pct": round(statistics.mean(x["net_pnl_pct"] for x in selected), 6),
        "median_net_pct": round(statistics.median(x["net_pnl_pct"] for x in selected), 6),
        "sum_pnl_sol": round(sum(x["pnl_sol"] for x in selected), 9),
        "selected": [{"mint": x["mint"], "net_pct": round(x["net_pnl_pct"], 4), "exit": x["exit_reason"], "hold_sec": x["hold_sec"]} for x in selected[:25]],
        "filter": filt,
    }

def main():
    rows=load_jsonl(LIFECYCLE)
    candidates=load_jsonl(CANDIDATES)
    trades=attach_features(pair_trades(rows), candidates)
    base={
        "generated_ts": int(time.time()),
        "trade_count": len(trades),
        "overall": {
            "wins": sum(1 for x in trades if x["net_pnl_pct"] > 0),
            "win_rate": round((sum(1 for x in trades if x["net_pnl_pct"] > 0) / len(trades)) if trades else 0, 4),
            "avg_net_pct": round(statistics.mean([x["net_pnl_pct"] for x in trades]) if trades else 0, 6),
            "sum_pnl_sol": round(sum(x["pnl_sol"] for x in trades), 9),
        },
    }
    grid=[]
    for vals in itertools.product(
        [700, 850, 900, 1000],       # min_score
        [12, 18, 24, 30],            # recent_buys
        [10, 12, 18, 25],            # recent_buyers
        [8.0, 10.0, 15.0, 25.0],     # buy_sol_recent min
        [0.20, 0.28, 0.35, 0.45],    # sell_pressure max
        [0.35, 0.55, 0.65, 0.85],    # sell_buy ratio max
        [1.0, 3.0, 5.0, 8.0],        # top_net_buy min
    ):
        filt={
            "require_pumpfun": True,
            "min_score": vals[0], "min_recent_buys": vals[1], "min_recent_buyers": vals[2],
            "min_buy_sol_recent": vals[3], "max_buy_sol_recent": 75.0, "max_last_event_sol": 5.0,
            "max_sell_pressure": vals[4], "max_sell_buy_ratio": vals[5], "min_top_net_buy_sol": vals[6],
            "max_danger_count": 0, "max_dump_risk_count": 0,
        }
        r=eval_filter(trades, filt)
        if r:
            # prioritize positive expectancy first, then win rate, then sample size
            grid.append(r)
    grid.sort(key=lambda r: (r["sum_pnl_sol"], r["avg_net_pct"], r["win_rate"], r["samples"]), reverse=True)
    recommended_patch={
        "PNL_REQUIRE_PUMPFUN_MINT": True,
        "PNL_MAX_LAST_EVENT_SOL": 5.0,
        "PNL_MAX_RECENT_BUY_SOL": 75.0,
        "PNL_MIN_MC_SOL": 15.0,
        "PNL_MAX_MC_SOL": 250000.0,
        "MIN_ENTRY_SCORE": 900.0,
        "PRESSURE_RUNNER_MIN_SCORE": 900.0,
        "PRESSURE_RUNNER_MIN_RECENT_BUYS": 18,
        "PRESSURE_RUNNER_MIN_RECENT_BUYERS": 12,
        "PRESSURE_RUNNER_MIN_BUY_SOL_RECENT": 15.0,
        "PRESSURE_RUNNER_MAX_SELL_PRESSURE": 0.30,
        "PRESSURE_RUNNER_MAX_SELL_BUY_RATIO": 0.55,
        "PRESSURE_RUNNER_MIN_TOP_NET_BUY_SOL": 5.0,
        "PRESSURE_RUNNER_MAX_DANGER_WALLETS": 0,
        "PRESSURE_RUNNER_MAX_DUMP_RISK_WALLETS": 0,
        "TRAIL_ACTIVATION_PCT": 0.075,
        "RUNNER_TRAIL_PCT": 0.028,
        "ATH_DROP_EXIT_ENABLED": True,
        "ATH_DROP_EXIT_PCT": 0.025,
        "PROFIT_MINT_COOLDOWN_SEC": 900,
        "LOSS_MINT_COOLDOWN_SEC": 1200,
        "SAME_MINT_LOSS_BLOCK_SEC": 1800,
        "MAX_ENTRIES_PER_MINT_PER_RUN": 1,
        "PRESSURE_RUNNER_REQUIRE_PRIORITY_CONFIRM": True,
        "PRESSURE_RUNNER_CONFIRM_MODE": "priority_or_extreme_flow",
        "HOT_PLAY_MAX_SELL_BUY_RATIO": 0.32,
        "HOT_PLAY_MIN_RECENT_BUY_SOL": 0.65,
        "HOT_PLAY_MIN_RECENT_BUYERS": 5,
        "HOT_PLAY_MAX_TOKEN_AGE_SEC": 720,
        "FAST_SNIPER_IDEAL_NET_PCT": 0.05,
    }
    report={**base, "top_filters": grid[:20], "recommended_config_patch": recommended_patch, "note": "Small sample. Use this as a filter miner each SIM run; do not trust old wallet ranks without fresh positive samples."}
    with open(OUT_REPORT,"w") as f: json.dump(report,f,indent=2)
    with open(OUT_PATCH,"w") as f: json.dump(recommended_patch,f,indent=2)
    print(json.dumps(report, indent=2)[:5000])

if __name__ == "__main__":
    main()
