#!/usr/bin/env python3
import json, time
from pathlib import Path
BAD_ROLES={"dump_risk","sell_near_high","sell_only","flipper"}
GOOD_ROLES={"alpha","accumulator","watch"}
def fnum(x,d=0.0):
    try: return float(x)
    except Exception: return d
def inum(x,d=0):
    try: return int(float(x))
    except Exception: return d
def load(path, default):
    p=Path(path)
    if not p.exists(): return default
    try: return json.loads(p.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save(path, obj): Path(path).write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")
def main():
    cfg=load("config.json", {})
    swarm=load(cfg.get("SWARM_EDGE_PROFILE_FILE","swarm_edge_profiles.json"), {})
    rep=load(cfg.get("WALLET_REPUTATION_FILE","wallet_reputation.json"), {"wallets":{}}).get("wallets", {})
    min_wr=fnum(cfg.get("VETTED_COPY_MIN_WIN_RATE"), .78); min_samples=inum(cfg.get("VETTED_COPY_MIN_SAMPLES"), 5)
    min_edge=fnum(cfg.get("VETTED_COPY_MIN_EDGE_PCT"), .015); max_dd=fnum(cfg.get("VETTED_COPY_MAX_AVG_DD_PCT"), -.35)
    max_age=fnum(cfg.get("VETTED_COPY_MAX_PROFILE_AGE_SEC"), 86400.0); now=time.time()
    entries=[]; exits=[]; rejected=[]
    for prof in swarm.get("copy_buy_wallets", []) or []:
        w=prof.get("wallet")
        if not w: continue
        role=str((rep.get(w) or {}).get("role") or "watch")
        row={"wallet":w,"role":role,"samples":inum(prof.get("samples") or prof.get("buy_count"),0),"win_rate":fnum(prof.get("win_rate"),0),"fee_adjusted_edge_pct":fnum(prof.get("fee_adjusted_edge_pct"),0),"avg_max_dd_pct":fnum(prof.get("avg_max_dd_pct"),0),"last_seen_age_sec":fnum(prof.get("last_seen_age_sec"), max(0, now-fnum(prof.get("last_seen_ts"), now))),"source":"swarm_copy_wallets"}
        reasons=[]
        if role in BAD_ROLES: reasons.append("bad_role_"+role)
        if role not in GOOD_ROLES: reasons.append("not_entry_role_"+role)
        if row["samples"] < min_samples: reasons.append("samples_lt_min")
        if row["win_rate"] < min_wr: reasons.append("wr_lt_min")
        if row["fee_adjusted_edge_pct"] < min_edge: reasons.append("edge_lt_min")
        if row["avg_max_dd_pct"] < max_dd: reasons.append("dd_lt_max_loss")
        if row["last_seen_age_sec"] > max_age: reasons.append("profile_stale")
        if reasons:
            row["reject_reason"]=reasons; rejected.append(row)
            if role in BAD_ROLES: exits.append({**row,"exit_reason":"bad_reputation_role"})
        else: entries.append(row)
    for prof in swarm.get("exit_warning_wallets", []) or []:
        w=prof.get("wallet")
        if not w: continue
        role=str((rep.get(w) or {}).get("role") or "watch")
        if role in BAD_ROLES or fnum(prof.get("drop_rate_after_sell"),0) >= fnum(cfg.get("VETTED_EXIT_MIN_DROP_RATE"), .60):
            exits.append({"wallet":w,"role":role,"samples":inum(prof.get("samples"),0),"drop_rate_after_sell":fnum(prof.get("drop_rate_after_sell"),0),"source":"swarm_exit_wallets","exit_reason":"sell_warning_profile"})
    e_by={r["wallet"]:r for r in entries}; x_by={r["wallet"]:r for r in exits}
    for w in list(x_by):
        if w in e_by and x_by[w].get("role") in BAD_ROLES: e_by.pop(w,None)
    entries=sorted(e_by.values(), key=lambda r:(fnum(r.get("win_rate")), inum(r.get("samples")), fnum(r.get("fee_adjusted_edge_pct"))), reverse=True)
    exits=sorted(x_by.values(), key=lambda r:(inum(r.get("samples")), fnum(r.get("drop_rate_after_sell"))), reverse=True)
    report={"ts":now,"entry_wallet_count":len(entries),"exit_wallet_count":len(exits),"rejected_count":len(rejected),"entry_wallets":entries,"exit_only_wallets":exits,"rejected_entry_wallets":rejected[:250]}
    save(cfg.get("VETTED_WALLET_REPORT_FILE","VETTED_WALLET_REPORT.json"), report)
    Path(cfg.get("VETTED_WALLET_TEXT_FILE","VETTED_WALLETS.txt")).write_text("ENTRY-APPROVED COPY WALLETS\n"+"\n".join([f"{r['wallet']} role={r['role']} wr={r['win_rate']:.2f} samples={r['samples']} edge={r['fee_adjusted_edge_pct']:.3f}" for r in entries])+"\n\nEXIT-ONLY / DANGER WALLETS\n"+"\n".join([f"{r['wallet']} role={r['role']} samples={r.get('samples',0)} reason={r.get('exit_reason')}" for r in exits]), encoding="utf-8")
    save("VETTED_WSS_SIGNAL_WALLETS.json", {"entry_wallets":[r["wallet"] for r in entries], "exit_wallets":[r["wallet"] for r in exits], "combined_watchlist": list(dict.fromkeys([r["wallet"] for r in entries+exits]))})
    print(f"Wrote {len(entries)} entry wallets and {len(exits)} exit-only wallets")
if __name__ == "__main__": main()
