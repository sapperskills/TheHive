# HIVE v11.2.44 — KOLSCAN + QUEEN ONLY PATCH

## Source: kolscan.io/leaderboard (scraped 2026-05-10)

### Kolscan wallets injected
- 50 top leaderboard wallets added to WSS_SIGNAL_WALLETS
- 50 wallets seeded into FOLLOW_MONEY_WATCHLIST.json + .txt
- Top 10 added to controller_watch_list.json for priority monitoring

### Config fixes from trade data analysis (35 trades, v43 run)
| Change | Was | Now | Reason |
|--------|-----|-----|--------|
| EARLY_DUMP_MIN_AGE_SEC | 0.0 | 8.0 | Dump stop fired at 0-2s, before fast sniper could hit +10% |
| EARLY_DUMP_STOP_PCT | -0.05 | -0.08 | Pumpfun entry slippage 3-5% was triggering -5% stop on entry |
| LIVE_TRACKED_WALLET_BUY re-enabled | disabled | enabled (strict) | Re-enabled but with kolscan wallets and much tighter filters |
| LIVE_TRACKED_WALLET_BUY_MIN_SCORE | 25 | 80 | Raise bar — previous lane had 9% win rate |
| LIVE_TRACKED_WALLET_BUY_MAX_SELL_BUY_RATIO | 1.25 | 0.65 | Tighter entry filter |
| LIVE_TRACKED_WALLET_BUY_MAX_SELL_PRESSURE | 0.55 | 0.35 | Tighter entry filter |
| LIVE_TRACKED_WALLET_BUY_MIN_TOP_NET_BUY_SOL | 0.05 | 0.25 | Needs real conviction |
| EARLY_CREATION_SNIPE_ENABLED | true | false | 0% win rate, -16% avg |
| QUEEN_EXIT_MIN_POSITION_AGE_SEC | 0.0 | 5.0 | Queen exits at 0s cut fast sniper holds short |
| STRICT_EDGE_REQUIRE_FRESH_BUY | (unset) | false | Still blocking with strict_edge_not_fresh_buy |
| WSS_NO_MESSAGE_RECONNECT_SEC | 45 | 30 | 191 WSS errors in last run |
| WSS_PING_INTERVAL_SEC | 30 | 20 | Detect dead feed faster |

### Carried from v43
- FRESH_INCOMING_BUY_ONLY: false
- STRICT_EDGE_MAX_RUG_RISK: 35.0
- STRICT_EDGE_MIN_WALLET_SCORE: 25.0
- MAX_SELL_BUY_RATIO: 1.0

### What to watch for
- fast_sniper_fee_safe_ideal_profit_exit: was 100% win rate — protect this
- early_dump_stop: should now fire AFTER 8s, not at 0-2s
- live_tracked_wallet_buy: kolscan wallets only — watch if win rate improves vs previous 9%

### Run
python main.py --mode sim --config config.json
