@echo off
cd /d %~dp0
python follow_money_graph.py --config config.json
python build_vetted_wallet_watchlist.py
pause
