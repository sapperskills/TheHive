from __future__ import annotations
"""
LIVE MONEY FLOW RANKER - v11.2.36 WR PATCH

Dashboard-only intelligence builder. It turns fresh SIM/WSS tape into:
  - HOT_SIM_PLAYS.json
  - RECENT_PROFIT_WALLETS.json
  - SIM_BEST_COPY_CALLS.json-compatible current-run calls

This file does not place orders. It deliberately favors higher win-rate/stability
signals over raw trade count: fresh buy consensus, low sell pressure, no severe
high drawdown, recent event freshness, and forward SIM replay evidence.
"""
import json, statistics, time
from collections import defaultdict, Counter
from pathlib import Path
from typing import Any, Dict, List, Tuple

from util import fnum, inum, iter_jsonl, save_json, now_ts

DEFAULT_HOT_PLAYS_FILE = 'HOT_SIM_PLAYS.json'
DEFAULT_RECENT_WALLETS_FILE = 'RECENT_PROFIT_WALLETS.json'
DEFAULT_WIN_RATE_FILE = 'WIN_RATE_OPTIMIZER_REPORT.json'


def _event_ts(e: Dict[str, Any]) -> int:
    return inum(e.get('ts') if e.get('ts') is not None else e.get('raw_ts'), 0)

def _event_side(e: Dict[str, Any]) -> str:
    return str(e.get('side') or e.get('txType') or '').lower().strip()

def _event_wallet(e: Dict[str, Any]) -> str:
    return str(e.get('wallet') or e.get('traderPublicKey') or '').strip()

def _event_sol(e: Dict[str, Any], cfg: Dict[str, Any] | None = None) -> float:
    cfg = cfg or {}
    sol = fnum(e.get('sol') if e.get('sol') is not None else e.get('solAmount'), 0.0)
    cap = fnum(cfg.get('RANKER_MAX_SINGLE_EVENT_SOL'), 5.0)
    if sol < 0:
        return 0.0
    return min(sol, cap) if cap > 0 else sol

def _event_mc(e: Dict[str, Any]) -> float:
    return fnum(e.get('mc') if e.get('mc') is not None else e.get('marketCapSol'), 0.0)

def load_tape(path: str = 'live_wallet_events.jsonl', max_events: int = 300000, cfg: Dict[str, Any] | None = None) -> Tuple[Dict[str, List[Dict[str, Any]]], int, int, int]:
    p = Path(path)
    if not p.exists():
        return {}, 0, 0, 0
    raw: List[Dict[str, Any]] = []
    for e in iter_jsonl(p):
        mint = str(e.get('mint') or '').strip()
        wallet = _event_wallet(e)
        side = _event_side(e)
        ts = _event_ts(e)
        mc = _event_mc(e)
        if not mint or not wallet or side not in ('buy', 'sell') or ts <= 0 or mc <= 0:
            continue
        raw.append({'ts': ts, 'mint': mint, 'wallet': wallet, 'side': side, 'sol': _event_sol(e, cfg), 'mc': mc})
    if max_events and len(raw) > max_events:
        raw = raw[-max_events:]
    by_mint: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    min_ts = 0; max_ts = 0
    for e in raw:
        by_mint[e['mint']].append(e)
        min_ts = e['ts'] if not min_ts else min(min_ts, e['ts'])
        max_ts = max(max_ts, e['ts'])
    for evs in by_mint.values():
        evs.sort(key=lambda x: (x['ts'], 0 if x['side'] == 'sell' else 1))
    return dict(by_mint), min_ts, max_ts, len(raw)


def _load_json(path: str, default: Any) -> Any:
    try:
        p = Path(path)
        if p.exists():
            return json.loads(p.read_text(encoding='utf-8'))
    except Exception:
        pass
    return default


def _profile_maps() -> Tuple[Dict[str, Dict[str, Any]], set[str], set[str]]:
    swarm = _load_json('swarm_edge_profiles.json', {}) or {}
    pred = _load_json('wallet_predator_profiles.json', {}) or {}
    good: Dict[str, Dict[str, Any]] = {}
    for w in swarm.get('copy_buy_wallets') or []:
        if isinstance(w, dict) and w.get('wallet'):
            good[str(w['wallet'])] = w
    for w in pred.get('top_wallets') or []:
        if isinstance(w, dict) and w.get('wallet'):
            row = good.setdefault(str(w['wallet']), {'wallet': str(w['wallet'])})
            row.setdefault('win_rate', w.get('win_rate'))
            row.setdefault('fee_adjusted_edge_pct', w.get('pnl_edge_pct'))
            row.setdefault('samples', w.get('samples') or w.get('trades'))
    exit_warn = {str(w.get('wallet')) for w in swarm.get('exit_warning_wallets') or [] if isinstance(w, dict) and w.get('wallet')}
    cycle = {str(w.get('wallet')) for w in swarm.get('cycle_wallets') or [] if isinstance(w, dict) and w.get('wallet') and fnum(w.get('net_sol'), 0.0) > 0}
    return good, exit_warn, cycle


def _recent_features(evs: List[Dict[str, Any]], anchor: int, window: float) -> Dict[str, Any]:
    recent = [x for x in evs if 0 <= anchor - x['ts'] <= window]
    buys = [x for x in recent if x['side'] == 'buy']
    sells = [x for x in recent if x['side'] == 'sell']
    buy_sol = sum(x['sol'] for x in buys)
    sell_sol = sum(x['sol'] for x in sells)
    ratio = sell_sol / max(0.000001, buy_sol)
    return {
        'events': recent, 'buys': buys, 'sells': sells,
        'buy_sol': buy_sol, 'sell_sol': sell_sol, 'ratio': ratio,
        'buyers': {x['wallet'] for x in buys}, 'sellers': {x['wallet'] for x in sells},
        'last_side': recent[-1]['side'] if recent else None,
        'last_ts': recent[-1]['ts'] if recent else None,
    }


def replay_filter_stats(cfg: Dict[str, Any], by_mint: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:
    """Fast forward replay used only to estimate which filters improve win rate.

    It samples recent buy prints instead of doing a full exhaustive backtest, so the
    dashboard can refresh even with very large WSS tapes.
    """
    recent_window = fnum(cfg.get('HOT_PLAY_RECENT_WINDOW_SEC'), 180.0)
    horizon = fnum(cfg.get('WIN_RATE_REPLAY_HORIZON_SEC'), 150.0)
    target = fnum(cfg.get('WIN_RATE_REPLAY_TARGET_PCT'), 0.055)
    stop = fnum(cfg.get('WIN_RATE_REPLAY_STOP_PCT'), -0.12)
    max_candidates = inum(cfg.get('WIN_RATE_REPLAY_MAX_CANDIDATES'), 6500)
    max_buy_events_per_mint = inum(cfg.get('WIN_RATE_REPLAY_MAX_BUYS_PER_MINT'), 80)
    filters = {
        'current_config': {
            'min_age': fnum(cfg.get('HOT_PLAY_MIN_TOKEN_AGE_SEC'), 12),
            'max_age': fnum(cfg.get('HOT_PLAY_MAX_TOKEN_AGE_SEC'), 2400),
            'min_buy_sol': fnum(cfg.get('HOT_PLAY_MIN_RECENT_BUY_SOL'), 0.35),
            'min_buyers': inum(cfg.get('HOT_PLAY_MIN_RECENT_BUYERS'), 3),
            'max_ratio': fnum(cfg.get('HOT_PLAY_MAX_SELL_BUY_RATIO'), 0.72),
            'max_dd': fnum(cfg.get('HOT_PLAY_MAX_DRAWDOWN_FROM_HIGH_PCT'), 0.38),
        },
        'higher_win_rate': {
            'min_age': fnum(cfg.get('WR_HOT_PLAY_MIN_TOKEN_AGE_SEC'), 25),
            'max_age': fnum(cfg.get('WR_HOT_PLAY_MAX_TOKEN_AGE_SEC'), 900),
            'min_buy_sol': fnum(cfg.get('WR_HOT_PLAY_MIN_RECENT_BUY_SOL'), 0.45),
            'min_buyers': inum(cfg.get('WR_HOT_PLAY_MIN_RECENT_BUYERS'), 4),
            'max_ratio': fnum(cfg.get('WR_HOT_PLAY_MAX_SELL_BUY_RATIO'), 0.45),
            'max_dd': fnum(cfg.get('WR_HOT_PLAY_MAX_DRAWDOWN_FROM_HIGH_PCT'), 0.28),
        },
        'very_strict': {'min_age': 35, 'max_age': 720, 'min_buy_sol': 0.65, 'min_buyers': 5, 'max_ratio': 0.32, 'max_dd': 0.22},
    }
    stats: Dict[str, Dict[str, Any]] = {k: {'samples': 0, 'wins': 0, 'losses': 0, 'avg_max_gain_pct': 0.0, 'avg_end_pct': 0.0, 'mints': set()} for k in filters}
    candidates_seen = 0
    # Prioritize recent/high-activity mints.
    mint_items = sorted(by_mint.items(), key=lambda kv: (kv[1][-1]['ts'] if kv[1] else 0, len(kv[1])), reverse=True)
    for mint, evs in mint_items:
        if candidates_seen >= max_candidates:
            break
        if len(evs) < 4:
            continue
        first_ts = evs[0]['ts']
        buys_idx = [i for i, x in enumerate(evs[:-1]) if x['side'] == 'buy'][-max_buy_events_per_mint:]
        # Prefix high by index for cheap drawdown.
        prefix_high = []
        h = 0.0
        for x in evs:
            h = max(h, x['mc']); prefix_high.append(h)
        for idx in buys_idx:
            if candidates_seen >= max_candidates:
                break
            e = evs[idx]
            age = e['ts'] - first_ts
            if age < 5 or e['mc'] <= 0:
                continue
            feat = _recent_features(evs[:idx+1], e['ts'], recent_window)
            if not feat['buys']:
                continue
            dd = 0.0 if prefix_high[idx] <= 0 else max(0.0, 1.0 - e['mc'] / prefix_high[idx])
            max_gain = -999.0; min_gain = 999.0; end_gain = 0.0; found_future = False
            for x in evs[idx+1:]:
                dt = x['ts'] - e['ts']
                if dt <= 0:
                    continue
                if dt > horizon:
                    break
                g = x['mc'] / e['mc'] - 1.0
                max_gain = max(max_gain, g); min_gain = min(min_gain, g); end_gain = g; found_future = True
            if not found_future:
                continue
            candidates_seen += 1
            win = (max_gain >= target) and (min_gain > stop)
            for name, flt in filters.items():
                if not (flt['min_age'] <= age <= flt['max_age']): continue
                if feat['buy_sol'] < flt['min_buy_sol']: continue
                if len(feat['buyers']) < flt['min_buyers']: continue
                if feat['ratio'] > flt['max_ratio']: continue
                if dd > flt['max_dd']: continue
                if feat['last_side'] != 'buy': continue
                st = stats[name]
                st['samples'] += 1; st['wins'] += 1 if win else 0; st['losses'] += 0 if win else 1
                st['avg_max_gain_pct'] += max_gain; st['avg_end_pct'] += end_gain; st['mints'].add(mint)
    out: Dict[str, Any] = {}
    for name, st in stats.items():
        samples = max(1, st['samples'])
        out[name] = {
            'samples': st['samples'], 'wins': st['wins'], 'losses': st['losses'],
            'win_rate': round(st['wins'] / samples, 4) if st['samples'] else 0.0,
            'avg_max_gain_pct': round(st['avg_max_gain_pct'] / samples, 6) if st['samples'] else 0.0,
            'avg_end_pct': round(st['avg_end_pct'] / samples, 6) if st['samples'] else 0.0,
            'unique_mints': len(st['mints']), 'filter': filters[name],
        }
    out['_sampled_candidates'] = candidates_seen
    return out

def lifecycle_stats() -> Dict[str, Any]:
    by_setup: Dict[str, List[float]] = defaultdict(list)
    by_reason: Dict[str, List[float]] = defaultdict(list)
    p = Path('position_lifecycle.jsonl')
    if not p.exists():
        return {'sells': 0, 'overall_win_rate': 0.0, 'by_setup': {}, 'by_reason': {}}
    for r in iter_jsonl(p):
        ev = str(r.get('event') or '').lower()
        if 'sell' not in ev:
            continue
        if 'pnl_pct' not in r and 'net_pnl_pct' not in r:
            continue
        pnl = fnum(r.get('net_pnl_pct'), fnum(r.get('pnl_pct'), 0.0))
        by_setup[str(r.get('setup') or 'unknown')].append(pnl)
        by_reason[str(r.get('reason') or 'unknown')].append(pnl)
    vals = [v for arr in by_setup.values() for v in arr]
    def pack(vals: List[float]) -> Dict[str, Any]:
        return {'count': len(vals), 'win_rate': round(sum(1 for v in vals if v > 0) / max(1, len(vals)), 4), 'avg_pct': round(sum(vals) / max(1, len(vals)), 6), 'median_pct': round(statistics.median(vals), 6) if vals else 0.0}
    return {
        'sells': len(vals), 'overall_win_rate': round(sum(1 for v in vals if v > 0) / max(1, len(vals)), 4) if vals else 0.0,
        'by_setup': dict(sorted(((k, pack(v)) for k, v in by_setup.items()), key=lambda kv: kv[1]['count'], reverse=True)),
        'by_reason': dict(sorted(((k, pack(v)) for k, v in by_reason.items()), key=lambda kv: kv[1]['count'], reverse=True)),
    }


def rank_hot_plays(cfg: Dict[str, Any] | None = None) -> Dict[str, Any]:
    cfg = cfg or {}
    events_file = cfg.get('LIVE_WALLET_EVENTS_FILE', 'live_wallet_events.jsonl')
    by_mint, min_ts, max_ts, event_count = load_tape(events_file, inum(cfg.get('HOT_PLAY_MAX_EVENTS_READ'), 300000), cfg)
    good_wallets, exit_wallets, cycle_wallets = _profile_maps()

    recent_window = fnum(cfg.get('HOT_PLAY_RECENT_WINDOW_SEC'), 180.0)
    stable_window = fnum(cfg.get('HOT_PLAY_STABLE_WINDOW_SEC'), 900.0)
    max_token_age = fnum(cfg.get('HOT_PLAY_MAX_TOKEN_AGE_SEC'), 900.0)
    min_token_age = fnum(cfg.get('HOT_PLAY_MIN_TOKEN_AGE_SEC'), 25.0)
    stale_after = fnum(cfg.get('HOT_PLAY_STALE_AFTER_SEC'), 90.0)
    min_buy_sol = fnum(cfg.get('HOT_PLAY_MIN_RECENT_BUY_SOL'), 0.45)
    min_buyers = inum(cfg.get('HOT_PLAY_MIN_RECENT_BUYERS'), 4)
    max_sell_ratio = fnum(cfg.get('HOT_PLAY_MAX_SELL_BUY_RATIO'), 0.45)
    max_drawdown = fnum(cfg.get('HOT_PLAY_MAX_DRAWDOWN_FROM_HIGH_PCT'), 0.28)
    min_mc = fnum(cfg.get('HOT_PLAY_MIN_MC_SOL'), 20.0)
    max_mc = fnum(cfg.get('HOT_PLAY_MAX_MC_SOL'), 100000.0)
    max_rows = inum(cfg.get('HOT_PLAY_MAX_ROWS'), 60)
    require_last_buy = cfg.get('HOT_PLAY_REQUIRE_LAST_SIDE_BUY', True)
    min_last3_buys = inum(cfg.get('HOT_PLAY_MIN_LAST3_BUYS'), 2)
    max_recent_sells = inum(cfg.get('HOT_PLAY_MAX_RECENT_SELL_COUNT'), 4)

    plays: List[Dict[str, Any]] = []
    recent_wallet_rows: Dict[str, Dict[str, Any]] = {}

    for mint, evs in by_mint.items():
        if not evs:
            continue
        first_ts, last_ts = evs[0]['ts'], evs[-1]['ts']
        token_age = max(0, max_ts - first_ts)
        last_age = max(0, max_ts - last_ts)
        if token_age > max_token_age or last_age > stale_after:
            continue
        first_mc, last_mc = evs[0]['mc'], evs[-1]['mc']
        high_mc = max(x['mc'] for x in evs); low_mc = min(x['mc'] for x in evs)
        if last_mc < min_mc or last_mc > max_mc:
            continue
        drawdown = 0.0 if high_mc <= 0 else max(0.0, 1.0 - last_mc / high_mc)
        lift_from_open = 0.0 if first_mc <= 0 else last_mc / first_mc - 1.0
        recent = _recent_features(evs, max_ts, recent_window)
        stable = _recent_features(evs, max_ts, stable_window)
        if not recent['events']:
            continue
        recent_buys, recent_sells = recent['buys'], recent['sells']
        good_recent = [x for x in recent_buys if x['wallet'] in good_wallets]
        cycle_recent = [x for x in recent_buys if x['wallet'] in cycle_wallets]
        exit_recent = [x for x in recent_sells if x['wallet'] in exit_wallets]
        last3 = recent['events'][-3:]
        last3_buys = sum(1 for x in last3 if x['side'] == 'buy')

        stable_ok = (
            token_age >= min_token_age and
            recent['buy_sol'] >= min_buy_sol and
            len(recent['buyers']) >= min_buyers and
            recent['ratio'] <= max_sell_ratio and
            stable['ratio'] <= max(0.60, max_sell_ratio + 0.18) and
            drawdown <= max_drawdown and
            len(exit_recent) <= inum(cfg.get('HOT_PLAY_MAX_EXIT_WARN_SELLS'), 1) and
            len(recent_sells) <= max_recent_sells and
            last3_buys >= min_last3_buys and
            ((not require_last_buy) or recent['last_side'] == 'buy')
        )

        score = 0.0
        score += min(80.0, recent['buy_sol'] * 16.0)
        score += min(55.0, len(recent['buyers']) * 8.0)
        score += min(50.0, len(good_recent) * 16.0)
        score += min(32.0, len(cycle_recent) * 8.0)
        score += max(0.0, min(50.0, lift_from_open * 45.0))
        score += max(0.0, min(35.0, (1.0 - recent['ratio']) * 35.0))
        score += 12.0 if last3_buys >= 2 else -18.0
        score -= min(90.0, drawdown * 145.0)
        score -= min(70.0, len(exit_recent) * 22.0)
        score -= min(50.0, recent['ratio'] * 35.0)
        score -= 22.0 if recent['last_side'] != 'buy' else 0.0
        if 35 <= token_age <= 720:
            score += 22.0
        elif token_age < 20:
            score -= 25.0

        if stable_ok and score >= fnum(cfg.get('HOT_PLAY_BUY_SCORE'), 70.0):
            play_type = 'SIM_BUY_EARLY_CANDIDATE'
        elif score >= fnum(cfg.get('HOT_PLAY_WATCH_SCORE'), 48.0) and drawdown <= max(0.34, max_drawdown + 0.06) and recent['ratio'] <= max(0.62, max_sell_ratio + 0.17):
            play_type = 'WATCH_STABLE_FLOW'
        else:
            play_type = 'REJECT_WEAK_OR_DUMPY'

        for x in good_recent[-12:]:
            prof = good_wallets.get(x['wallet'], {})
            wr = fnum(prof.get('win_rate'), 0.0); edge = fnum(prof.get('fee_adjusted_edge_pct'), 0.0)
            row = recent_wallet_rows.setdefault(x['wallet'], {
                'wallet': x['wallet'], 'score': 0.0, 'recent_buy_count': 0, 'recent_buy_sol': 0.0,
                'mints': set(), 'last_seen_ts': 0, 'last_seen_age_sec': None,
                'profile_win_rate': wr, 'profile_edge_pct': edge, 'profile_samples': inum(prof.get('samples'), 0),
                'latest_mint': mint,
            })
            row['score'] += 40.0 + wr * 120.0 + edge * 250.0 + max(0.0, score * 0.25)
            row['recent_buy_count'] += 1; row['recent_buy_sol'] += x['sol']; row['mints'].add(mint)
            if x['ts'] >= row['last_seen_ts']:
                row['last_seen_ts'] = x['ts']; row['last_seen_age_sec'] = max(0, max_ts - x['ts']); row['latest_mint'] = mint

        reasons = []
        if recent['last_side'] == 'buy': reasons.append('last_print_buy')
        if last3_buys >= min_last3_buys: reasons.append(f'last3_buys={last3_buys}')
        reasons.append(f'recent_buy_sol={recent["buy_sol"]:.3f}')
        reasons.append(f'unique_buyers={len(recent["buyers"])}')
        reasons.append(f'sell_buy_ratio={recent["ratio"]:.2f}')
        reasons.append(f'drawdown={drawdown*100:.1f}%')
        if good_recent: reasons.append(f'profiled_wallet_buys={len(good_recent)}')
        if cycle_recent: reasons.append(f'positive_cycle_buys={len(cycle_recent)}')
        if exit_recent: reasons.append(f'exit_warning_sells={len(exit_recent)}')
        if not stable_ok: reasons.append('watch_only_until_cleaner_flow')

        plays.append({
            'mint': mint, 'play_type': play_type, 'score': round(score, 6), 'stable_ok': bool(stable_ok),
            'event_anchor_ts': max_ts, 'first_seen_ts': first_ts, 'last_seen_ts': last_ts,
            'token_age_sec': int(token_age), 'last_event_age_sec': int(last_age),
            'first_mc': round(first_mc, 6), 'last_mc': round(last_mc, 6), 'high_mc': round(high_mc, 6), 'low_mc': round(low_mc, 6),
            'lift_from_open_pct': round(lift_from_open, 6), 'drawdown_from_high_pct': round(drawdown, 6),
            'recent_buy_sol': round(recent['buy_sol'], 9), 'recent_sell_sol': round(recent['sell_sol'], 9), 'recent_sell_buy_ratio': round(recent['ratio'], 6),
            'stable_buy_sol': round(stable['buy_sol'], 9), 'stable_sell_sol': round(stable['sell_sol'], 9), 'stable_sell_buy_ratio': round(stable['ratio'], 6),
            'recent_buy_count': len(recent_buys), 'recent_sell_count': len(recent_sells), 'unique_recent_buyers': len(recent['buyers']), 'unique_recent_sellers': len(recent['sellers']),
            'profiled_wallet_buy_count': len(good_recent), 'positive_cycle_buy_count': len(cycle_recent), 'exit_warning_sell_count': len(exit_recent),
            'last_side': recent['last_side'], 'last3_buys': last3_buys,
            'top_recent_wallets': [{'wallet': w, 'buys': c} for w, c in Counter(x['wallet'] for x in recent_buys).most_common(10)],
            'top_profiled_wallets': [{'wallet': x['wallet'], 'sol': round(x['sol'], 9), 'ts': x['ts'], 'age_sec': max(0, max_ts - x['ts']), 'win_rate': good_wallets.get(x['wallet'], {}).get('win_rate'), 'edge_pct': good_wallets.get(x['wallet'], {}).get('fee_adjusted_edge_pct'), 'samples': good_wallets.get(x['wallet'], {}).get('samples')} for x in good_recent[-10:]][::-1],
            'reason': '; '.join(reasons),
        })

    order = {'SIM_BUY_EARLY_CANDIDATE': 2, 'WATCH_STABLE_FLOW': 1, 'REJECT_WEAK_OR_DUMPY': 0}
    plays.sort(key=lambda x: (order.get(x['play_type'], 0), x['score'], -x['last_event_age_sec']), reverse=True)
    plays = [p for p in plays if p['play_type'] != 'REJECT_WEAK_OR_DUMPY'][:max_rows]

    wallets: List[Dict[str, Any]] = []
    for row in recent_wallet_rows.values():
        mints = sorted(row.pop('mints'))
        row['mints'] = mints; row['mints_count'] = len(mints)
        row['recent_buy_sol'] = round(row['recent_buy_sol'], 9)
        row['score'] = round(row['score'] + min(30.0, row['recent_buy_count'] * 5.0) + min(25.0, row['recent_buy_sol'] * 10.0), 6)
        row['action'] = 'COPY/WATCH_NOW' if row['last_seen_age_sec'] is not None and row['last_seen_age_sec'] <= recent_window else 'WATCH_ONLY'
        wallets.append(row)
    wallets.sort(key=lambda x: (x.get('score', 0), x.get('recent_buy_sol', 0), -x.get('last_seen_age_sec', 999999)), reverse=True)

    replay = replay_filter_stats(cfg, by_mint)
    life = lifecycle_stats()
    recommended = {
        'LIVE_REQUIRE_PUBLIC_KEY_MATCH_FOR_WSS_ADOPT': True,
        'FRESH_INCOMING_BUY_ONLY': True,
        'MAX_OPEN_POSITIONS': min(inum(cfg.get('MAX_OPEN_POSITIONS'), 3), 2),
        'HOT_PLAY_MIN_TOKEN_AGE_SEC': 25,
        'HOT_PLAY_MAX_TOKEN_AGE_SEC': 900,
        'HOT_PLAY_STALE_AFTER_SEC': 90,
        'HOT_PLAY_MIN_RECENT_BUY_SOL': 0.45,
        'HOT_PLAY_MIN_RECENT_BUYERS': 4,
        'HOT_PLAY_MAX_SELL_BUY_RATIO': 0.45,
        'HOT_PLAY_MAX_DRAWDOWN_FROM_HIGH_PCT': 0.28,
        'HOT_PLAY_BUY_SCORE': 70,
        'HOT_PLAY_WATCH_SCORE': 48,
        'RANKER_MAX_SINGLE_EVENT_SOL': 5.0,
        'LIVE_MAX_SELL_BUY_RATIO': min(fnum(cfg.get('LIVE_MAX_SELL_BUY_RATIO'), 5.0), 1.25),
        'LIVE_TRACKED_WALLET_BUY_MAX_SELL_BUY_RATIO': min(fnum(cfg.get('LIVE_TRACKED_WALLET_BUY_MAX_SELL_BUY_RATIO'), 5.0), 0.85),
        'LIVE_SWARM_MIN_RECENT_BUYS': max(inum(cfg.get('LIVE_SWARM_MIN_RECENT_BUYS'), 1), 2),
        'LIVE_SWARM_MIN_BUYERS': max(inum(cfg.get('LIVE_SWARM_MIN_BUYERS'), 1), 2),
    }

    report = {
        'ts': now_ts(), 'source_events_file': events_file, 'event_anchor_ts': max_ts,
        'replay_horizon_sec': fnum(cfg.get('WIN_RATE_REPLAY_HORIZON_SEC'), 150.0),
        'replay_target_pct': fnum(cfg.get('WIN_RATE_REPLAY_TARGET_PCT'), 0.055),
        'filter_backtest': replay, 'lifecycle_stats': life,
        'recommended_config_patch': recommended,
        'diagnosis': [
            'Current run shows low win-rate pollution from live_wss_adopted_untracked_buy if WSS adoption is allowed without a confirmed own PUBLIC_KEY match.',
            'Best-play dashboard should prefer fresh buy consensus plus low sell/buy ratio instead of old wallet rank alone.',
            'Use SIM calls as watch/copy intelligence only; live send should still re-check tape and safety at send time.',
        ],
    }
    save_json(cfg.get('WIN_RATE_OPTIMIZER_FILE', DEFAULT_WIN_RATE_FILE), report)

    return {
        'ts': now_ts(), 'event_anchor_ts': max_ts, 'event_min_ts': min_ts, 'event_count': event_count, 'mint_count': len(by_mint), 'source_events_file': events_file,
        'settings': {'recent_window_sec': recent_window, 'stable_window_sec': stable_window, 'max_token_age_sec': max_token_age, 'stale_after_sec': stale_after, 'min_recent_buy_sol': min_buy_sol, 'min_recent_buyers': min_buyers, 'max_sell_buy_ratio': max_sell_ratio, 'max_drawdown_from_high_pct': max_drawdown},
        'summary': {'sim_buy_early_candidates': sum(1 for p in plays if p.get('play_type') == 'SIM_BUY_EARLY_CANDIDATE'), 'watch_stable_flow': sum(1 for p in plays if p.get('play_type') == 'WATCH_STABLE_FLOW'), 'recent_profit_wallets': len(wallets)},
        'win_rate_optimizer': report,
        'hot_plays': plays,
        'recent_profit_wallets': wallets[:inum(cfg.get('RECENT_PROFIT_WALLET_MAX_ROWS'), 50)],
        'warning': 'SIM intelligence only. Live buying must re-check current tape, slippage, sell pressure, and holder risk before sending.',
    }


def write_hot_sim_plays(cfg: Dict[str, Any] | None = None, path: str | None = None) -> Dict[str, Any]:
    cfg = cfg or {}
    out = rank_hot_plays(cfg)
    hot_path = path or cfg.get('HOT_SIM_PLAYS_FILE', DEFAULT_HOT_PLAYS_FILE)
    save_json(hot_path, out)
    save_json(cfg.get('RECENT_PROFIT_WALLETS_FILE', DEFAULT_RECENT_WALLETS_FILE), {'ts': out.get('ts'), 'event_anchor_ts': out.get('event_anchor_ts'), 'wallets': out.get('recent_profit_wallets', [])})
    return out


if __name__ == '__main__':
    cfg = _load_json('config.json', {}) or {}
    out = write_hot_sim_plays(cfg)
    wr = ((out.get('win_rate_optimizer') or {}).get('filter_backtest') or {}).get('higher_win_rate', {})
    print(f"HOT_SIM_PLAYS wrote={cfg.get('HOT_SIM_PLAYS_FILE', DEFAULT_HOT_PLAYS_FILE)} buy={out.get('summary',{}).get('sim_buy_early_candidates',0)} watch={out.get('summary',{}).get('watch_stable_flow',0)} wallets={len(out.get('recent_profit_wallets',[]))} replay_wr={wr.get('win_rate')} samples={wr.get('samples')}")
