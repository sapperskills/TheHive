# THE HIVE v11.2.36 - Follow The Money / Hot SIM Plays Patch

This patch fixes stale dashboard intelligence by separating **old profitable wallet profiles** from **fresh current-run money flow**.

## New outputs

- `HOT_SIM_PLAYS.json`  
  Dashboard-ready list of new/stable mints with fresh buy flow.

- `RECENT_PROFIT_WALLETS.json`  
  Wallets from mined profitable profiles that are actively buying right now.

## Dashboard additions

The dashboard now shows two new cards near the top:

1. **FOLLOW THE MONEY: Hot New Stable SIM Plays**
   - copyable mint CA
   - SIM BUY EARLY vs WATCH label
   - score
   - token age
   - last event age
   - market cap
   - buy/sell pressure
   - unique buyer count
   - profiled wallet buy count
   - reason string

2. **Fresh Profit Wallets Active Now**
   - copyable wallet
   - latest mint CA
   - profile WR / edge
   - recent buy count and SOL

## Why this fixes stale lists

The older `MOST_PROFITABLE_WALLETS.txt` can still contain strong historical wallets. That is useful, but it can look stale.

The new `HOT_SIM_PLAYS.json` is anchored to the newest WSS/SIM event timestamp, so replay/SIM runs still rank the freshest mints from the current data instead of only wall-clock time.

## Stability filters

A mint is treated as a stronger SIM buy candidate only when it has:

- recent buy flow
- enough unique recent buyers
- sell/buy ratio under the configured max
- acceptable drawdown from high
- recent last print, preferably a buy
- no heavy exit-warning wallet sell pressure

No SIM call is guaranteed profit. Use this as a scanner/call list and let live code re-check tape, slippage, and risk before real buys.
