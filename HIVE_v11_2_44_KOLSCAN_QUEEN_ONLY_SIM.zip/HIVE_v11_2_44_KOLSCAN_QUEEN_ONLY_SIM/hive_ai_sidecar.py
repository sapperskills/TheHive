#!/usr/bin/env python3
"""
HIVE lightweight AI sidecar.

Purpose:
- Read the single diagnostics stream + trades.
- Build tabular features from live decisions/exits.
- Train a tiny local model when enough labeled rows exist.
- Fall back to deterministic wallet/setup scorecards when sklearn/tabpfn is missing.
- Write hive_ai_scores.json for the live bot to hot-reload.

This is intentionally NOT a chat LLM in the live loop. It is a lightweight
pattern miner / tabular scorer designed for wallet+swarm behavior.
"""
from __future__ import annotations
import csv, json, math, os, time, traceback
from pathlib import Path
from typing import Any, Dict, List, Tuple

DEFAULT_CONFIG = 'config.json'
DEFAULT_DIAG = 'HIVE_BEHAVIOR_DIAGNOSTICS.jsonl'
DEFAULT_TRADES = 'wallet_predator_trades.csv'
DEFAULT_OUT = 'hive_ai_scores.json'

def now_ts() -> int:
    return int(time.time())

def fnum(x: Any, d: float=0.0) -> float:
    try:
        if x is None or x == '': return d
        return float(x)
    except Exception:
        return d

def inum(x: Any, d: int=0) -> int:
    try:
        if x is None or x == '': return d
        return int(float(x))
    except Exception:
        return d

def load_json(path: str, default: Any=None) -> Any:
    try:
        p=Path(path)
        if not p.exists(): return default
        return json.loads(p.read_text(encoding='utf-8', errors='ignore'))
    except Exception:
        return default

def save_json(path: str, obj: Any) -> None:
    p=Path(path); tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding='utf-8')
    tmp.replace(p)

def append_jsonl(path: str, obj: Dict[str, Any]) -> None:
    with open(path, 'a', encoding='utf-8') as f:
        f.write(json.dumps(obj, separators=(',',':'))+'\n')

def iter_jsonl(path: str, max_rows: int=250000) -> List[Dict[str, Any]]:
    rows=[]; p=Path(path)
    if not p.exists(): return rows
    try:
        with p.open('r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                if not line.strip(): continue
                try:
                    obj=json.loads(line)
                    if isinstance(obj, dict): rows.append(obj)
                    if len(rows) >= max_rows: break
                except Exception:
                    continue
    except Exception:
        pass
    return rows

def load_trades(path: str) -> List[Dict[str, Any]]:
    p=Path(path)
    if not p.exists(): return []
    rows=[]
    try:
        with p.open('r', encoding='utf-8', errors='ignore', newline='') as f:
            for r in csv.DictReader(f): rows.append(dict(r))
    except Exception:
        return []
    return rows


def load_lifecycle_sells(path: str='position_lifecycle.jsonl') -> List[Dict[str, Any]]:
    """Load SIM/live lifecycle sells as training labels.

    wallet_predator_trades.csv is not always complete in this codebase. The
    lifecycle file is the source of truth for paper_buy/paper_sell outcomes, so
    the AI risk manager learns from what the SIM actually did.
    """
    rows=[]
    for r in iter_jsonl(path, max_rows=300000):
        ev=str(r.get('event','')).lower()
        if 'sell' not in ev:
            continue
        rr=dict(r)
        rr['side']=rr.get('side') or 'PAPER_SELL'
        rows.append(rr)
    return rows

def setup_performance(rows: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        setup=str(r.get('setup') or 'unknown')
        pnl=fnum(r.get('pnl_sol'), fnum(r.get('gross_pnl_sol'), 0.0))
        pct=fnum(r.get('net_pnl_pct'), fnum(r.get('pnl_pct'), fnum(r.get('gross_pnl_pct'), 0.0)))
        d=out.setdefault(setup, {'n':0,'wins':0,'pnl_sol':0.0,'pct_sum':0.0,'reasons':{}})
        d['n'] += 1
        d['wins'] += 1 if (pnl > 0 or pct > 0.0) else 0
        d['pnl_sol'] += pnl
        d['pct_sum'] += pct
        reason=str(r.get('reason') or '')
        if reason:
            d['reasons'][reason]=d['reasons'].get(reason,0)+1
    for setup,d in out.items():
        n=max(1,int(d['n']))
        d['win_rate']=round(float(d['wins'])/n,4)
        d['avg_pnl_sol']=round(float(d['pnl_sol'])/n,8)
        d['avg_pct']=round(float(d['pct_sum'])/n,6)
        d['allowed'] = bool(d['win_rate'] >= 0.55 and d['avg_pnl_sol'] > 0 and n >= 2)
        d['blocked'] = bool((d['win_rate'] < 0.45 and n >= 3) or d['avg_pnl_sol'] < 0)
    return dict(sorted(out.items(), key=lambda kv: (kv[1].get('win_rate',0), kv[1].get('avg_pnl_sol',0)), reverse=True))

def ai_pattern_grade(feat: Dict[str,float], setup: str, setup_perf: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """Deterministic AI risk-manager grade, tuned from the user's logs.

    AI can approve/block/rank, but it does not invent entries. Winning pattern =
    pressure runner or proven swarm edge with fresh buy-side flow and low danger.
    Losing pattern = queen-worker, wallet predator, stale/noisy volume bots,
    sell-only/dump-risk pressure.
    """
    allow_setups={'pressure_runner_lift','swarm_edge_auto_ride','top_trader_volume_spike'}
    bad_setups={'queen_worker_front_run','queen_cycle_ride','queen_dump_recovery_scout','wallet_predator_accumulation','worker_swarm_acceleration','ai_swarm_edge_override','copy_wallet_probe','watch_surge_counter'}
    entry=0.50
    danger=0.05
    flags=[]
    if setup in allow_setups:
        entry += 0.20; flags.append('allowed_hard_setup')
    if setup in bad_setups:
        entry -= 0.25; danger += 0.30; flags.append('bad_historical_setup')
    perf=setup_perf.get(setup) or {}
    if perf:
        wr=fnum(perf.get('win_rate'),0.5); avg=fnum(perf.get('avg_pnl_sol'),0.0); n=fnum(perf.get('n'),0.0)
        entry += max(-0.20, min(0.20, (wr-0.50)*0.55))
        if avg > 0: entry += min(0.10, avg*20)
        if avg < 0: danger += min(0.15, abs(avg)*30)
        if n >= 3 and wr < 0.45: danger += 0.12; flags.append('setup_under_45wr')
        if n >= 2 and wr >= 0.65 and avg > 0: flags.append('setup_positive_scorecard')
    recent_buys=fnum(feat.get('recent_buys'))
    recent_sells=fnum(feat.get('recent_sells'))
    buy_sol=fnum(feat.get('buy_sol_recent'))
    sell_pressure=fnum(feat.get('sell_pressure'))
    ratio=fnum(feat.get('sell_buy_ratio'))
    top_net=fnum(feat.get('top_net_buy_sol'))
    dump=fnum(feat.get('dump_risk_count'))
    sell_only=fnum(feat.get('sell_only_count'))
    sell_near=fnum(feat.get('sell_near_high_count'))
    queen_sell=fnum(feat.get('queen_sell_sol'))
    worker_buy=fnum(feat.get('worker_buy_sol'))
    score=fnum(feat.get('score'))
    if recent_buys >= 20: entry += 0.08; flags.append('many_recent_buys')
    if buy_sol >= 8: entry += 0.08; flags.append('strong_recent_buy_sol')
    if top_net >= 1: entry += 0.06; flags.append('positive_top_net_buy')
    if score >= 750: entry += 0.08; flags.append('high_pressure_score')
    if worker_buy > 0 and queen_sell <= 0: entry += 0.04
    if recent_sells > recent_buys: danger += 0.18; flags.append('sells_outnumber_buys')
    if sell_pressure > 0.42: danger += min(0.30, (sell_pressure-0.42)*0.75); flags.append('sell_pressure_high')
    if ratio > 1.15: danger += min(0.30, (ratio-1.15)*0.20); flags.append('sell_buy_ratio_high')
    if dump > 0: danger += min(0.25, dump*0.08); flags.append('dump_risk_wallets')
    if sell_only > 0: danger += min(0.18, sell_only*0.07); flags.append('sell_only_wallets')
    if sell_near > 0: danger += min(0.15, sell_near*0.05); flags.append('sell_near_high_wallets')
    if queen_sell > max(0.2, worker_buy*0.5): danger += 0.12; flags.append('queen_sell_pressure')
    entry=max(0.01,min(0.99,entry-danger*0.35))
    danger=max(0.0,min(0.99,danger))
    if danger >= 0.70 or entry < 0.45:
        grade='F'
    elif danger >= 0.55 or entry < 0.58:
        grade='D'
    elif entry >= 0.82 and danger <= 0.30:
        grade='A'
    elif entry >= 0.70 and danger <= 0.42:
        grade='B'
    else:
        grade='C'
    return {'entry_score':round(entry,4),'danger_score':round(danger,4),'runner_score':round(max(0.01,min(0.99,entry + min(0.12, top_net/20.0) - min(0.15, queen_sell/8.0))),4),'grade':grade,'flags':flags}

def decision_rows(diag_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out=[]
    for r in diag_rows:
        if r.get('type') == 'decision':
            out.append(r)
    return out

def normalize_wallet_summary(ws: Any) -> Dict[str, Any]:
    return ws if isinstance(ws, dict) else {}

def trade_labels_by_mint(trades: List[Dict[str, Any]], fee_safe_pct: float=0.08) -> Dict[str, Dict[str, Any]]:
    by={}
    for t in trades:
        side=str(t.get('side','')).upper()
        if 'SELL' not in side: continue
        mint=t.get('mint') or t.get('ca') or ''
        if not mint: continue
        pnl=fnum(t.get('pnl_sol'), fnum(t.get('gross_pnl_sol'), 0.0))
        net_pct=fnum(t.get('net_pnl_pct'), fnum(t.get('gross_pnl_pct'), 0.0))
        gross_pct=fnum(t.get('gross_pnl_pct'), 0.0)
        # Favor actual wallet/net pnl if present; fallback percent.
        win = 1 if (pnl > 0 or net_pct >= fee_safe_pct or gross_pct >= fee_safe_pct) else 0
        d=by.setdefault(mint, {'sells':0,'wins':0,'pnl_sol':0.0,'best_net_pct':-999.0,'setups':{}})
        d['sells'] += 1; d['wins'] += win; d['pnl_sol'] += pnl; d['best_net_pct'] = max(d['best_net_pct'], net_pct)
        setup=t.get('setup') or 'unknown'
        sd=d['setups'].setdefault(setup, {'n':0,'wins':0,'pnl_sol':0.0})
        sd['n'] += 1; sd['wins'] += win; sd['pnl_sol'] += pnl
    return by

def build_feature(r: Dict[str, Any]) -> Dict[str, float]:
    ws=normalize_wallet_summary(r.get('wallet_summary'))
    hive=normalize_wallet_summary(r.get('hive_state'))
    qs=normalize_wallet_summary(r.get('queen_signature'))
    return {
        'score': fnum(r.get('score')),
        'sell_pressure': fnum(r.get('sell_pressure')),
        'sell_buy_ratio': fnum(r.get('sell_buy_ratio'), fnum(r.get('total_sell_buy_ratio'))),
        'recent_buys': fnum(r.get('recent_buys')),
        'recent_sells': fnum(r.get('recent_sells')),
        'last_event_sol': fnum(r.get('last_event_sol'), fnum(r.get('last_buy_sol'))),
        'age': fnum(r.get('age')),
        'worker_buys': fnum(hive.get('worker_buys')),
        'queen_sells': fnum(hive.get('queen_sells')),
        'worker_buy_sol': fnum(hive.get('worker_buy_sol')),
        'queen_sell_sol': fnum(hive.get('queen_sell_sol')),
        'net_hive_sol': fnum(hive.get('net_hive_sol')),
        'top_net_buy_sol': fnum(ws.get('top_net_buy_sol')),
        'alpha_count': fnum(ws.get('alpha_count')),
        'accumulator_count': fnum(ws.get('accumulator_count')),
        'dump_risk_count': fnum(ws.get('dump_risk_count')),
        'sell_only_count': fnum(ws.get('sell_only_count')),
        'sell_near_high_count': fnum(ws.get('sell_near_high_count')),
        'queen_sell_buy_sol_ratio': fnum(qs.get('sell_buy_sol_ratio'), 9.0),
    }

def label_decisions(decisions: List[Dict[str, Any]], labels_by_mint: Dict[str, Dict[str, Any]]) -> Tuple[List[Dict[str, float]], List[int], List[Dict[str, Any]]]:
    X=[]; y=[]; meta=[]
    for r in decisions:
        mint=r.get('mint') or ''
        if not mint or mint not in labels_by_mint: continue
        # Only train from approved rows to avoid pretending every block was a trade.
        if not r.get('approved'): continue
        lab=labels_by_mint[mint]
        X.append(build_feature(r)); y.append(1 if lab.get('wins',0) > 0 and fnum(lab.get('pnl_sol')) > 0 else 0)
        meta.append({'mint':mint,'setup':r.get('setup') or 'none','wallet':r.get('last_wallet') or r.get('last_event_wallet') or '', 'label':y[-1], 'pnl_sol':lab.get('pnl_sol',0)})
    return X,y,meta

def fit_predict_model(X: List[Dict[str,float]], y: List[int]) -> Tuple[bool, Any, List[str], str]:
    if len(X) < 20 or len(set(y)) < 2:
        return False, None, [], 'not_enough_labeled_rows'
    cols=sorted(X[0].keys())
    mat=[[fnum(row.get(c)) for c in cols] for row in X]
    try:
        # Try TabPFN only when explicitly installed. It can be heavy, so fallback remains first-class.
        use_tabpfn = os.environ.get('HIVE_USE_TABPFN','0') == '1'
        if use_tabpfn:
            from tabpfn import TabPFNClassifier  # type: ignore
            clf=TabPFNClassifier()
            clf.fit(mat, y)
            return True, clf, cols, 'tabpfn'
    except Exception:
        pass
    try:
        from sklearn.ensemble import HistGradientBoostingClassifier, GradientBoostingClassifier  # type: ignore
        try:
            clf=HistGradientBoostingClassifier(max_iter=80, learning_rate=0.06, max_leaf_nodes=15, random_state=7)
        except Exception:
            clf=GradientBoostingClassifier(random_state=7)
        clf.fit(mat, y)
        return True, clf, cols, 'sklearn_gradient_boosting'
    except Exception:
        return False, None, cols, 'sklearn_missing_fallback_scorecard'

def model_score(model: Any, cols: List[str], feat: Dict[str,float]) -> float:
    if model is None or not cols: return 0.5
    row=[[fnum(feat.get(c)) for c in cols]]
    try:
        if hasattr(model, 'predict_proba'):
            return float(model.predict_proba(row)[0][1])
        pred=model.predict(row)[0]
        return float(pred)
    except Exception:
        return 0.5

def heuristic_score(feat: Dict[str,float]) -> float:
    s=0.50
    s += min(0.18, feat['score']/1000.0)
    s += min(0.12, feat['top_net_buy_sol']/10.0)
    s += min(0.10, feat['worker_buy_sol']/10.0)
    s += min(0.08, max(0.0, feat['net_hive_sol'])/10.0)
    s -= min(0.18, feat['sell_pressure']*0.25)
    s -= min(0.16, feat['sell_buy_ratio']*0.12)
    s -= min(0.12, feat['dump_risk_count']*0.04)
    s -= min(0.08, feat['sell_near_high_count']*0.02)
    return max(0.01, min(0.99, s))

def aggregate_scores(decisions: List[Dict[str, Any]], trades: List[Dict[str, Any]], model: Any, cols: List[str], setup_perf: Dict[str, Dict[str, Any]]|None=None) -> Dict[str, Any]:
    setup_perf = setup_perf or {}
    wallet_scores: Dict[str, Dict[str, Any]]={}
    setup_scores: Dict[str, Dict[str, Any]]={}
    mint_scores: Dict[str, Dict[str, Any]]={}
    recent = decisions[-5000:]
    for r in recent:
        wallet = r.get('last_wallet') or r.get('last_event_wallet') or ''
        setup = r.get('setup') or 'none'
        mint = r.get('mint') or ''
        feat=build_feature(r)
        ps=ai_pattern_grade(feat, setup, setup_perf)
        ms=model_score(model, cols, feat) if model is not None else heuristic_score(feat)
        hs=heuristic_score(feat)
        entry_score = max(0.01, min(0.99, 0.20*ms + 0.20*hs + 0.60*fnum(ps.get('entry_score'),0.5)))
        danger = max(fnum(ps.get('danger_score'),0.0), max(0.0, min(0.99, fnum(feat.get('sell_pressure'))*0.55 + min(0.35, fnum(feat.get('sell_buy_ratio'))*0.20) + min(0.25, fnum(feat.get('dump_risk_count'))*0.05))))
        runner = max(0.0, min(0.99, 0.60*fnum(ps.get('runner_score'),0.5) + 0.40*(entry_score + min(0.18, fnum(feat.get('top_net_buy_sol'))/20.0) - min(0.20, fnum(feat.get('queen_sell_sol'))/10.0))))
        for bucket, key in ((wallet_scores,wallet),(setup_scores,setup),(mint_scores,mint)):
            if not key: continue
            d=bucket.setdefault(key, {'n':0,'entry_sum':0.0,'danger_sum':0.0,'runner_sum':0.0,'approved':0,'blocked':0,'grade_counts':{}})
            d['n'] += 1; d['entry_sum'] += entry_score; d['danger_sum'] += danger; d['runner_sum'] += runner
            grade = ai_pattern_grade(feat, setup, setup_perf).get('grade','C')
            d['grade_counts'][grade] = d['grade_counts'].get(grade,0)+1
            if r.get('approved'): d['approved'] += 1
            else: d['blocked'] += 1
    def finalize(bucket: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        out={}
        for k,d in bucket.items():
            n=max(1, int(d.get('n',0)))
            if n < 2: continue
            out[k]={
                'n': n,
                'entry_score': round(d['entry_sum']/n, 4),
                'danger_score': round(d['danger_sum']/n, 4),
                'runner_score': round(d['runner_sum']/n, 4),
                'approved': d.get('approved',0),
                'blocked': d.get('blocked',0),
                'grade_counts': d.get('grade_counts',{}),
            }
        return dict(sorted(out.items(), key=lambda kv: kv[1].get('entry_score',0), reverse=True)[:500])
    return {'wallet_scores': finalize(wallet_scores), 'setup_scores': finalize(setup_scores), 'mint_scores': finalize(mint_scores)}

def main(argv=None) -> None:
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('--config', default=DEFAULT_CONFIG)
    ap.add_argument('--once', action='store_true')
    args=ap.parse_args(argv)
    cfg=load_json(args.config, {}) or {}
    diag_file=cfg.get('DIAGNOSTIC_EXPORT_FILE', DEFAULT_DIAG)
    trades_file=cfg.get('TRADES_FILE', DEFAULT_TRADES)
    out_file=cfg.get('HIVE_AI_SCORES_FILE', DEFAULT_OUT)
    try:
        diag=iter_jsonl(diag_file, max_rows=inum(cfg.get('HIVE_AI_MAX_DIAGNOSTIC_ROWS'), 200000))
        decisions=decision_rows(diag)
        trades=load_trades(trades_file)
        lifecycle=load_lifecycle_sells(cfg.get('HIVE_AI_LIFECYCLE_FILE','position_lifecycle.jsonl'))
        all_trade_labels = trades + lifecycle
        setup_perf = setup_performance(all_trade_labels)
        labels=trade_labels_by_mint(all_trade_labels, fnum(cfg.get('HIVE_AI_FEE_SAFE_TARGET_PCT'), 0.08))
        X,y,meta=label_decisions(decisions, labels)
        # Live default: fast heuristic scorecard. Full sklearn/TabPFN training can be
        # enabled later, but should not stall live trading on Windows.
        if bool(cfg.get('HIVE_AI_TRAIN_MODEL_ENABLED', False)):
            ok, model, cols, model_type = fit_predict_model(X,y)
        else:
            ok, model, cols, model_type = False, None, [], 'heuristic_fast_no_training'
        scored=aggregate_scores(decisions, all_trade_labels, model if ok else None, cols if ok else [], setup_perf)
        out={
            'ts': now_ts(),
            'model_type': model_type,
            'model_ready': bool(ok),
            'labeled_rows': len(y),
            'positive_rows': int(sum(y)),
            'diagnostic_rows': len(diag),
            'decision_rows': len(decisions),
            'trade_rows': len(trades),
            'lifecycle_sell_rows': len(lifecycle),
            'config': {
                'entry_score_allow': fnum(cfg.get('HIVE_AI_ENTRY_SCORE_ALLOW'), 0.62),
                'entry_score_block': fnum(cfg.get('HIVE_AI_ENTRY_SCORE_BLOCK'), 0.36),
                'danger_score_block': fnum(cfg.get('HIVE_AI_DANGER_SCORE_BLOCK'), 0.78),
                'runner_score_hold': fnum(cfg.get('HIVE_AI_RUNNER_SCORE_HOLD'), 0.66),
                'ai_can_enter_trades': bool(cfg.get('AI_CAN_ENTER_TRADES', False)),
                'ai_can_block_trades': bool(cfg.get('AI_CAN_BLOCK_TRADES', True)),
            },
            'setup_performance': setup_perf,
            **scored,
            'top_wallets': list(scored.get('wallet_scores', {}).items())[:25],
            'top_setups': list(scored.get('setup_scores', {}).items())[:25],
        }
        save_json(out_file, out)
        append_jsonl('hive_ai_sidecar_runs.jsonl', {'ts': now_ts(), 'out': out_file, 'model_type': model_type, 'model_ready': bool(ok), 'labeled_rows': len(y), 'positive_rows': int(sum(y)), 'wallets': len(out.get('wallet_scores',{})), 'setups': len(out.get('setup_scores',{}))})
        print(f"HIVE_AI_SIDECAR wrote={out_file} model={model_type} ready={bool(ok)} labels={len(y)} positives={int(sum(y))} wallets={len(out.get('wallet_scores',{}))}")
    except Exception as e:
        append_jsonl('hive_ai_sidecar_errors.jsonl', {'ts': now_ts(), 'error': str(e), 'trace': traceback.format_exc()[-4000:]})
        raise

if __name__ == '__main__':
    main()
