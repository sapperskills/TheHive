# v11.2.36 Buy/Sell-Only WSS Filter Patch

This patch turns the raw WSS firehose into a clean buy/sell tape before strategy logic sees it.

## Main safety/profit changes

- `STRICT_SWAP_ONLY=true`: CreateToken, ATA creation, anchor self CPI, transfers, funding, metadata, and non-trade events are ignored.
- `BUY_SELL_ONLY_JSONL=buy_sell_only.jsonl` and `BUY_SELL_ONLY_CSV=buy_sell_only.csv`: clean tape only.
- `LIVE_ADOPT_UNTRACKED_OWN_BUY=false`: stops the low-win-rate `live_wss_adopted_untracked_buy` pollution.
- `LIVE_REQUIRE_PUBLIC_KEY_MATCH_FOR_WSS_ADOPT=true`: WSS confirmations must match your own public key before they can touch local positions.
- Fresh incoming buys are still required for entries.
- Hot-play settings from the latest optimizer report are applied.

## Optional wallet-only mode

The screenshot creator wallet is already listed in `WSS_SIGNAL_WALLETS`:

`DvWHmcpuwWrmbrpJshAnAdbj66NQRt66R35LWfMHvWSt`

By default `FILTER_TO_WSS_SIGNAL_WALLETS=false`, so the bot still mines all clean buy/sell flow. Set it to `true` if you want to only record/copy that wallet's buy/sell tape.

## Useful commands

```bash
python main.py --mode sim --config config.json
python watch_buy_sell_only.py
python export_buy_sell_summary.py
```

The dashboard/copy logic should trust `buy_sell_only.jsonl` and `buy_sell_only.csv` over raw `live_wallet_events.jsonl`.
