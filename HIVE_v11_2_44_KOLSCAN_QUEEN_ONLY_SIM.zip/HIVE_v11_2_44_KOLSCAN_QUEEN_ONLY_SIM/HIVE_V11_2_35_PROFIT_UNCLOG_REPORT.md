# HIVE v11.2.35 Profit Unclog / AI-Safe Runner Lift

## What the new data showed

Closed sells in the uploaded run were net negative after wallet-delta/fee drag:

- Closed sell rows: 38
- Gross PnL: +0.156796 SOL
- Estimated/wallet drag: -0.255860 SOL
- Net PnL: -0.099064 SOL

Setup breakdown:

| Setup | Sells | Net SOL | Avg SOL | Win rate |
|---|---:|---:|---:|---:|
| queen_dump_recovery_scout | 28 | +0.043117 | +0.001540 | 50% |
| queen_cycle_ride | 5 | -0.014513 | -0.002903 | 0% |
| hive_state_scout | 2 | -0.039278 | -0.019639 | 0% |
| swarm_edge_auto_ride | 3 | -0.088389 | -0.029463 | 0% |

So the patch keeps the queen dump recovery lane and disables the lanes that lost money in this run.

## AI / buy slowdown finding

The live loop was trying to run the AI sidecar repeatedly, but the uploaded logs contained these errors:

- `NameError: argv is not defined`
- `TypeError: main() takes 0 positional arguments but 1 was given`

This meant the AI sidecar was not producing useful live scores. In v11.2.35 it is fixed and isolated:

- AI sidecar runs in a subprocess.
- If AI crashes, live trading continues.
- AI is advisory by default and does not danger-block approved trades.
- Fast heuristic mode is default so sklearn/TabPFN cannot stall live trading.

## Blocker replay

Simulation used next observed market-cap tape with +18% TP / -15% SL over 90 seconds.

| Blocker | Replay count | Win rate | Avg result | Verdict |
|---|---:|---:|---:|---|
| not_new_incoming_buy | 11,502 | 23.4% | -3.72% | keep hard for normal entries |
| rug_risk | 2,848 | 49.2% | -0.49% | do not globally remove |
| queen_exit_shadow | 239 | 31.8% | -4.28% | keep hard except recovery lanes |
| queen_pre_exit_warning | 13 | 23.1% | -7.39% | keep hard |
| recent_sells | 15 | 33.3% | -4.00% | keep hard |
| sell_pressure | 4,232 | 50.5% | +0.87% | can be lifted only by strong runner lane |

## Same-mint / max-entry blocks

`max_entries_per_mint_3` was mostly protective in this sample. The 13 prebuy blocks tested at only 30.8% win rate and -7.39% average result. I did not lift this globally.

## New lane added

`pressure_runner_lift`

This lane is for the rare cases where blockers hide a real runner. It only fires when the tape looks like a broad worker runner, not a single queen wallet:

- hive state must be `worker_entry` or `worker_swarm`
- score >= 600
- recent buys >= 20
- recent unique buyers >= 8
- recent buy SOL >= 3.0
- sell pressure <= 0.58
- sell/buy ratio <= 1.45
- no sell-only wallet in current set
- danger wallets <= 5

It can bypass selected soft blockers:

- `not_new_incoming_buy`
- `rug_risk_`
- `sell_pressure_`
- `sell_buy_ratio_`
- `dump_risk_wallets_`
- limited `danger_wallets_`
- selected live sell-pressure/recent-sell guards

This is not a global loosening. It is a high-conviction unblocker for runner-quality swarm flow.

## Config changes

- `SWARM_EDGE_AUTO_RIDE_ENABLED=false`
- `QUEEN_CYCLE_RIDE_ENABLED=false`
- `HIVE_STATE_SCOUT_ENABLED=false`
- `HIVE_AI_BLOCK_DANGER_APPROVED=false`
- `HIVE_AI_TRAIN_MODEL_ENABLED=false` by default for speed
- `PRESSURE_RUNNER_LIFT_ENABLED=true`
- `QUEEN_DUMP_RECOVERY_MAX_SELL_PRESSURE_AFTER_REFILL=0.42`
- `QUEEN_DUMP_RECOVERY_MAX_SELL_BUY_RATIO_AFTER_REFILL=0.70`

## Bottom line

The data did not support lifting all blockers. It did support one new aggressive lane: broad worker-swarm runner pressure. The bot should now trade the proven queen recovery lane, avoid the losing lanes, and allow blocked runners only when the swarm itself is strong enough to justify it.
