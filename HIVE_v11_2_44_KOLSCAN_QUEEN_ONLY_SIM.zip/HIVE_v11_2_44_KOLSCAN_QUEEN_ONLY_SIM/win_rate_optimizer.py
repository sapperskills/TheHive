#!/usr/bin/env python3
from __future__ import annotations
"""Generate WIN_RATE_OPTIMIZER_REPORT.json and refresh HOT_SIM_PLAYS.json.

Run this after a SIM session to see which filters improved replay win rate and
what config patch is recommended for cleaner dashboard calls.
"""
import json
from pathlib import Path
from live_money_flow_ranker import write_hot_sim_plays, DEFAULT_WIN_RATE_FILE


def main() -> None:
    cfg = {}
    if Path('config.json').exists():
        try:
            cfg = json.loads(Path('config.json').read_text(encoding='utf-8'))
        except Exception:
            cfg = {}
    out = write_hot_sim_plays(cfg)
    report = out.get('win_rate_optimizer') or {}
    path = cfg.get('WIN_RATE_OPTIMIZER_FILE', DEFAULT_WIN_RATE_FILE)
    fb = report.get('filter_backtest') or {}
    print(f"wrote {path}")
    for name in ('current_config', 'higher_win_rate', 'very_strict'):
        r = fb.get(name) or {}
        print(f"{name}: samples={r.get('samples',0)} win_rate={r.get('win_rate',0)} avg_max_gain={r.get('avg_max_gain_pct',0)}")
    print('recommended_config_patch:')
    print(json.dumps(report.get('recommended_config_patch') or {}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
