# HIVE v11.2.36 Pre-Arm Funding Graph Patch

Applied systems:

1. **Offline Funding Graph Builder**
   - New standalone `funding_graph_builder.py`
   - Maintains `funding_graph.json`, `cluster_map.json`, `controller_watch_list.json`, and `pending_token_watch.json`
   - Uses async aiohttp RPC, 25 calls/10s limiter, concurrency semaphore, 429 backoff, and JSON locks
   - Watches controller wallets for fresh outbound funding and writes `controller_alerts.jsonl`

2. **Pre-Armed Token Watcher**
   - `live_feed.py` now exposes `check_pending_token_watch(cfg, book)`
   - `main.py` calls it every ~2 seconds even when websocket traffic is quiet
   - Confirmed funded-wallet creator hits produce synthetic rows with:
     - `pre_armed=True`
     - `pre_arm_cluster_id`
     - `pre_arm_controller`
     - `pre_arm_score_override=180`
   - `strategy.py` routes these through `pre_armed_controller_cluster` and logs `pre_arm_decisions.jsonl`

3. **Feed Latency Monitor**
   - New `feed_latency_monitor.py`
   - `main.py` records every websocket event latency
   - `executor.py` tags creator-cluster sell exits as low-confidence if feed p90 is slow, but still exits

4. **START_LIVE.bat**
   - Launches graph builder in its own window:
     - `start "HIVE GRAPH BUILDER" python funding_graph_builder.py`

Compile checked:
- `util.py`
- `live_feed.py`
- `main.py`
- `strategy.py`
- `executor.py`
- `wallet_intel.py`
- `creator_tracker.py`
- `dashboard_server.py`
- `funding_graph_builder.py`
- `feed_latency_monitor.py`
