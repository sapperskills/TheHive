@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist swarm_edge_miner.py (
  echo ERROR: swarm_edge_miner.py not found. Run this from the extracted v11.2.29 bot folder.
  pause
  exit /b 1
)
python swarm_edge_miner.py
if errorlevel 1 pause && exit /b 1
python diagnostic_export.py
if errorlevel 1 pause && exit /b 1
echo DONE. Upload HIVE_DIAGNOSTIC_EXPORT.json
pause
