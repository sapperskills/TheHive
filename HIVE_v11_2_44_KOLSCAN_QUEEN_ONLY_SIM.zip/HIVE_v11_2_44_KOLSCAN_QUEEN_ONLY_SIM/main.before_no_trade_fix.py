#!/usr/bin/env python3
from __future__ import annotations
import argparse, asyncio, json, time, traceback, os, subprocess, sys
from pathlib import Path
from typing import Any, Dict
from util import BOT_BUILD, load_json, save_json, append_jsonl, iter_jsonl, boot_proof, fnum, inum, now_ts, short_mint
from wallet_intel import WalletIntel
from strategy import WalletPredatorStrategy
from executor import PositionManager
from live_feed import LiveMintBook, check_pending_token_watch
from creator_tracker import CreatorTracker, set_global_creator_tracker
from feed_latency_monitor import FeedLatencyMonitor, set_global_feed_latency_monitor

_SWARM_EDGE_LAST_MINE_TS = 0.0
_SWARM_EDGE_LAST_SIG = None
_HIVE_AI_LAST_RUN_TS = 0.0
_HIVE_AI_LAST_SIG = None
_FOLLOW_MONEY_LAST_MINE_TS = 0.0
_FOLLOW_MONEY_LAST_SIG = None


def maybe_auto_mine_swarm_edges(cfg: Dict[str, Any], strategy: Any = None, pm: Any = None, force: bool = False) -> None:
    """Mine wallet weakness profiles from live data and hot-reload them.

    This is intentionally cheap and safe: it only runs when enough time has
    passed AND live_wallet_events.jsonl changed. It never stops trading if the
    miner fails.
    """
    global _SWARM_EDGE_LAST_MINE_TS, _SWARM_EDGE_LAST_SIG
    if not cfg.get('SWARM_EDGE_AUTO_MINE_ENABLED', True):
        return
    events_path = Path(cfg.get('LIVE_WALLET_EVENTS_FILE','live_wallet_events.jsonl'))
    if not events_path.exists():
        return
    now = time.time()
    interval = fnum(cfg.get('SWARM_EDGE_AUTO_MINE_INTERVAL_SEC'), 120.0)
    min_events = inum(cfg.get('SWARM_EDGE_AUTO_MINE_MIN_EVENTS'), 150)
    try:
        st = events_path.stat()
        sig = (st.st_size, int(st.st_mtime))
        if not force and now - _SWARM_EDGE_LAST_MINE_TS < interval:
            return
        if not force and _SWARM_EDGE_LAST_SIG == sig:
            return
        # Quick line count guard to avoid mining noise from the first few events.
        lines = 0
        with events_path.open('rb') as f:
            for _ in f:
                lines += 1
                if lines >= min_events:
                    break
        if lines < min_events and not force:
            return
        from swarm_edge_miner import load_events, mine_swarm_edges, load_trade_pnl, DEFAULT_OUT, write_recent_copy_watch_file
        events = load_events(str(events_path))
        profiles = mine_swarm_edges(events, cfg)
        profiles['trade_setup_pnl'] = load_trade_pnl(cfg.get('TRADES_FILE','wallet_predator_trades.csv'))
        out_path = cfg.get('SWARM_EDGE_PROFILE_FILE', DEFAULT_OUT)
        save_json(out_path, profiles)
        write_recent_copy_watch_file(profiles, cfg.get('RECENT_COPY_CALL_FILE', 'SIM_BEST_COPY_CALLS.json'))
        hot_summary = {}
        try:
            from live_money_flow_ranker import write_hot_sim_plays
            hot = write_hot_sim_plays(cfg)
            hot_summary = hot.get('summary', {}) if isinstance(hot, dict) else {}
        except Exception as _e:
            append_jsonl('hot_sim_play_errors.jsonl', {'ts': now_ts(), 'where': 'auto_mine_hot_sim', 'error': str(_e)})
        try:
            from dashboard_server import profitable_wallets_text
            Path('MOST_PROFITABLE_WALLETS.txt').write_text(profitable_wallets_text(100), encoding='utf-8')
        except Exception as _e:
            append_jsonl('profitable_wallet_export_errors.jsonl', {'ts': now_ts(), 'where': 'auto_mine_export', 'error': str(_e)})
        _SWARM_EDGE_LAST_MINE_TS = now
        _SWARM_EDGE_LAST_SIG = sig
        if strategy and hasattr(strategy, 'reload_swarm_edge_profiles'):
            strategy.reload_swarm_edge_profiles()
        if pm and hasattr(pm, 'reload_swarm_edge_profiles'):
            pm.reload_swarm_edge_profiles()
        append_jsonl('swarm_edge_miner_runs.jsonl', {
            'ts': now_ts(), 'profile_file': out_path, 'events_file': str(events_path),
            'event_file_size': st.st_size, 'mints': profiles.get('inputs',{}).get('mints'),
            'copy_buy_wallets': len(profiles.get('copy_buy_wallets', [])),
            'exit_warning_wallets': len(profiles.get('exit_warning_wallets', [])),
            'cycle_wallets': len(profiles.get('cycle_wallets', [])),
            'recent_copy_calls': len(profiles.get('recent_copy_call_candidates', [])),
            'hot_sim_play_summary': hot_summary,
            'hot_reloaded': bool(strategy or pm),
        })
        print(f"SWARM_EDGE_AUTO_MINE wrote={out_path} copy={len(profiles.get('copy_buy_wallets',[]))} exit={len(profiles.get('exit_warning_wallets',[]))} cycle={len(profiles.get('cycle_wallets',[]))} calls={len(profiles.get('recent_copy_call_candidates',[]))}")
    except Exception as e:
        append_jsonl('runtime_errors.jsonl', {'ts': now_ts(), 'where': 'swarm_edge_auto_mine', 'error': str(e), 'trace': traceback.format_exc()[-2000:]})





def maybe_auto_build_follow_money_graph(cfg: Dict[str, Any], strategy: Any = None, pm: Any = None, force: bool = False) -> None:
    """Build a bigger wallet/dev/creator graph from local trade logs.

    Runs opportunistically and never blocks trading. It powers:
    - FOLLOW_MONEY_GRAPH.json
    - FOLLOW_MONEY_WATCHLIST.json
    - FOLLOW_MONEY_WATCHLIST.txt
    Strategy/exit code can then use these as local signal files.
    """
    global _FOLLOW_MONEY_LAST_MINE_TS, _FOLLOW_MONEY_LAST_SIG
    if not cfg.get('FOLLOW_MONEY_GRAPH_ENABLED', True):
        return
    events_path = Path(cfg.get('LIVE_WALLET_EVENTS_FILE','live_wallet_events.jsonl'))
    clean_path = Path(cfg.get('BUY_SELL_ONLY_JSONL','buy_sell_only.jsonl'))
    creator_path = Path(cfg.get('CREATOR_WALLET_MAP_FILE','creator_wallet_map.jsonl'))
    now = time.time()
    interval = fnum(cfg.get('FOLLOW_MONEY_BUILD_INTERVAL_SEC'), 60.0)
    try:
        sig_parts = []
        for p in (events_path, clean_path, creator_path):
            if p.exists():
                st = p.stat(); sig_parts.append((str(p), st.st_size, int(st.st_mtime)))
        sig = tuple(sig_parts)
        if not force and now - _FOLLOW_MONEY_LAST_MINE_TS < interval:
            return
        if not force and _FOLLOW_MONEY_LAST_SIG == sig:
            return
        from follow_money_graph import build_graph, write_outputs
        graph = build_graph(cfg)
        write_outputs(graph, cfg)
        _FOLLOW_MONEY_LAST_MINE_TS = now
        _FOLLOW_MONEY_LAST_SIG = sig
        if strategy and hasattr(strategy, 'reload_follow_money_graph'):
            strategy.reload_follow_money_graph()
        if pm and hasattr(pm, 'reload_follow_money_graph'):
            pm.reload_follow_money_graph()
        append_jsonl('follow_money_graph_runs.jsonl', {'ts': now_ts(), 'inputs': graph.get('inputs', {}), 'entry_wallets': len(graph.get('entry_wallets', [])), 'exit_wallets': len(graph.get('exit_wallets', [])), 'hot_creation_mints': len(graph.get('hot_creation_mints', []))})
    except Exception as e:
        append_jsonl('runtime_errors.jsonl', {'ts': now_ts(), 'where': 'follow_money_graph_build', 'error': str(e), 'trace': traceback.format_exc()[-1200:]})

def maybe_auto_run_hive_ai(cfg: Dict[str, Any], strategy: Any = None, pm: Any = None, force: bool = False) -> None:
    """Run lightweight AI sidecar and hot-reload hive_ai_scores.json.

    The sidecar is intentionally a local file-to-file scorer. It never sends
    data off-box and it never blocks trading if it fails.
    """
    global _HIVE_AI_LAST_RUN_TS, _HIVE_AI_LAST_SIG
    if not cfg.get('HIVE_AI_ENABLED', True):
        return
    if not cfg.get('HIVE_AI_AUTO_RUN_ENABLED', True) and not force:
        return
    diag_path = Path(cfg.get('DIAGNOSTIC_EXPORT_FILE','HIVE_BEHAVIOR_DIAGNOSTICS.jsonl'))
    trades_path = Path(cfg.get('TRADES_FILE','wallet_predator_trades.csv'))
    lifecycle_path = Path(cfg.get('HIVE_AI_LIFECYCLE_FILE','position_lifecycle.jsonl'))
    if not diag_path.exists():
        return
    now = time.time()
    interval = fnum(cfg.get('HIVE_AI_AUTO_RUN_INTERVAL_SEC'), 120.0)
    try:
        ds = diag_path.stat()
        ts = trades_path.stat() if trades_path.exists() else None
        ls = lifecycle_path.stat() if lifecycle_path.exists() else None
        sig = (ds.st_size, int(ds.st_mtime), ts.st_size if ts else 0, int(ts.st_mtime) if ts else 0, ls.st_size if ls else 0, int(ls.st_mtime) if ls else 0)
        if not force and now - _HIVE_AI_LAST_RUN_TS < interval:
            return
        if not force and _HIVE_AI_LAST_SIG == sig:
            return
        # Run the AI sidecar out-of-process so parser bugs or optional AI deps never
        # crash/slow the live WSS loop. This is advisory data, not a trading dependency.
        ai_cmd = [sys.executable, 'hive_ai_sidecar.py', '--config', str(cfg.get('_CONFIG_PATH','config.json')), '--once']
        r = subprocess.run(ai_cmd, cwd=str(Path.cwd()), capture_output=True, text=True, timeout=fnum(cfg.get('HIVE_AI_AUTO_RUN_TIMEOUT_SEC'), 45.0))
        if r.returncode != 0:
            append_jsonl('hive_ai_sidecar_errors.jsonl', {'ts': now_ts(), 'where': 'hive_ai_auto_run_subprocess', 'returncode': r.returncode, 'stdout': (r.stdout or '')[-2000:], 'stderr': (r.stderr or '')[-4000:]})
            return
        _HIVE_AI_LAST_RUN_TS = now
        _HIVE_AI_LAST_SIG = sig
        if strategy and hasattr(strategy, 'reload_hive_ai_scores'):
            strategy.reload_hive_ai_scores()
        if pm and hasattr(pm, 'reload_hive_ai_scores'):
            pm.reload_hive_ai_scores()
        append_jsonl('hive_ai_auto_runs.jsonl', {'ts': now_ts(), 'score_file': cfg.get('HIVE_AI_SCORES_FILE','hive_ai_scores.json'), 'hot_reloaded': bool(strategy or pm)})
    except SystemExit:
        pass
    except Exception as e:
        append_jsonl('runtime_errors.jsonl', {'ts': now_ts(), 'where': 'hive_ai_auto_run', 'error': str(e), 'trace': traceback.format_exc()[-2000:]})

def load_config(path: str = 'config.json') -> Dict[str, Any]:
    cfg = load_json(path, {}) or {}
    cfg['BOT_BUILD'] = BOT_BUILD  # override stale local config build string for dashboards/validators
    return cfg


def write_intel(cfg: Dict[str, Any], strategy: WalletPredatorStrategy, pm: PositionManager, counters: Dict[str, Any]) -> None:
    intel = {
        'bot_build': BOT_BUILD,
        'mode': cfg.get('MODE'),
        'boot_proof': boot_proof('config.json'),
        'active': {'has_position': pm.has_position(), 'positions': list(pm.positions.values())},
        'live_risk_state': load_json(cfg.get('LIVE_RISK_STATE_FILE','live_risk_state.json'), {}),
        'counters': counters,
        'strategy': {
            'name': 'wallet_predator_live_new_event_copytrader',
            'ml_enabled': False,
            'adaptive_agent_enabled': False,
            'entry_lanes': ['queen_dump_recovery_scout','queen_worker_front_run','queen_hunter_swarm_quorum','queen_cycle_ride','swarm_edge_auto_ride','post_sell_recovery_scout','rug_scout','hive_state_scout'],
            'focus': 'fresh incoming buys only; copy worker bees early, exit on queen/dump/hive-flip behavior, trail-only runners',
            'fresh_incoming_buy_only': bool(cfg.get('FRESH_INCOMING_BUY_ONLY', True)),
            'max_entry_event_age_sec': cfg.get('MAX_ENTRY_EVENT_AGE_SEC'),
        },
        'files': {
            'decisions': cfg.get('DECISIONS_FILE'),
            'trades': cfg.get('TRADES_FILE'),
            'positions': cfg.get('POSITIONS_FILE'),
            'profiles': cfg.get('PROFILE_EXPORT_FILE'),
            'single_diagnostic_file': cfg.get('DIAGNOSTIC_EXPORT_FILE','HIVE_BEHAVIOR_DIAGNOSTICS.jsonl'),
            'live_events': 'live_wallet_events.jsonl',
            'live_trades': 'live_trades.jsonl',
            'live_risk_state': cfg.get('LIVE_RISK_STATE_FILE','live_risk_state.json'),
            'ignored_live_guard_entries': 'ignored_live_guard_entries.jsonl',
            'ignored_live_risk_blocks': 'ignored_live_risk_blocks.jsonl',
            'queen_worker_graph': cfg.get('QUEEN_WORKER_GRAPH_FILE','queen_worker_graph_state.json'),
            'queen_worker_decisions': cfg.get('QUEEN_WORKER_DECISIONS_FILE','queen_worker_decisions.jsonl'),
            'queen_worker_exit_pressure': 'queen_worker_exit_pressure.jsonl',
        }
    }
    try:
        save_json('ucf_upgrade_intel.json', intel)
        save_json('performance_intel.json', intel)
    except Exception as e:
        append_jsonl('runtime_errors.jsonl', {'ts': now_ts(), 'where': 'write_intel', 'error': repr(e)})
        print(f'WRITE_INTEL_WARN err={e}')


def replay_sim_data(cfg: Dict[str, Any]) -> None:
    print(f"START wallet-predator build={BOT_BUILD} mode=sim-data")
    wi = WalletIntel(cfg)
    wi.export_profiles(cfg.get('PROFILE_EXPORT_FILE','wallet_predator_profiles.json'))
    creator_tracker = CreatorTracker(cfg) if cfg.get('CREATOR_CLUSTER_TRACKING_ENABLED', True) else None
    if creator_tracker: set_global_creator_tracker(creator_tracker)
    strat = WalletPredatorStrategy(cfg, wi, creator_tracker)
    pm = PositionManager(cfg, creator_tracker)
    maybe_auto_mine_swarm_edges(cfg, strat, pm, force=True)
    maybe_auto_run_hive_ai(cfg, strat, pm, force=True)
    counters = {'rows':0,'approved':0,'blocked':0,'buys':0,'sells':0,'by_setup':{},'block_reasons':{}}
    replay = Path(cfg.get('MARKET_BRAIN_REPLAY_FILE','sim_market_brain.jsonl'))
    if not replay.exists():
        snap = load_json('market_brain_snapshot.json', {}) or {}
        rows = snap.get('top') if isinstance(snap.get('top'), list) else []
    else:
        rows = iter_jsonl(replay)
    last_entry_ts = 0.0
    for row in rows:
        try:
            counters['rows'] += 1
            event_ts = int(fnum(row.get('ts'), counters['rows']))
            exits = pm.update_and_maybe_exit(row)
            exits += pm.stale_check_all(event_ts)
            counters['sells'] += len(exits)
            for _ex in exits:
                append_jsonl(cfg.get('DIAGNOSTIC_EXPORT_FILE','HIVE_BEHAVIOR_DIAGNOSTICS.jsonl'), {'ts':now_ts(),'type':'exit','result':_ex})
            if pm.has_position():
                continue
            if event_ts - last_entry_ts < fnum(cfg.get('ENTRY_COOLDOWN_SEC'),6.0):
                continue
            d = strat.decide(row)
            append_jsonl(cfg.get('DECISIONS_FILE','wallet_predator_decisions.jsonl'), {'ts':now_ts(), **d})
            append_jsonl(cfg.get('DIAGNOSTIC_EXPORT_FILE','HIVE_BEHAVIOR_DIAGNOSTICS.jsonl'), {'ts':now_ts(),'type':'decision','mint':d.get('mint'),'approved':d.get('approved'),'setup':d.get('setup'),'reason':d.get('reason'),'score':d.get('score'),'buy_sol':d.get('buy_sol'),'mc':d.get('mc'),'last_side':d.get('last_side'),'last_wallet':d.get('last_event_wallet'),'last_event_sol':d.get('last_event_sol'),'sell_pressure':d.get('sell_pressure'),'sell_buy_ratio':d.get('total_sell_buy_ratio'),'recent_buys':d.get('recent_buys'),'recent_sells':d.get('recent_sells'),'hive_state':d.get('hive_state'),'queen_signature':d.get('queen_signature'),'wallet_summary':d.get('wallet_summary')})
            if d.get('approved'):
                counters['approved'] += 1
                setup = d.get('setup','')
                counters['by_setup'][setup] = counters['by_setup'].get(setup,0)+1
                pm.buy(d)
                counters['buys'] += 1
                last_entry_ts = event_ts
            else:
                counters['blocked'] += 1
                r = d.get('reason','')
                counters['block_reasons'][r] = counters['block_reasons'].get(r,0)+1
            if counters['rows'] % 200 == 0:
                write_intel(cfg, strat, pm, counters)
        except Exception as e:
            append_jsonl('runtime_errors.jsonl', {'ts':now_ts(), 'where':'sim_loop', 'error':str(e), 'trace':traceback.format_exc()[-2000:]})
            continue
    for mint,pos in list(pm.positions.items()):
        pm.sell(mint, 1.0, fnum(pos.get('last_mc'), fnum(pos.get('entry_mc'),0.0)), 'sim_end_flatten')
    write_intel(cfg, strat, pm, counters)
    print(f"DONE rows={counters['rows']} buys={counters['buys']} sells={counters['sells']} approved={counters['approved']} diag={cfg.get('DIAGNOSTIC_EXPORT_FILE','HIVE_BEHAVIOR_DIAGNOSTICS.jsonl')}")


async def live_or_paper_ws(cfg: Dict[str, Any]) -> None:
    try:
        import websockets  # type: ignore
    except Exception:
        print('websockets package not installed; pip install websockets')
        return
    mode = cfg.get('MODE')
    print(f"START wallet-predator build={BOT_BUILD} mode={mode} live_signing={1 if mode=='live' and cfg.get('TRADE_ENABLED') else 0}")
    wi = WalletIntel(cfg); wi.export_profiles(cfg.get('PROFILE_EXPORT_FILE','wallet_predator_profiles.json'))
    creator_tracker = CreatorTracker(cfg) if cfg.get('CREATOR_CLUSTER_TRACKING_ENABLED', True) else None
    if creator_tracker: set_global_creator_tracker(creator_tracker)
    strat = WalletPredatorStrategy(cfg, wi, creator_tracker); pm = PositionManager(cfg, creator_tracker)
    feed_latency_monitor = FeedLatencyMonitor(cfg) if cfg.get('FEED_LATENCY_MONITOR_ENABLED', True) else None
    set_global_feed_latency_monitor(feed_latency_monitor)
    maybe_auto_mine_swarm_edges(cfg, strat, pm, force=True)
    maybe_auto_build_follow_money_graph(cfg, strat, pm, force=True)
    book = LiveMintBook(cfg)
    counters = {'rows':0,'approved':0,'blocked':0,'buys':0,'sells':0,'errors':0,'connect_attempts':0,'reconnects':0,'watchdog_reconnects':0,'ignored_stale_events':0,'ignored_zero_sol_buys':0,'pre_arm_hits':0,'by_setup':{},'block_reasons':{},'last_msg_ts':0,'wss_connected':False}

    async def process_live_row(row: Dict[str, Any], source: str = 'wss') -> None:
        try:
            counters['rows'] += 1
            counters['last_msg_ts'] = now_ts()
            try:
                pm.observe_own_wallet_trade(row)
            except Exception as e:
                append_jsonl('runtime_errors.jsonl', {'ts': now_ts(), 'where': 'observe_own_wallet_trade', 'source': source, 'error': str(e)})
            exits = await pm.update_and_maybe_exit_async(row)
            exits += await pm.stale_check_all_async(row.get('ts'))
            counters['sells'] += len(exits)
            for _ex in exits:
                append_jsonl(cfg.get('DIAGNOSTIC_EXPORT_FILE','HIVE_BEHAVIOR_DIAGNOSTICS.jsonl'), {'ts':now_ts(),'type':'exit','result':_ex})
            if pm.has_position():
                return
            d = strat.decide(row)
            append_jsonl(cfg.get('DECISIONS_FILE','wallet_predator_decisions.jsonl'), {'ts':now_ts(), **d})
            append_jsonl(cfg.get('DIAGNOSTIC_EXPORT_FILE','HIVE_BEHAVIOR_DIAGNOSTICS.jsonl'), {'ts':now_ts(),'type':'decision','source':source,'mint':d.get('mint'),'approved':d.get('approved'),'setup':d.get('setup'),'reason':d.get('reason'),'score':d.get('score'),'buy_sol':d.get('buy_sol'),'mc':d.get('mc'),'last_side':d.get('last_side'),'last_wallet':d.get('last_event_wallet'),'last_event_sol':d.get('last_event_sol'),'sell_pressure':d.get('sell_pressure'),'sell_buy_ratio':d.get('total_sell_buy_ratio'),'recent_buys':d.get('recent_buys'),'recent_sells':d.get('recent_sells'),'hive_state':d.get('hive_state'),'queen_signature':d.get('queen_signature'),'wallet_summary':d.get('wallet_summary'),'pre_armed':d.get('pre_armed')})
            if d.get('approved'):
                setup = d.get('setup','')
                counters['approved'] += 1
                counters['by_setup'][setup] = counters['by_setup'].get(setup,0)+1
                pos = await pm.buy_async(d)
                if pos:
                    counters['buys'] += 1
            else:
                counters['blocked'] += 1
                reason = str(d.get('reason','none')).split('|')[0]
                counters['block_reasons'][reason] = counters['block_reasons'].get(reason,0)+1
        except Exception as e:
            counters['errors'] += 1
            append_jsonl('runtime_errors.jsonl', {'ts': now_ts(), 'where': 'process_live_row', 'source': source, 'error': str(e), 'trace': traceback.format_exc()[-2000:]})
    # Use a market-data websocket for Pump token events. WSS_URL is often a
    # Solana RPC websocket and does not understand subscribeNewToken, so only
    # use it as a feed if explicitly requested.
    urls = []
    candidate_urls = [cfg.get('WSS_FEED_URL'), cfg.get('PUMPDEV_WS_URL'), cfg.get('PUMPPORTAL_WS_URL')]
    if cfg.get('USE_RPC_WSS_AS_FEED', False):
        candidate_urls.append(cfg.get('WSS_URL'))
    for u in candidate_urls:
        if u and str(u).strip() and str(u).strip() not in urls:
            urls.append(str(u).strip())
    if not urls:
        urls = ['wss://pumpdev.io/ws']
    heartbeat_sec = fnum(cfg.get('HEARTBEAT_SEC'), 15.0)
    token_subscribe_enabled = cfg.get('WSS_TOKEN_TRADE_SUBSCRIBE_ENABLED', True)
    token_subscribe_pump_only = cfg.get('WSS_TOKEN_TRADE_SUBSCRIBE_PUMP_ONLY', True)
    max_token_subscriptions = inum(cfg.get('WSS_MAX_ACTIVE_TOKEN_SUBSCRIPTIONS'), 35)
    token_subscribe_cooldown = fnum(cfg.get('WSS_TOKEN_SUBSCRIBE_COOLDOWN_SEC'), 0.35)
    last_token_subscribe_ts = 0.0
    resub_every = fnum(cfg.get('RESUBSCRIBE_EVERY_SEC'), 45.0)
    no_msg_timeout = fnum(cfg.get('WSS_NO_MESSAGE_RECONNECT_SEC'), 75.0)
    backoff = 1.0
    url_i = 0
    while True:
        url = urls[url_i % len(urls)]
        url_i += 1
        try:
            counters['connect_attempts'] += 1
            print(f"WSS_CONNECTING url={url} attempt={counters['connect_attempts']} reconnects={counters['reconnects']}")
            async with websockets.connect(url, ping_interval=fnum(cfg.get('WSS_PING_INTERVAL_SEC'), 30.0), ping_timeout=fnum(cfg.get('WSS_PING_TIMEOUT_SEC'), 30.0), close_timeout=5, open_timeout=fnum(cfg.get('WSS_OPEN_TIMEOUT_SEC'), 10.0), max_queue=inum(cfg.get('WSS_MAX_QUEUE'), 10000)) as ws:
                backoff = 1.0
                counters['wss_connected'] = True
                counters['last_msg_ts'] = now_ts()
                print(f"WSS_CONNECTED url={url} attempt={counters['connect_attempts']}")
                subscribe_payloads = [{'method':'subscribeNewToken'}, {'method':'subscribeNewToken','keys':[]}]
                if str(url).startswith('wss://pumpportal'):
                    subscribe_payloads = [{'method':'subscribeNewToken'}]
                for payload in subscribe_payloads:
                    try:
                        await ws.send(json.dumps(payload))
                        print(f"WSS_SUB_NEW_TOKEN_SENT payload={payload}")
                    except Exception as e:
                        append_jsonl('runtime_errors.jsonl', {'ts': now_ts(), 'where': 'subscribeNewToken', 'url': url, 'error': str(e)})
                last_heartbeat = time.time()
                last_resub = time.time()
                last_prearm_check = 0.0
                while True:
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=min(no_msg_timeout, 2.0))
                    except asyncio.TimeoutError:
                        now = time.time()
                        if now - counters.get('last_msg_ts', 0) >= no_msg_timeout:
                            counters['watchdog_reconnects'] += 1
                            print(f"WSS_WATCHDOG_RECONNECT no_msg_for={no_msg_timeout:.1f}s rows={counters['rows']}")
                            raise RuntimeError('wss_no_message_watchdog')
                        if now - last_prearm_check >= 2.0:
                            last_prearm_check = now
                            for pre_row in check_pending_token_watch(cfg, book):
                                counters['pre_arm_hits'] += 1
                                await process_live_row(pre_row, 'pre_arm')
                        continue
                    now = time.time()
                    if now - last_prearm_check >= 2.0:
                        last_prearm_check = now
                        for pre_row in check_pending_token_watch(cfg, book):
                            counters['pre_arm_hits'] += 1
                            await process_live_row(pre_row, 'pre_arm')
                    if now - last_heartbeat >= heartbeat_sec:
                        print(f"HEARTBEAT build={BOT_BUILD} rows={counters['rows']} buys={counters['buys']} sells={counters['sells']} positions={len(pm.positions)} connects={counters.get('connect_attempts',0)} reconnects={counters['reconnects']} blocked={counters['blocked']} ignored_stale={counters.get('ignored_stale_events',0)} ignored_zero={counters.get('ignored_zero_sol_buys',0)}")
                        try:
                            if cfg.get('HIVE_REPUTATION_AUTO_MINE_ENABLED', True):
                                wi.export_profiles(cfg.get('PROFILE_EXPORT_FILE','wallet_predator_profiles.json'))
                        except Exception as e:
                            append_jsonl('runtime_errors.jsonl', {'ts': now_ts(), 'where': 'hive_reputation_refresh', 'error': str(e)})
                        maybe_auto_mine_swarm_edges(cfg, strat, pm, force=False)
                        maybe_auto_build_follow_money_graph(cfg, strat, pm, force=False)
                        maybe_auto_run_hive_ai(cfg, strat, pm, force=False)
                        write_intel(cfg, strat, pm, counters)
                        last_heartbeat = now
                    if token_subscribe_enabled and now - last_resub >= resub_every:
                        for mint in list(book.subscribed)[-inum(cfg.get('MAX_RESUB_MINTS'), 20):]:
                            try:
                                await ws.send(json.dumps({'method':'subscribeTokenTrade','keys':[mint]}))
                            except Exception:
                                pass
                        last_resub = now
                    try:
                        obj = json.loads(msg)
                    except Exception:
                        continue
                    objs = obj if isinstance(obj, list) else [obj]
                    for ev in objs:
                        try:
                            if not isinstance(ev, dict):
                                continue
                            try:
                                if feed_latency_monitor:
                                    feed_latency_monitor.record_event(ev)
                            except Exception as e:
                                append_jsonl('feed_latency_errors.jsonl', {'ts': now_ts(), 'where': 'main_record_event', 'error': str(e)[:400]})
                            mint = ev.get('mint') or ev.get('token') or ev.get('ca') or ev.get('address')
                            if mint and mint not in book.subscribed:
                                book.remember_new_token(mint, fnum(ev.get('marketCapSol') or ev.get('marketCap') or ev.get('mc'), 28.0))
                                try:
                                    append_jsonl(cfg.get('NEW_TOKEN_EVENTS_FILE','new_token_events.jsonl'), {'ts': now_ts(), 'mint': mint, 'wallet': ev.get('traderPublicKey') or ev.get('wallet') or ev.get('creator') or ev.get('user') or '', 'sig': ev.get('signature') or ev.get('sig') or ev.get('txSignature') or '', 'raw_type': ev.get('txType') or ev.get('type') or ev.get('method') or ev.get('eventType') or '', 'mc': ev.get('marketCapSol') or ev.get('marketCap') or ev.get('mc')})
                                except Exception:
                                    pass
                                try:
                                    if creator_tracker:
                                        creator_tracker.schedule_new_token_event(ev)
                                except Exception as e:
                                    append_jsonl('creator_tracker_warnings.jsonl', {'ts': now_ts(), 'where': 'main_schedule_new_token', 'mint': mint, 'error': str(e)[:400]})
                                should_sub = bool(token_subscribe_enabled)
                                if token_subscribe_pump_only and not str(mint).endswith('pump'):
                                    should_sub = False
                                if max_token_subscriptions > 0 and len(book.subscribed) >= max_token_subscriptions:
                                    should_sub = False
                                if should_sub and (time.time() - last_token_subscribe_ts) < token_subscribe_cooldown:
                                    should_sub = False
                                if should_sub:
                                    book.subscribed.add(mint)
                                    try:
                                        await ws.send(json.dumps({'method':'subscribeTokenTrade','keys':[mint]}))
                                        last_token_subscribe_ts = time.time()
                                        print(f"WSS_SUB_TOKEN_TRADES mint={short_mint(mint)} active={len(book.subscribed)}/{max_token_subscriptions}")
                                    except Exception as e:
                                        append_jsonl('runtime_errors.jsonl', {'ts':now_ts(), 'where':'subscribeTokenTrade', 'mint':mint, 'error':str(e)})
                                else:
                                    # Remember it as seen without adding pressure to the websocket.
                                    if cfg.get('LOG_SKIPPED_TOKEN_SUBSCRIPTIONS', False):
                                        append_jsonl('skipped_token_subscriptions.jsonl', {'ts': now_ts(), 'mint': mint, 'active': len(book.subscribed), 'reason': 'cap_or_filter_or_cooldown'})
                            row = book.update_from_ws(ev)
                            counters['ignored_stale_events'] = getattr(book, 'ignored_stale', 0)
                            counters['ignored_zero_sol_buys'] = getattr(book, 'ignored_zero_sol', 0)
                            if row is None:
                                continue
                            await process_live_row(row, 'wss')
                        except Exception as e:
                            counters['errors'] += 1
                            append_jsonl('runtime_errors.jsonl', {'ts':now_ts(), 'where':'event_loop', 'error':str(e), 'trace':traceback.format_exc()[-2000:]})
                            continue
        except Exception as e:
            counters['errors'] += 1
            counters['wss_connected'] = False
            counters['reconnects'] += 1
            append_jsonl('runtime_errors.jsonl', {'ts':now_ts(), 'where':'wss_outer_loop', 'url':url, 'error':str(e), 'recoverable': ('keepalive ping timeout' in str(e).lower() or 'wss_no_message_watchdog' in str(e).lower()), 'trace':traceback.format_exc()[-2000:]})
            print(f"WSS_RECONNECT_AFTER_ERROR error={str(e)[:180]} backoff={backoff:.1f}s")
            write_intel(cfg, strat, pm, counters)
            await asyncio.sleep(backoff)
            backoff = min(fnum(cfg.get('MAX_RECONNECT_BACKOFF_SEC'), 30.0), backoff * 1.6)


def _live_guard(cfg: Dict[str, Any]) -> None:
    if cfg.get('MODE') != 'live':
        return
    if not cfg.get('TRADE_ENABLED'):
        raise SystemExit('LIVE blocked: set TRADE_ENABLED=true in config.json')
    if cfg.get('LIVE_CONFIRM') != 'I_UNDERSTAND_LIVE_TRADING_RISK':
        raise SystemExit('LIVE blocked: LIVE_CONFIRM must equal I_UNDERSTAND_LIVE_TRADING_RISK')
    if not (str(cfg.get('RPC_URL') or '').strip() and str(cfg.get('WSS_URL') or '').strip()):
        raise SystemExit('LIVE blocked: config.json must include hard-coded RPC_URL and WSS_URL')
    if not (str(cfg.get('MAIN_PRIVATE_KEY_BASE58') or '').strip() or (cfg.get('MAIN_SECRET_JSON') or [])):
        raise SystemExit('LIVE blocked: config.json must include MAIN_PRIVATE_KEY_BASE58 or MAIN_SECRET_JSON')


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--mode', default=None, choices=['sim','sim-data','paper-wss','live'])
    ap.add_argument('--config', default='config.json')
    ap.add_argument('--bundle', action='store_true')
    args = ap.parse_args()
    cfg = load_config(args.config)
    cfg['_CONFIG_PATH'] = args.config
    if args.mode: cfg['MODE'] = args.mode
    if cfg.get('MODE') == 'sim':
        cfg['MODE'] = 'paper-wss'
        cfg['SIM_REALISTIC_LIVE_PARITY'] = True
    if args.bundle:
        from diagnostic_export import build_export
        print(build_export(cfg)); return
    _live_guard(cfg)
    mode = cfg.get('MODE','sim-data')
    if mode in ('sim','paper-wss','live'):
        asyncio.run(live_or_paper_ws(cfg))
    else:
        replay_sim_data(cfg)

if __name__ == '__main__':
    main()
