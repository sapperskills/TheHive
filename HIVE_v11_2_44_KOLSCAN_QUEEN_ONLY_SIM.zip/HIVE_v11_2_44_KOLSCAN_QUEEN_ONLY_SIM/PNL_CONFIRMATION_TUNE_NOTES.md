# HIVE v11.2.38 PnL confirmation tune

Your SIM snapshot showed pressure_runner_lift fired 21 trades with only 9.5% WR while fast_sniper_fee_safe was the only strong realized exit. This patch makes pressure_runner_lift much harder to trigger and converts wallet intel from a bonus into confirmation.

## Main behavior changes

- `pressure_runner_lift` now requires priority wallet confirmation or extreme clean flow.
- Pressure runner score raised to 900 and recent buy SOL raised to 15.
- Sell pressure cap is 0.30 and sell/buy ratio cap is 0.55.
- Hot play strict filter is applied: ratio 0.32, min buy SOL 0.65, min buyers 5, max age 720s.
- Trail-only runner exit is tightened to 2.8%.
- Added ATH drop protection: after a 7.5% high, exit on a 2.5% drop from peak.
- Fast sniper ideal net profit target lowered to 5% so the bot takes the fee-safe exit more often.

## Commands

Run after a SIM session:

```powershell
python win_rate_optimizer.py
python pnl_edge_miner.py
python apply_optimizer_patch.py --dry-run
```

To apply optimizer output to config:

```powershell
python apply_optimizer_patch.py --apply
```

Keep `PNL_AUTO_PATCH_DRY_RUN=true` for live. Do not let an auto-loop change live config without reviewing the patch.
