#!/usr/bin/env python3
from __future__ import annotations
import json, csv, time, collections
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path('.').resolve()

def _read_json(path: str, default: Any):
    try:
        p=ROOT/path
        if p.exists(): return json.loads(p.read_text(encoding='utf-8', errors='ignore'))
    except Exception:
        pass
    return default

def _tail_jsonl(path: str, n: int = 500) -> List[Dict[str, Any]]:
    p=ROOT/path
    if not p.exists(): return []
    rows=[]
    try:
        lines=p.read_text(encoding='utf-8', errors='ignore').splitlines()[-n:]
        for line in lines:
            try: rows.append(json.loads(line))
            except Exception: rows.append({'raw': line[:2000]})
    except Exception as e:
        rows.append({'error': str(e)})
    return rows

def _read_trades(path='wallet_predator_trades.csv'):
    p=ROOT/path
    if not p.exists(): return []
    try:
        return list(csv.DictReader(p.open(encoding='utf-8', errors='ignore')))
    except Exception:
        return []

def _f(x, d=0.0):
    try: return float(x)
    except Exception: return d

def _summarize_trades(rows):
    by=collections.defaultdict(lambda:{'buys':0,'sells':0,'pnl_sol':0.0,'gross_pnl_sol':0.0,'estimated_cost_sol':0.0,'wins':0})
    total={'buys':0,'sells':0,'pnl_sol':0.0,'gross_pnl_sol':0.0,'estimated_cost_sol':0.0,'wins':0}
    for r in rows:
        setup=r.get('setup') or 'unknown'
        side=r.get('side') or ''
        d=by[setup]
        if side.endswith('BUY'):
            d['buys']+=1; total['buys']+=1
        if side.endswith('SELL') and 'FAIL' not in side:
            d['sells']+=1; total['sells']+=1
            pnl=_f(r.get('pnl_sol')); gross=_f(r.get('gross_pnl_sol')); cost=_f(r.get('estimated_cost_sol'))
            d['pnl_sol']+=pnl; d['gross_pnl_sol']+=gross; d['estimated_cost_sol']+=cost; d['wins']+= 1 if pnl>0 else 0
            total['pnl_sol']+=pnl; total['gross_pnl_sol']+=gross; total['estimated_cost_sol']+=cost; total['wins']+= 1 if pnl>0 else 0
    return {'total': total, 'by_setup': dict(by)}

def _summarize_decisions(path='wallet_predator_decisions.jsonl'):
    p=ROOT/path
    reasons=collections.Counter(); setups=collections.Counter(); approved=0; n=0
    last=[]
    if not p.exists(): return {}
    with p.open(encoding='utf-8', errors='ignore') as f:
        for line in f:
            try: d=json.loads(line)
            except Exception: continue
            n+=1
            if d.get('approved'):
                approved+=1; setups[d.get('setup') or 'unknown']+=1
            else:
                reasons[str(d.get('reason') or '')[:180]]+=1
            if len(last)>=300: last.pop(0)
            last.append({k:d.get(k) for k in ('ts','mint','approved','setup','reason','score','buy_sol','mc','last_side','last_event_wallet','last_event_sol','sell_pressure','total_sell_buy_ratio','recent_buys','recent_sells')})
    return {'rows':n,'approved':approved,'approval_rate':approved/max(1,n),'approved_setups':setups.most_common(50),'blockers':reasons.most_common(100),'last_300_compact':last}

def build_export(cfg: Dict[str, Any] | None = None, out: str | None = None) -> str:
    cfg = cfg or _read_json('config.json', {})
    out = out or cfg.get('DIAGNOSTIC_SNAPSHOT_FILE','HIVE_DIAGNOSTIC_EXPORT.json')
    trades=_read_trades(cfg.get('TRADES_FILE','wallet_predator_trades.csv'))
    data={
        'export_ts': int(time.time()),
        'bot_build': cfg.get('BOT_BUILD'),
        'config_key_settings': {k:cfg.get(k) for k in sorted(cfg) if k.startswith(('QUEEN_','HIVE_','LIVE_','PNL_','FAST_SNIPER','RUNNER','WALLET_DUMP','EARLY_DUMP','MAX_','MIN_','SCOUT','POST_SELL','SWARM_EDGE'))},
        'trade_summary': _summarize_trades(trades),
        'trades': trades[-500:],
        'decision_summary': _summarize_decisions(cfg.get('DECISIONS_FILE','wallet_predator_decisions.jsonl')),
        'live_risk_state': _read_json(cfg.get('LIVE_RISK_STATE_FILE','live_risk_state.json'), {}),
        'positions': _read_json(cfg.get('POSITIONS_FILE','wallet_predator_positions.json'), {}),
        'wallet_profiles': _read_json(cfg.get('PROFILE_EXPORT_FILE','wallet_predator_profiles.json'), {}),
        'wallet_reputation': _read_json(cfg.get('WALLET_REPUTATION_FILE','wallet_reputation.json'), {}),
        'swarm_edge_profiles': _read_json(cfg.get('SWARM_EDGE_PROFILE_FILE','swarm_edge_profiles.json'), {}),
        'queen_hive_report': _read_json('queen_hive_report.json', {}),
        'queen_worker_graph_state': _read_json(cfg.get('QUEEN_WORKER_GRAPH_FILE','queen_worker_graph_state.json'), {}),
        'recent_behavior_events': _tail_jsonl(cfg.get('DIAGNOSTIC_EXPORT_FILE','HIVE_BEHAVIOR_DIAGNOSTICS.jsonl'), 1000),
        'recent_queen_cycle_candidates': _tail_jsonl('queen_cycle_ride_candidates.jsonl', 500),
        'recent_queen_dump_recovery_candidates': _tail_jsonl('queen_dump_recovery_candidates.jsonl', 500),
        'recent_swarm_edge_auto_candidates': _tail_jsonl('swarm_edge_auto_candidates.jsonl', 500),
        'recent_swarm_edge_exit_warning_events': _tail_jsonl('swarm_edge_exit_warning_events.jsonl', 500),
        'recent_exit_pressure': _tail_jsonl('queen_worker_exit_pressure.jsonl', 500),
        'recent_runtime_errors': _tail_jsonl('runtime_errors.jsonl', 500),
        'recent_wallet_sol_balance': _tail_jsonl('live_wallet_sol_balance.jsonl', 500),
    }
    Path(out).write_text(json.dumps(data, indent=2, sort_keys=True), encoding='utf-8')
    return out

if __name__ == '__main__':
    print(build_export())
