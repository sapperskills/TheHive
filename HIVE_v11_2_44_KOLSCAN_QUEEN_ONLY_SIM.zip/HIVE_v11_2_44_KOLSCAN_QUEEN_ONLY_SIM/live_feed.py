from __future__ import annotations

import json
import time
from pathlib import Path
from collections import defaultdict, deque
from typing import Any, Deque, Dict, List, Set
from util import fnum, inum, now_ts, append_jsonl, append_csv, load_json, save_json, PROCESS_START_TS


def _tail_jsonl(path: str | Path, max_lines: int = 1000) -> List[Dict[str, Any]]:
    """Cheap best-effort JSONL tail reader used by pre-arm checks."""
    try:
        p = Path(path)
        if not p.exists():
            return []
        lines = p.read_text(encoding='utf-8', errors='ignore').splitlines()[-max_lines:]
        out: List[Dict[str, Any]] = []
        for line in lines:
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    out.append(obj)
            except Exception:
                continue
        return out
    except Exception as e:
        try:
            append_jsonl('pre_arm_errors.jsonl', {'ts': now_ts(), 'where': '_tail_jsonl', 'path': str(path), 'error': str(e)[:400]})
        except Exception:
            pass
        return []


def check_pending_token_watch(cfg: Dict[str, Any], book: 'LiveMintBook') -> List[Dict[str, Any]]:
    """Inject synthetic high-priority rows for wallets pre-funded by a controller.

    Runs in the live process, but all errors are swallowed/logged so the trading
    loop never depends on this file bridge.
    """
    if not cfg.get('PRE_ARM_SKIP_SOFT_BLOCKERS', True):
        # The watcher can still be enabled through pending file, but skip logic is
        # a core part of this lane. If disabled, do not create synthetic rows.
        return []
    try:
        now = now_ts()
        pending_path = Path(cfg.get('PENDING_TOKEN_WATCH_FILE', 'pending_token_watch.json'))
        pending = load_json(pending_path, {}) or {}
        if not isinstance(pending, dict) or not pending:
            return []
        creator_map_file = cfg.get('CREATOR_WALLET_MAP_FILE', 'creator_wallet_map.jsonl')
        creator_rows = _tail_jsonl(creator_map_file, 1500)
        by_creator: Dict[str, Dict[str, Any]] = {}
        for ev in creator_rows:
            creator = str(ev.get('creator_wallet') or ev.get('creator') or '')
            mint = str(ev.get('mint') or '')
            ts = inum(ev.get('ts'), 0)
            if creator and mint and now - ts <= inum(cfg.get('PENDING_TOKEN_WATCH_WINDOW_SEC'), 300):
                old = by_creator.get(creator)
                if old is None or ts >= inum(old.get('ts'), 0):
                    by_creator[creator] = ev
        hits: List[Dict[str, Any]] = []
        changed = False
        for wallet, entry in list(pending.items()):
            if not isinstance(entry, dict):
                pending.pop(wallet, None); changed = True; continue
            watch_until = inum(entry.get('watch_until_ts'), 0)
            if watch_until and watch_until < now:
                append_jsonl('pre_arm_misses.jsonl', {'ts': now, 'new_wallet': wallet, 'controller': entry.get('controller'), 'cluster_id': entry.get('cluster_id'), 'funded_ts': entry.get('funded_ts'), 'reason': 'watch_expired'})
                pending.pop(wallet, None); changed = True; continue
            hit = by_creator.get(str(entry.get('new_wallet') or wallet))
            if not hit:
                continue
            mint = str(hit.get('mint') or '')
            if not mint:
                continue
            funded_ts = inum(entry.get('funded_ts'), now)
            seconds_notice = max(0, now - funded_ts)
            mc = fnum(hit.get('mc') or hit.get('marketCapSol') or hit.get('marketCap'), book.last_mc.get(mint, 28.0))
            book.remember_new_token(mint, mc)
            row = book.row(mint)
            row.update({
                'ts': now,
                'mint': mint,
                'mc': mc,
                'age': max(0, now - inum(hit.get('ts'), now)),
                'setup': 'pre_armed_controller_cluster',
                'bot_pattern': 'pre_armed_controller_cluster',
                'pre_armed': True,
                'pre_arm_cluster_id': entry.get('cluster_id'),
                'pre_arm_controller': entry.get('controller'),
                'pre_arm_seconds_notice': seconds_notice,
                'pre_arm_score_override': fnum(cfg.get('PRE_ARM_SCORE_OVERRIDE'), 180.0),
                'last_side': 'buy',
                'last_event_fresh': True,
                'last_event_age_sec': 0,
                'last_event_wallet': str(entry.get('new_wallet') or wallet),
                'live_event_wallets': list(set(row.get('live_event_wallets') or []) | {str(entry.get('new_wallet') or wallet), str(entry.get('controller') or '')}),
            })
            hits.append(row)
            append_jsonl('pre_arm_hits.jsonl', {'ts': now, 'mint': mint, 'cluster_id': entry.get('cluster_id'), 'seconds_notice': seconds_notice, 'pre_arm_score_override': row.get('pre_arm_score_override')})
            pending.pop(wallet, None); changed = True
        if changed:
            save_json(pending_path, pending)
        return hits
    except Exception as e:
        try:
            append_jsonl('pre_arm_errors.jsonl', {'ts': now_ts(), 'where': 'check_pending_token_watch', 'error': str(e)[:700]})
        except Exception:
            pass
        return []

class LiveMintBook:
    """Rolling event book built only from fresh websocket buy/sell events.

    v11.2.1 rule: entries must originate from a new incoming BUY after process start.
    We still record sells for exits, but stale historical/poll events are ignored.
    """
    def __init__(self, cfg: Dict[str, Any]):
        self.cfg = cfg
        self.created_ts: Dict[str, int] = {}
        self.events: Dict[str, Deque[Dict[str, Any]]] = defaultdict(deque)
        self.last_mc: Dict[str, float] = {}
        self.subscribed: Set[str] = set()
        self.max_events = inum(cfg.get('LIVE_BOOK_MAX_EVENTS_PER_MINT'), 300)
        self.process_start_ts = PROCESS_START_TS
        self.ignored_stale = 0
        self.ignored_zero_sol = 0
        self.ignored_non_trade = 0
        self.ignored_unwatched_wallet = 0
        self.buy_sell_only_headers = ['ts', 'raw_ts', 'mint', 'side', 'wallet', 'sol', 'mc', 'sig', 'source']

    def remember_new_token(self, mint: str, mc: float = 28.0) -> None:
        if not mint:
            return
        self.created_ts.setdefault(mint, now_ts())
        if mc > 0:
            self.last_mc[mint] = mc

    def _event_ts_from_obj(self, obj: Dict[str, Any]) -> int:
        # Prefer real chain/feed timestamps when present; otherwise receive time.
        for key in ('blockTime', 'timestamp', 'time', 'created_timestamp', 'createdAt', 'ts'):
            v = obj.get(key)
            if v is None or v == '':
                continue
            try:
                fv = float(v)
                # milliseconds -> seconds
                if fv > 10_000_000_000:
                    fv = fv / 1000.0
                if fv > 1_000_000_000:
                    return int(fv)
            except Exception:
                continue
        return now_ts()

    def _is_stale_raw_event(self, raw_ts: int) -> bool:
        if not self.cfg.get('FRESH_ONLY_IGNORE_PRE_START_EVENTS', True):
            return False
        grace = fnum(self.cfg.get('FRESH_START_GRACE_SEC'), 2.0)
        if raw_ts < self.process_start_ts - grace:
            return True
        max_age = fnum(self.cfg.get('MAX_RAW_EVENT_AGE_SEC'), 12.0)
        if max_age > 0 and now_ts() - raw_ts > max_age:
            return True
        return False

    def _side(self, obj: Dict[str, Any]) -> str:
        tx_type = str(obj.get('txType') or obj.get('type') or obj.get('side') or obj.get('action') or '').lower()
        if tx_type in ('buy', 'sell'):
            return tx_type
        if obj.get('isBuy') is True:
            return 'buy'
        if obj.get('isSell') is True:
            return 'sell'
        sol_delta = fnum(obj.get('sol_delta'), 0.0)
        if sol_delta < 0:
            return 'buy'
        if sol_delta > 0:
            return 'sell'
        return ''

    def _sol_amount(self, obj: Dict[str, Any], side: str) -> float:
        for key in ('solAmount', 'sol_amount', 'amountSol', 'sol', 'sol_delta', 'vSolInBondingCurveDelta'):
            if key in obj and obj.get(key) not in (None, ''):
                return abs(fnum(obj.get(key), 0.0))
        # Pump feeds sometimes include virtual SOL in bonding curve, but that is not trade size.
        return 0.0

    def _wallet_watchlist(self) -> Set[str]:
        vals = []
        for key in ('WSS_SIGNAL_WALLETS', 'WATCHED_CREATOR_WALLETS', 'TRACKED_SIGNAL_WALLETS'):
            v = self.cfg.get(key)
            if isinstance(v, list):
                vals.extend([str(x).strip() for x in v if str(x).strip()])
            elif isinstance(v, str) and v.strip():
                vals.extend([x.strip() for x in v.replace(';', ',').split(',') if x.strip()])
        return set(vals)

    def _is_known_non_trade_action(self, obj: Dict[str, Any]) -> bool:
        text = ' '.join(str(obj.get(k) or '').lower() for k in ('txType','type','side','action','instruction','method','eventType'))
        non_trade_words = (
            'createtoken', 'create_token', 'create token', 'initialize', 'mintto',
            'associated token', 'ata', 'anchor self', 'self cpi', 'transfer',
            'balance change', 'funded', 'stake', 'metadata'
        )
        if any(w in text for w in non_trade_words) and not any(w in text for w in ('buy', 'sell', 'swap')):
            return True
        return False

    def _strict_trade_ok(self, obj: Dict[str, Any], side: str, wallet: str, sol: float) -> tuple[bool, str]:
        if not self.cfg.get('STRICT_SWAP_ONLY', True):
            return True, ''
        if side not in ('buy', 'sell'):
            return False, 'no_buy_sell_side'
        if self._is_known_non_trade_action(obj):
            return False, 'known_non_trade_action'
        # For raw parsed tx feeds, require the direction to make economic sense.
        # BUY = wallet loses SOL / gains token. SELL = wallet gains SOL / loses token.
        token_delta = fnum(obj.get('token_delta'), fnum(obj.get('tokenDelta'), 0.0))
        sol_delta = fnum(obj.get('sol_delta'), fnum(obj.get('solDelta'), 0.0))
        if self.cfg.get('STRICT_BALANCE_DELTA_CONFIRMATION', False):
            if side == 'buy' and not (token_delta > 0 and sol_delta < 0):
                return False, 'buy_delta_not_confirmed'
            if side == 'sell' and not (token_delta < 0 and sol_delta > 0):
                return False, 'sell_delta_not_confirmed'
        if side == 'buy' and self.cfg.get('IGNORE_ZERO_SOL_BUYS', True) and sol <= 0.0:
            return False, 'zero_or_unknown_sol_buy'
        if not wallet and self.cfg.get('STRICT_REQUIRE_WALLET', True):
            return False, 'missing_wallet'
        watch = self._wallet_watchlist()
        if watch and wallet and wallet not in watch and self.cfg.get('FILTER_TO_WSS_SIGNAL_WALLETS', False):
            return False, 'wallet_not_in_signal_watchlist'
        return True, ''

    def _record_clean_buy_sell(self, ev: Dict[str, Any], mint: str) -> None:
        row = {
            'ts': ev.get('ts'), 'raw_ts': ev.get('raw_ts'), 'mint': mint, 'side': ev.get('side'),
            'wallet': ev.get('wallet'), 'sol': ev.get('sol'), 'mc': ev.get('mc'), 'sig': ev.get('sig'),
            'source': ev.get('source') or 'wss_trade'
        }
        append_jsonl(self.cfg.get('BUY_SELL_ONLY_JSONL', 'buy_sell_only.jsonl'), row)
        append_csv(self.cfg.get('BUY_SELL_ONLY_CSV', 'buy_sell_only.csv'), self.buy_sell_only_headers, row)

    def update_from_ws(self, obj: Dict[str, Any]) -> Dict[str, Any] | None:
        mint = obj.get('mint') or obj.get('token') or obj.get('ca') or obj.get('address')
        if not mint:
            return None
        raw_ts = self._event_ts_from_obj(obj)
        if self._is_stale_raw_event(raw_ts):
            self.ignored_stale += 1
            append_jsonl('ignored_stale_events.jsonl', {'ts': now_ts(), 'raw_ts': raw_ts, 'mint': mint, 'reason': 'pre_start_or_old_raw_event'})
            return None
        side = self._side(obj)
        ts = now_ts()
        mc = fnum(obj.get('marketCapSol') or obj.get('marketCap') or obj.get('mc') or obj.get('vSolInBondingCurve'), self.last_mc.get(mint, 28.0))
        wallet = obj.get('traderPublicKey') or obj.get('wallet') or obj.get('user') or obj.get('maker') or obj.get('owner') or ''
        sol = self._sol_amount(obj, side)
        ok, reject_reason = self._strict_trade_ok(obj, side, wallet, sol)
        if not ok:
            # We still remember new token/MC, but do not let CreateToken, ATA, transfers,
            # self-CPI, funding, or old/non-wallet noise feed copy-trade decisions.
            self.remember_new_token(mint, mc)
            if reject_reason == 'zero_or_unknown_sol_buy':
                self.ignored_zero_sol += 1
                append_jsonl('ignored_zero_sol_buys.jsonl', {'ts': ts, 'raw_ts': raw_ts, 'mint': mint, 'wallet': wallet, 'reason': reject_reason})
            elif reject_reason == 'wallet_not_in_signal_watchlist':
                self.ignored_unwatched_wallet += 1
                if not self.cfg.get('QUIET_NON_TRADE_WSS', True):
                    append_jsonl('ignored_unwatched_wss_wallets.jsonl', {'ts': ts, 'raw_ts': raw_ts, 'mint': mint, 'wallet': wallet, 'side': side, 'reason': reject_reason})
            else:
                self.ignored_non_trade += 1
                if self.cfg.get('RECORD_NO_TRADE_WSS_TX', False):
                    append_jsonl('ignored_non_trade_wss.jsonl', {'ts': ts, 'raw_ts': raw_ts, 'mint': mint, 'wallet': wallet, 'side': side, 'reason': reject_reason})
            return None
        ev = {
            'ts': ts,
            'raw_ts': raw_ts,
            'side': side,
            'wallet': wallet,
            'sol': sol,
            'mc': mc,
            'sig': obj.get('signature') or obj.get('sig') or obj.get('txSignature') or obj.get('transactionSignature') or '',
            'fresh_after_start': raw_ts >= self.process_start_ts - fnum(self.cfg.get('FRESH_START_GRACE_SEC'), 2.0),
            'source': obj.get('source') or 'wss_trade',
            'raw': {k: obj.get(k) for k in list(obj.keys())[:25]},
        }
        self.remember_new_token(mint, mc)
        q = self.events[mint]
        q.append(ev)
        while len(q) > self.max_events:
            q.popleft()
        self.last_mc[mint] = mc
        append_jsonl(self.cfg.get('LIVE_WALLET_EVENTS_FILE', 'live_wallet_events.jsonl'), {'ts': ts, 'raw_ts': raw_ts, 'mint': mint, 'side': side, 'wallet': wallet, 'sol': sol, 'mc': mc, 'sig': ev.get('sig')})
        self._record_clean_buy_sell(ev, mint)
        return self.row(mint)

    def row(self, mint: str) -> Dict[str, Any]:
        ts = now_ts()
        win = fnum(self.cfg.get('LIVE_FLOW_WINDOW_SEC'), 24.0)
        q = self.events.get(mint) or deque()
        recent = [e for e in q if ts - inum(e.get('ts'), ts) <= win]
        buys = [e for e in recent if e.get('side') == 'buy']
        sells = [e for e in recent if e.get('side') == 'sell']
        all_buys = [e for e in q if e.get('side') == 'buy']
        all_sells = [e for e in q if e.get('side') == 'sell']
        buyers = {e.get('wallet') for e in buys if e.get('wallet')}
        sellers = {e.get('wallet') for e in sells if e.get('wallet')}
        mc = self.last_mc.get(mint, 28.0)
        first_mc = q[0].get('mc', mc) if q else mc
        above_open = (mc / first_mc - 1.0) if first_mc else 0.0
        high_mc = max([fnum(e.get('mc'), mc) for e in q] + [mc])
        pullback = (high_mc - mc) / high_mc if high_mc > 0 else 0.0
        sell_pressure = len(sells) / max(1, len(recent))
        ratio = len(all_sells) / max(1, len(all_buys))
        age = ts - self.created_ts.get(mint, ts)
        buy_accel = len(buys) / max(1.0, win / 10.0)
        buy_sol_recent = sum(fnum(e.get('sol'), 0.0) for e in buys)
        sell_sol_recent = sum(fnum(e.get('sol'), 0.0) for e in sells)
        last = recent[-1] if recent else {}
        last_event_ts = inum(last.get('ts'), 0)
        last_event_age = ts - last_event_ts if last_event_ts else 999999
        quality = 25 + len(buys)*8 + len(buyers)*8 + max(0, len(buys)-len(sells))*7 + min(buy_sol_recent, 5.0)*8
        breakout = 15 + max(0.0, above_open)*80 + min(len(buys), 10)*4 - len(sells)*3 - pullback*25
        rug = max(0.0, min(100.0, 18 + sell_pressure*45 + ratio*9 - len(buyers)*2 + max(0, len(sells)-len(buys))*6))
        return {
            'ts': ts,
            'mint': mint,
            'mc': mc,
            'age': age,
            'setup': 'live_new_flow',
            'bot_pattern': 'live_wallet_flow',
            'quality_score': round(quality, 2),
            'breakout_score': round(max(0.0, breakout), 2),
            'rug_risk': round(rug, 2),
            'recent_buys': len(buys),
            'recent_sells': len(sells),
            'recent_buyers': len(buyers),
            'recent_sellers': len(sellers),
            'total_buys': len(all_buys),
            'total_sells': len(all_sells),
            'sell_pressure': round(sell_pressure, 4),
            'total_sell_buy_ratio': round(ratio, 4),
            'buy_accel': round(buy_accel, 4),
            'pullback_pct': round(pullback, 4),
            'above_open_pct': round(above_open, 4),
            'buy_sol_recent': round(buy_sol_recent, 9),
            'sell_sol_recent': round(sell_sol_recent, 9),
            'live_wallet_events': list(recent)[-20:],
            'live_event_wallets': list({e.get('wallet') for e in recent if e.get('wallet')}),
            'last_side': last.get('side') or '',
            'last_event_ts': last_event_ts,
            'last_event_age_sec': last_event_age,
            'last_event_wallet': last.get('wallet') or '',
            'last_event_sol': fnum(last.get('sol'), 0.0),
            'last_event_sig': last.get('sig') or '',
            'last_event_fresh': bool(last) and last_event_age <= fnum(self.cfg.get('MAX_ENTRY_EVENT_AGE_SEC'), 8.0),
            'ignored_stale_events': self.ignored_stale,
            'ignored_zero_sol_buys': self.ignored_zero_sol,
            'ignored_non_trade_wss': self.ignored_non_trade,
            'ignored_unwatched_wallets': self.ignored_unwatched_wallet,
        }
