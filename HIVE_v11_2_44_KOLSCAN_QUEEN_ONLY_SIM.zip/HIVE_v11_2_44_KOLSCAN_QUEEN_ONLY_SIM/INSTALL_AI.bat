@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ==========================================
echo HIVE Lightweight AI Installer

echo This installs optional local AI packages.
echo If TabPFN fails on your GPU, the bot still uses sklearn fallback.
echo ==========================================

python --version
if errorlevel 1 (
  echo ERROR: Python not found in PATH.
  pause
  exit /b 1
)

python -m pip install --upgrade pip
python -m pip install pandas numpy scikit-learn joblib

echo.
echo Optional TabPFN install. This can be heavier.
echo Installing TabPFN...
python -m pip install tabpfn

if errorlevel 1 (
  echo.
  echo WARNING: TabPFN install failed. This is OK.
  echo The AI sidecar will use scikit-learn fallback.
) else (
  echo TabPFN installed.
)

echo.
echo DONE. You can now run START_LIVE.bat.
echo AI sidecar output: hive_ai_scores.json
pause
endlocal
