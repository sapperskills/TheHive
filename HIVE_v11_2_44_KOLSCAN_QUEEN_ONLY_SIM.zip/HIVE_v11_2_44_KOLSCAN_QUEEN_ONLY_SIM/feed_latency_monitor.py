from __future__ import annotations

"""Rolling websocket feed latency diagnostics for THE HIVE.

The monitor is intentionally tiny and safe: every public method catches its own
errors and writes to feed_latency_errors.jsonl instead of raising into trading.
"""

from collections import deque
from typing import Any, Deque, Dict, Optional

from util import append_jsonl, fnum, inum, now_ts

_GLOBAL_FEED_LATENCY_MONITOR: Optional["FeedLatencyMonitor"] = None


def set_global_feed_latency_monitor(monitor: Optional["FeedLatencyMonitor"]) -> None:
    global _GLOBAL_FEED_LATENCY_MONITOR
    _GLOBAL_FEED_LATENCY_MONITOR = monitor


def get_global_feed_latency_monitor() -> Optional["FeedLatencyMonitor"]:
    return _GLOBAL_FEED_LATENCY_MONITOR


class FeedLatencyMonitor:
    """Track block-time to receive-time latency for the live websocket feed."""

    def __init__(self, cfg: Dict[str, Any]):
        self.cfg = cfg
        self.window: Deque[Dict[str, Any]] = deque(maxlen=500)
        self.last_snapshot_ts = 0
        self.last_health = "UNKNOWN"
        self.fast_ms = fnum(cfg.get("FEED_LATENCY_FAST_THRESHOLD_MS"), 1500.0)
        self.slow_ms = fnum(cfg.get("FEED_LATENCY_SLOW_THRESHOLD_MS"), 4000.0)

    def _warn(self, where: str, err: Any, extra: Dict[str, Any] | None = None) -> None:
        try:
            append_jsonl("feed_latency_errors.jsonl", {"ts": now_ts(), "where": where, "error": str(err)[:500], **(extra or {})})
        except Exception:
            pass

    def _event_block_time(self, event_dict: Dict[str, Any]) -> int:
        for key in ("block_time", "blockTime", "blockTimeSec", "timestamp", "time", "created_timestamp", "createdAt", "raw_ts", "ts"):
            v = event_dict.get(key)
            if v in (None, ""):
                continue
            try:
                fv = float(v)
                if fv > 10_000_000_000:
                    fv /= 1000.0
                if fv > 1_000_000_000:
                    return int(fv)
            except Exception:
                continue
        return 0

    def record_event(self, event_dict: Dict[str, Any]) -> None:
        """Record latency for one websocket event, then periodically log stats."""
        if not self.cfg.get("FEED_LATENCY_MONITOR_ENABLED", True):
            return
        try:
            if not isinstance(event_dict, dict):
                return
            ts = now_ts()
            block_time = self._event_block_time(event_dict)
            if block_time <= 0:
                return
            latency_ms = max(0.0, (ts - block_time) * 1000.0)
            self.window.append({"ts": ts, "block_time": block_time, "latency_ms": latency_ms})
            if ts - self.last_snapshot_ts >= 60:
                self.log_snapshot()
        except Exception as e:
            self._warn("record_event", e)

    def _percentile(self, vals: list[float], pct: float) -> float:
        if not vals:
            return 0.0
        vals = sorted(vals)
        idx = int(round((len(vals) - 1) * pct))
        return float(vals[max(0, min(len(vals) - 1, idx))])

    def get_stats(self) -> Dict[str, Any]:
        """Return rolling latency statistics over the last 500 events."""
        try:
            ts = now_ts()
            vals = [fnum(x.get("latency_ms"), 0.0) for x in self.window]
            p90 = self._percentile(vals, 0.90)
            if not vals:
                health = "UNKNOWN"
            elif p90 < self.fast_ms:
                health = "FAST"
            elif p90 <= self.slow_ms:
                health = "DEGRADED"
            else:
                health = "SLOW"
            return {
                "p50_ms": round(self._percentile(vals, 0.50), 2),
                "p90_ms": round(p90, 2),
                "p99_ms": round(self._percentile(vals, 0.99), 2),
                "max_ms": round(max(vals) if vals else 0.0, 2),
                "events_last_60s": sum(1 for x in self.window if ts - inum(x.get("ts"), 0) <= 60),
                "feed_health": health,
            }
        except Exception as e:
            self._warn("get_stats", e)
            return {"p50_ms": 0, "p90_ms": 0, "p99_ms": 0, "max_ms": 0, "events_last_60s": 0, "feed_health": "UNKNOWN"}

    def log_snapshot(self) -> None:
        """Append one stats snapshot and emit transition alerts."""
        try:
            stats = self.get_stats()
            ts = now_ts()
            self.last_snapshot_ts = ts
            append_jsonl("feed_latency_log.jsonl", {"ts": ts, **stats})
            health = str(stats.get("feed_health") or "UNKNOWN")
            print(f"FEED_LATENCY health={health} p50={stats.get('p50_ms')}ms p90={stats.get('p90_ms')}ms events60={stats.get('events_last_60s')}")
            if self.last_health not in ("UNKNOWN", health) and health in ("DEGRADED", "SLOW"):
                append_jsonl("feed_alerts.jsonl", {"ts": ts, "alert": "feed_degraded", "p90_ms": stats.get("p90_ms"), "feed_health": health})
            self.last_health = health
        except Exception as e:
            self._warn("log_snapshot", e)

    def should_cluster_exit_be_trusted(self) -> bool:
        """Cluster sell exits are trusted only when p90 latency is under 2s."""
        try:
            stats = self.get_stats()
            trusted = fnum(stats.get("p90_ms"), 999999.0) < 2000.0
            if not trusted:
                append_jsonl("feed_alerts.jsonl", {"ts": now_ts(), "warn": "cluster_sell_exit_feed_slow", "latency_p90_ms": stats.get("p90_ms"), "feed_health": stats.get("feed_health")})
            return trusted
        except Exception as e:
            self._warn("should_cluster_exit_be_trusted", e)
            return False
