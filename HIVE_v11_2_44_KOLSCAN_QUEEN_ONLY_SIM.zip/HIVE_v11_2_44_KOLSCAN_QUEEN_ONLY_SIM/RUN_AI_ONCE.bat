@echo off
setlocal
cd /d "%~dp0"
echo Running HIVE AI sidecar once...
python hive_ai_sidecar.py --config config.json --once
pause
endlocal
