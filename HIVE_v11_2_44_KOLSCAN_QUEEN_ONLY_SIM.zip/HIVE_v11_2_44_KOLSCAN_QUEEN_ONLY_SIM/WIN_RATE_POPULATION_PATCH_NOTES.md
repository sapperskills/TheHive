# HIVE v11.2.36 Win-Rate + File Population Patch

## Main fixes

1. **Blocked fake WSS adoption pollution**
   - `executor.py` now requires a confirmed public-key match before adopting any WSS buy/sell as your own wallet trade.
   - This prevents random tape buys from becoming `live_wss_adopted_untracked_buy` positions when `PUBLIC_KEY` is blank/unresolved.

2. **Higher win-rate SIM play ranking**
   - `live_money_flow_ranker.py` now favors cleaner/stabler early plays:
     - token age 25-900 sec
     - recent buy SOL >= 0.45
     - unique recent buyers >= 4
     - sell/buy ratio <= 0.45
     - drawdown from high <= 28%
     - last-side-buy/last-3-buy confirmation
     - capped single-event SOL to stop bogus WSS rows from dominating

3. **Win-rate optimizer report**
   - New `win_rate_optimizer.py` writes `WIN_RATE_OPTIMIZER_REPORT.json`.
   - It does a fast forward replay on the SIM/WSS tape and compares filter sets.
   - On the uploaded data:
     - old/lax style filter replay was ~31.96% WR before tightening
     - patched higher-win-rate filter replay is ~54.08% WR
     - very strict filter replay is ~64.23% WR but takes fewer plays

4. **Dashboard population checks**
   - Dashboard now shows:
     - Win-Rate Optimizer card
     - Output File Health card
     - `/api/win_rate_optimizer`
     - `/api/output_file_health`
   - Dashboard refreshes `HOT_SIM_PLAYS.json`, `RECENT_PROFIT_WALLETS.json`, and `WIN_RATE_OPTIMIZER_REPORT.json` if the WSS tape is newer.

## Run after a SIM session

```bat
python win_rate_optimizer.py
python wallet_profit_export.py
python dashboard_server.py
```

Use `FOLLOW THE MONEY` for current-run mints and `Win-Rate Optimizer` to decide whether to use the normal or very strict settings.
