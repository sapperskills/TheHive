from __future__ import annotations

"""Live trading adapter for UCF Wallet Predator.

This module intentionally keeps secrets in config.json only. It does not read
private keys from environment variables. It supports PumpPortal/PumpDev style
`trade-local` endpoints that return a serialized Solana transaction, signs it,
and sends it through the configured RPC URL.
"""

import base64
import json
import time
from typing import Any, Dict, Optional, Tuple

from util import append_jsonl, fnum, now_ts, short_mint


def _decode_secret(config: Dict[str, Any]):
    """Return a solders Keypair from config MAIN_PRIVATE_KEY_BASE58 or MAIN_SECRET_JSON."""
    try:
        from solders.keypair import Keypair  # type: ignore
    except Exception as e:  # pragma: no cover - dependency only required for live
        raise RuntimeError("solders is required for LIVE trading: pip install solders solana aiohttp") from e

    b58 = str(config.get("MAIN_PRIVATE_KEY_BASE58") or "").strip()
    arr = config.get("MAIN_SECRET_JSON") or []
    if b58 and "PUT_" not in b58:
        return Keypair.from_base58_string(b58)
    if isinstance(arr, list) and arr:
        return Keypair.from_bytes(bytes(int(x) for x in arr))
    raise RuntimeError("No live private key in config.json. Set MAIN_PRIVATE_KEY_BASE58 or MAIN_SECRET_JSON.")


class LiveTrader:
    def __init__(self, config: Dict[str, Any]):
        self.cfg = config
        self.rpc_url = str(config.get("RPC_URL") or "").strip()
        self.trade_url = str(
            config.get("PUMPDEV_TRADE_LOCAL_URL")
            or config.get("PUMPPORTAL_TRADE_LOCAL_URL")
            or "https://pumpportal.fun/api/trade-local"
        )
        self.public_key = str(config.get("PUBLIC_KEY") or "").strip()
        self.keypair = None
        self._ready = False
        if config.get("MODE") == "live" and config.get("TRADE_ENABLED"):
            self._init_keypair()

    def _init_keypair(self) -> None:
        if not self.rpc_url:
            raise RuntimeError("RPC_URL is required for LIVE mode.")
        self.keypair = _decode_secret(self.cfg)
        self.public_key = str(self.keypair.pubkey())
        self._ready = True

    def enabled(self) -> bool:
        return bool(self.cfg.get("MODE") == "live" and self.cfg.get("TRADE_ENABLED") and self._ready)

    async def _post_trade_local(self, session, payload: Dict[str, Any]) -> bytes:
        async with session.post(self.trade_url, json=payload, timeout=fnum(self.cfg.get("LIVE_TRADE_HTTP_TIMEOUT_SEC"), 8.0)) as resp:
            data = await resp.read()
            if resp.status >= 300:
                text = data.decode("utf-8", errors="ignore")[:500]
                raise RuntimeError(f"trade-local HTTP {resp.status}: {text}")
            # Endpoints usually return raw tx bytes, base64, or JSON containing transaction.
            ctype = resp.headers.get("content-type", "")
            if "application/json" in ctype:
                obj = json.loads(data.decode("utf-8"))
                tx = obj.get("transaction") or obj.get("tx") or obj.get("serializedTransaction") or obj.get("data")
                if isinstance(tx, str):
                    try:
                        return base64.b64decode(tx)
                    except Exception:
                        return bytes(json.loads(tx))
                if isinstance(tx, list):
                    return bytes(tx)
                raise RuntimeError(f"trade-local JSON response missing transaction keys: {list(obj)[:8]}")
            # Raw bytes are common from PumpPortal trade-local.
            return bytes(data)

    async def _sign_and_send(self, tx_bytes: bytes) -> str:
        """Sign a trade-local transaction and submit with raw JSON-RPC.

        v11.2.6: default live sends use skipPreflight=true. Preflight simulation
        can reject fast Pump.fun/PumpPortal trades even when the transaction is
        otherwise worth sending in this latency race. We still keep all strategy,
        wallet, live-risk, SOL-balance, and one-position safeguards before send.
        """
        try:
            from solders.transaction import VersionedTransaction  # type: ignore
            from solders.message import to_bytes_versioned  # type: ignore
        except Exception as e:  # pragma: no cover
            raise RuntimeError("Live send requires solders: pip install solders") from e
        if self.keypair is None:
            self._init_keypair()
        tx = VersionedTransaction.from_bytes(tx_bytes)
        sig = self.keypair.sign_message(to_bytes_versioned(tx.message))
        signed = VersionedTransaction.populate(tx.message, [sig])
        tx64 = base64.b64encode(bytes(signed)).decode("ascii")

        skip_default = bool(self.cfg.get("LIVE_SKIP_PREFLIGHT", True))
        try:
            return await self._rpc_send_transaction(tx64, skip_preflight=skip_default)
        except Exception as e:
            err = str(e)
            # If the local/RPC simulation blocks the tx, optionally retry once with
            # skipPreflight=true. This avoids old behavior where preflight stopped
            # all live buys. If skip was already true, re-raise the original error.
            should_retry = (not skip_default) and bool(self.cfg.get("LIVE_PREFLIGHT_RETRY_SKIP", True)) and (
                "preflight" in err.lower() or "simulation" in err.lower() or "sendtransaction error" in err.lower()
            )
            if should_retry:
                append_jsonl("live_trades.jsonl", {
                    "ts": now_ts(), "ok": False, "action": "send_retry",
                    "reason": "preflight_retry_with_skip", "error": err[:700]
                })
                print(f"LIVE_PREFLIGHT_RETRY_SKIP error={err[:180]}")
                return await self._rpc_send_transaction(tx64, skip_preflight=True)
            raise

    async def _rpc_send_transaction(self, tx64: str, skip_preflight: bool | None = None) -> str:
        """Submit base64 transaction through JSON-RPC without solana-py internals."""
        import aiohttp
        if not self.rpc_url:
            raise RuntimeError("RPC_URL is required for LIVE sendTransaction")
        if skip_preflight is None:
            skip_preflight = bool(self.cfg.get("LIVE_SKIP_PREFLIGHT", True))
        opts = {
            "encoding": "base64",
            "skipPreflight": bool(skip_preflight),
            "maxRetries": int(self.cfg.get("LIVE_SEND_MAX_RETRIES", 3)),
        }
        # Keep commitment only as an RPC hint. skipPreflight=true still sends fast.
        if self.cfg.get("LIVE_PREFLIGHT_COMMITMENT"):
            opts["preflightCommitment"] = str(self.cfg.get("LIVE_PREFLIGHT_COMMITMENT", "processed"))
        params = [tx64, opts]
        payload = {"jsonrpc": "2.0", "id": int(time.time() * 1000) % 1000000, "method": "sendTransaction", "params": params}
        timeout = fnum(self.cfg.get("LIVE_RPC_HTTP_TIMEOUT_SEC"), fnum(self.cfg.get("LIVE_TRADE_HTTP_TIMEOUT_SEC"), 8.0))
        if bool(self.cfg.get("LIVE_LOG_PREFLIGHT_ERRORS", True)):
            append_jsonl("live_trades.jsonl", {"ts": now_ts(), "ok": None, "action": "sendTransaction", "skipPreflight": bool(skip_preflight), "maxRetries": opts["maxRetries"]})
        async with aiohttp.ClientSession() as session:
            async with session.post(self.rpc_url, json=payload, timeout=timeout) as resp:
                text = await resp.text()
                if resp.status >= 300:
                    raise RuntimeError(f"RPC sendTransaction HTTP {resp.status}: {text[:500]}")
                try:
                    obj = json.loads(text)
                except Exception:
                    raise RuntimeError(f"RPC sendTransaction non-json response: {text[:500]}")
        if obj.get("error"):
            raise RuntimeError(f"RPC sendTransaction error skipPreflight={bool(skip_preflight)}: {obj.get('error')}")
        sig = obj.get("result")
        if not sig:
            raise RuntimeError(f"RPC sendTransaction missing result: {str(obj)[:500]}")
        return str(sig)


    async def _rpc_call(self, method: str, params: list) -> Dict[str, Any]:
        """Small raw JSON-RPC helper used for live balance/sweep checks."""
        import aiohttp
        if not self.rpc_url:
            raise RuntimeError("RPC_URL is required for JSON-RPC calls")
        payload = {"jsonrpc": "2.0", "id": int(time.time() * 1000) % 1000000, "method": method, "params": params}
        timeout = fnum(self.cfg.get("LIVE_RPC_HTTP_TIMEOUT_SEC"), fnum(self.cfg.get("LIVE_TRADE_HTTP_TIMEOUT_SEC"), 8.0))
        async with aiohttp.ClientSession() as session:
            async with session.post(self.rpc_url, json=payload, timeout=timeout) as resp:
                text = await resp.text()
                if resp.status >= 300:
                    raise RuntimeError(f"RPC {method} HTTP {resp.status}: {text[:500]}")
                try:
                    obj = json.loads(text)
                except Exception:
                    raise RuntimeError(f"RPC {method} non-json response: {text[:500]}")
        if obj.get("error"):
            raise RuntimeError(f"RPC {method} error: {obj.get('error')}")
        return obj

    async def _sum_token_account_values(self, vals: list, target_mint: str) -> Tuple[int, float]:
        raw_total = 0
        ui_total = 0.0
        for it in vals or []:
            info = (((it.get("account") or {}).get("data") or {}).get("parsed") or {}).get("info") or {}
            acct_mint = str(info.get("mint") or "")
            if target_mint and acct_mint and acct_mint != str(target_mint):
                continue
            ta = info.get("tokenAmount") or {}
            raw_s = str(ta.get("amount") or "0")
            try:
                raw_total += int(raw_s)
            except Exception:
                pass
            ui = ta.get("uiAmount")
            if ui is None:
                try:
                    ui = float(ta.get("uiAmountString") or 0.0)
                except Exception:
                    ui = 0.0
            ui_total += float(ui or 0.0)
        return raw_total, ui_total

    async def get_token_balance_raw_ui(self, mint: str) -> Tuple[int, float]:
        """Return total token balance for this wallet/mint as (raw_amount, ui_amount).

        v11.2.10: modeled after the older UCF balance logic: try direct mint
        filter first, then optionally scan wallet token accounts if direct lookup
        returns zero/unknown. This keeps local position state reconciled with the
        actual wallet and prevents leftover sell loops.
        """
        if not self.public_key:
            return 0, 0.0
        params = [
            self.public_key,
            {"mint": mint},
            {"encoding": "jsonParsed", "commitment": str(self.cfg.get("COMMITMENT", "processed"))},
        ]
        try:
            obj = await self._rpc_call("getTokenAccountsByOwner", params)
            vals = (((obj.get("result") or {}).get("value")) or [])
            raw_total, ui_total = await self._sum_token_account_values(vals, mint)
            # Some RPCs are slow to expose brand-new mint-filtered accounts. Fall
            # back to scanning token programs when direct lookup returns zero.
            if raw_total <= 0 and bool(self.cfg.get("LIVE_TOKEN_BALANCE_SCAN_ALL_ON_ZERO", True)):
                scan_raw, scan_ui = await self._scan_token_balances_raw_ui(mint)
                if scan_raw > raw_total or scan_ui > ui_total:
                    raw_total, ui_total = scan_raw, scan_ui
            append_jsonl("live_token_balances.jsonl", {"ts": now_ts(), "mint": mint, "raw": raw_total, "ui": ui_total})
            return raw_total, ui_total
        except Exception as e:
            append_jsonl("live_token_balances.jsonl", {"ts": now_ts(), "mint": mint, "error": str(e)[:500]})
            return -1, -1.0

    async def _scan_token_balances_raw_ui(self, mint: str) -> Tuple[int, float]:
        """Fallback scan of owned SPL token accounts, inspired by v10.5 tracking."""
        owners = []
        if bool(self.cfg.get("LIVE_TOKEN_BALANCE_SCAN_TOKEN_PROGRAM", True)):
            owners.append({"programId": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"})
        if bool(self.cfg.get("LIVE_TOKEN_BALANCE_SCAN_TOKEN2022", False)):
            owners.append({"programId": "TokenzQdBNbLqP5VEhdkAS6EPGkKVQhQx6kPp3S5B"})
        total_raw, total_ui = 0, 0.0
        for filt in owners:
            try:
                obj = await self._rpc_call("getTokenAccountsByOwner", [
                    self.public_key,
                    filt,
                    {"encoding": "jsonParsed", "commitment": str(self.cfg.get("COMMITMENT", "processed"))},
                ])
                vals = (((obj.get("result") or {}).get("value")) or [])
                raw, ui = await self._sum_token_account_values(vals, mint)
                total_raw += raw
                total_ui += ui
            except Exception as e:
                append_jsonl("live_token_balances.jsonl", {"ts": now_ts(), "mint": mint, "scan_error": str(e)[:300], "filter": filt})
        return total_raw, total_ui


    async def get_sol_balance(self) -> float:
        """Return wallet SOL balance using RPC getBalance.

        Used only for live PnL reconciliation. If RPC fails, return -1 so the
        engine can keep trading and fall back to fee-estimated PnL.
        """
        if not self.public_key:
            return -1.0
        try:
            old_timeout = self.cfg.get("LIVE_RPC_HTTP_TIMEOUT_SEC")
            if self.cfg.get("LIVE_PNL_RPC_TIMEOUT_SEC") is not None:
                self.cfg["LIVE_RPC_HTTP_TIMEOUT_SEC"] = self.cfg.get("LIVE_PNL_RPC_TIMEOUT_SEC")
            obj = await self._rpc_call("getBalance", [self.public_key, {"commitment": str(self.cfg.get("COMMITMENT", "processed"))}])
            if old_timeout is not None:
                self.cfg["LIVE_RPC_HTTP_TIMEOUT_SEC"] = old_timeout
            lamports = (((obj.get("result") or {}).get("value")))
            bal = float(lamports or 0) / 1_000_000_000.0
            append_jsonl("live_wallet_sol_balance.jsonl", {"ts": now_ts(), "wallet": self.public_key, "sol_balance": bal})
            return bal
        except Exception as e:
            append_jsonl("live_wallet_sol_balance.jsonl", {"ts": now_ts(), "wallet": self.public_key, "error": str(e)[:500]})
            return -1.0

    async def execute(self, action: str, mint: str, amount: Any, denominated_in_sol: bool = True) -> Tuple[bool, str]:
        """Execute a pump trade. Returns (ok, signature_or_error)."""
        import aiohttp
        if not self.enabled():
            return False, "live_trader_not_enabled"
        payload = {
            "publicKey": self.public_key,
            "action": action,
            "mint": mint,
            "amount": amount,
            "denominatedInSol": "true" if denominated_in_sol else "false",
            "slippage": fnum(self.cfg.get("SLIPPAGE_BPS"), 1000) / 100.0,
            "priorityFee": fnum(self.cfg.get("PRIORITY_FEE_SOL"), 0.00005),
            "pool": self.cfg.get("PUMP_POOL", "pump"),
        }
        try:
            async with aiohttp.ClientSession() as session:
                tx_bytes = await self._post_trade_local(session, payload)
                sig = await self._sign_and_send(tx_bytes)
            append_jsonl("live_trades.jsonl", {"ts": now_ts(), "ok": True, "action": action, "mint": mint, "amount": amount, "sig": sig})
            print(f"LIVE_{action.upper()}_OK mint={short_mint(mint)} sig={sig}")
            return True, sig
        except Exception as e:
            err = str(e)
            append_jsonl("live_trades.jsonl", {"ts": now_ts(), "ok": False, "action": action, "mint": mint, "amount": amount, "error": err})
            print(f"LIVE_{action.upper()}_FAIL mint={short_mint(mint)} error={err[:220]}")
            return False, err
