@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title HIVE v11.2.36 LIVE Profit Unclog
if not exist config.json copy default_config.json config.json

if not exist swarm_edge_miner.py (
  echo ERROR: swarm_edge_miner.py is missing from this folder.
  echo You are not in the v11.2.36 extracted core folder.
  pause
  exit /b 1
)
if not exist diagnostic_export.py (
  echo ERROR: diagnostic_export.py is missing from this folder.
  pause
  exit /b 1
)

start "HIVE Dashboard" cmd /k "cd /d "%~dp0" && python dashboard_server.py"
start "HIVE GRAPH BUILDER" python funding_graph_builder.py

:loop
echo ==========================================
echo Starting HIVE LIVE with AI-safe + pressure-runner lift + graph builder
echo Build: v11.2.36
echo Miner/AI run safely in advisory mode; trading continues if AI fails.
echo ==========================================
python swarm_edge_miner.py
python hive_ai_sidecar.py --config config.json --once
python main.py --mode live
set ERR=%ERRORLEVEL%
echo LIVE bot stopped with code %ERR%. Restarting in 5 seconds...
timeout /t 5 /nobreak >nul
goto loop
