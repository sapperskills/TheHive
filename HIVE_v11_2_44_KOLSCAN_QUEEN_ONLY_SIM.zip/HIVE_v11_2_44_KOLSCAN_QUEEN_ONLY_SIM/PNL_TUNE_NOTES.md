# HIVE v11.2.37 PnL Tune Notes

This patch is aimed at improving SIM/live trade selection quality, not increasing trade count.

## What changed

1. **Fee-aware entry bias**
   - Your latest SIM shows ~0.00295 SOL cost on a 0.05 SOL test buy, or about 5.9% drag.
   - Filters were tightened so entries need stronger flow before they are worth taking.

2. **Bad data / corrupted tape guard**
   - Blocks non-`pump` mint strings when `PNL_REQUIRE_PUMPFUN_MINT=true`.
   - Blocks suspicious event sizes where token amounts appear to be treated like SOL.
   - Blocks obviously malformed market caps.

3. **Pressure runner is now quality-only**
   - Higher minimum score.
   - Higher recent buy count / unique buyer requirements.
   - Requires larger recent buy SOL and top net buy SOL.
   - Lower allowed sell pressure and sell/buy ratio.
   - Danger/dump-risk wallets must be zero.

4. **No repeated revenge trading on same mint**
   - `MAX_ENTRIES_PER_MINT_PER_RUN=1`.
   - Profit cooldown raised to 15 minutes.
   - Loss/hard-stop cooldowns raised.

5. **Trail is fee-aware**
   - Trail activation moved from tiny gross movement to `0.085`, so it should not trail out before clearing fees.

## New script

Run:

```powershell
python pnl_edge_miner.py
```

It writes:

- `PNL_EDGE_REPORT.json`
- `PNL_EDGE_CONFIG_PATCH.json`

Use that after each SIM run to identify which entry filters actually produced positive net PnL.

## Important read

The current sample is small: 21 closed SIM trades, only 2 net winners. Do not overfit to one run. The safest path is to run this stricter config, collect 100+ closed trades, then rerun `pnl_edge_miner.py` and adjust from the report.
