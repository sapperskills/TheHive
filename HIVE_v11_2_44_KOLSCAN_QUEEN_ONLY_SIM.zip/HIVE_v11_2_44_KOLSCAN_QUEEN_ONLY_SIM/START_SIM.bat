@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title HIVE v11.2.29 PAPER/SIM Auto Swarm Edge Miner
if not exist config.json copy default_config.json config.json
start "HIVE Dashboard" cmd /k "cd /d "%~dp0" && python dashboard_server.py"
:loop
python swarm_edge_miner.py
python main.py --mode paper-wss
set ERR=%ERRORLEVEL%
echo PAPER bot stopped with code %ERR%. Restarting in 5 seconds...
timeout /t 5 /nobreak >nul
goto loop
