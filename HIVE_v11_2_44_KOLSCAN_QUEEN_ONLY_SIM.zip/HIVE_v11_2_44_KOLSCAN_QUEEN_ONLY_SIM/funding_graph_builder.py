#!/usr/bin/env python3
from __future__ import annotations

"""Offline funding graph builder for THE HIVE.

Standalone process. It shares no memory with the live trader and communicates
only through JSON/JSONL files on disk. All RPC operations are async, rate-limited,
and best-effort so this process can be killed/restarted independently.
"""

import argparse
import asyncio
import hashlib
import json
import time
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import aiohttp

from util import append_jsonl, fnum, inum, load_json, now_ts, save_json

LAMPORTS_PER_SOL = 1_000_000_000


class RpcLimiter:
    """Global 25 calls / 10 sec limiter plus bounded concurrency."""

    def __init__(self, cfg: Dict[str, Any]):
        self.max_calls = max(1, inum(cfg.get("FUNDING_GRAPH_RPC_MAX_CALLS_PER_10S"), 25))
        self.window_sec = 10.0
        self.calls: List[float] = []
        self.sem = asyncio.Semaphore(5)
        self.lock = asyncio.Lock()

    async def wait(self) -> None:
        async with self.lock:
            now = time.time()
            self.calls = [x for x in self.calls if now - x < self.window_sec]
            if len(self.calls) >= self.max_calls:
                sleep_for = self.window_sec - (now - self.calls[0]) + 0.05
                await asyncio.sleep(max(0.05, sleep_for))
            self.calls.append(time.time())


class FundingGraphBuilder:
    """Continuously traces wallet funding relationships and controller alerts."""

    def __init__(self, cfg: Dict[str, Any]):
        self.cfg = cfg
        self.data_dir = Path(cfg.get("DATA_DIR") or ".")
        self.rpc_url = str(cfg.get("RPC_URL") or "").strip()
        self.graph_path = self.data_dir / "funding_graph.json"
        self.cluster_path = self.data_dir / "cluster_map.json"
        self.watch_path = self.data_dir / "controller_watch_list.json"
        self.pending_path = self.data_dir / "pending_token_watch.json"
        self.creator_map_path = self.data_dir / str(cfg.get("CREATOR_WALLET_MAP_FILE", "creator_wallet_map.jsonl"))
        self.graph_lock = asyncio.Lock()
        self.cluster_lock = asyncio.Lock()
        self.watch_lock = asyncio.Lock()
        self.pending_lock = asyncio.Lock()
        self.limiter = RpcLimiter(cfg)
        self.session: Optional[aiohttp.ClientSession] = None
        self.wallet_last_checked: Dict[str, int] = {}
        self.wallets_processed_this_hour = 0
        self.hour_bucket = int(time.time() // 3600)
        self.seen_controller_sigs: Dict[str, Set[str]] = {}
        self.creator_map_offset = 0
        self.graph: Dict[str, Any] = self._normalize_graph(load_json(self.graph_path, {}) or {})
        self.cluster_map: Dict[str, Any] = load_json(self.cluster_path, {}) or {}
        self.watch_list: Dict[str, Any] = load_json(self.watch_path, {}) or {}
        self.pending_watch: Dict[str, Any] = load_json(self.pending_path, {}) or {}

    def _normalize_graph(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        # The previous creator_tracker stored {creators/controllers/mints}; the
        # builder uses wallet->record. Preserve legacy keys while adding wallet records.
        if not isinstance(raw, dict):
            return {}
        out = dict(raw)
        creators = raw.get("creators") if isinstance(raw.get("creators"), dict) else {}
        controllers = raw.get("controllers") if isinstance(raw.get("controllers"), dict) else {}
        for creator, info in creators.items():
            ctrl = str((info or {}).get("controller") or "")
            if not ctrl:
                continue
            cid = self.cluster_id(ctrl)
            row = out.setdefault(creator, {})
            if isinstance(row, dict):
                row.update({"controller": ctrl, "cluster_id": cid, "last_active_ts": inum((info or {}).get("updated_ts"), now_ts())})
            funded = (((controllers.get(ctrl) or {}).get("funded_wallets") or {}) if isinstance(controllers.get(ctrl), dict) else {})
            ctrl_row = out.setdefault(ctrl, {})
            if isinstance(ctrl_row, dict):
                ctrl_row.update({"controller": ctrl, "cluster_id": cid, "funded_wallets": sorted(set(funded.keys()) | {creator})})
        return out

    def cluster_id(self, controller: str) -> str:
        return hashlib.sha256(controller.encode("utf-8")).hexdigest()[:12]

    def _warn(self, where: str, err: Any, extra: Dict[str, Any] | None = None) -> None:
        try:
            append_jsonl("funding_graph_builder_errors.jsonl", {"ts": now_ts(), "where": where, "error": str(err)[:700], **(extra or {})})
        except Exception:
            pass

    async def rpc(self, method: str, params: List[Any], wallet: str = "") -> Any:
        started = time.time()
        success = False
        try:
            if not self.rpc_url:
                raise RuntimeError("RPC_URL missing")
            await self.limiter.wait()
            payload = {"jsonrpc": "2.0", "id": int(time.time() * 1000) % 1_000_000, "method": method, "params": params}
            assert self.session is not None
            async with self.limiter.sem:
                async with self.session.post(self.rpc_url, json=payload, timeout=fnum(self.cfg.get("FUNDING_GRAPH_RPC_TIMEOUT_SEC"), 7.0)) as resp:
                    text = await resp.text()
                    if resp.status == 429:
                        append_jsonl("rpc_rate_limit_events.jsonl", {"ts": now_ts(), "method": method, "wallet": wallet, "status": 429})
                        await asyncio.sleep(30.0)
                        raise RuntimeError("RPC 429 rate limited")
                    if resp.status >= 300:
                        raise RuntimeError(f"RPC HTTP {resp.status}: {text[:500]}")
                    obj = json.loads(text)
            if obj.get("error"):
                raise RuntimeError(f"RPC error: {obj.get('error')}")
            success = True
            return obj.get("result")
        except Exception:
            raise
        finally:
            try:
                append_jsonl("rpc_call_log.jsonl", {"ts": now_ts(), "method": method, "wallet": wallet, "response_time_ms": round((time.time() - started) * 1000, 2), "success": success})
            except Exception:
                pass

    async def get_signatures(self, wallet: str, limit: int) -> List[Dict[str, Any]]:
        res = await self.rpc("getSignaturesForAddress", [wallet, {"limit": limit, "commitment": str(self.cfg.get("COMMITMENT", "processed"))}], wallet)
        return res if isinstance(res, list) else []

    async def get_transaction(self, sig: str, wallet: str = "") -> Dict[str, Any]:
        res = await self.rpc("getTransaction", [sig, {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 0, "commitment": str(self.cfg.get("COMMITMENT", "processed"))}], wallet)
        return res if isinstance(res, dict) else {}

    def parse_sol_transfers(self, tx: Dict[str, Any]) -> List[Dict[str, Any]]:
        transfers: List[Dict[str, Any]] = []
        try:
            msg = (((tx.get("transaction") or {}).get("message") or {}))
            instrs = list(msg.get("instructions") or [])
            meta = tx.get("meta") or {}
            for inner in meta.get("innerInstructions") or []:
                instrs.extend(inner.get("instructions") or [])
            for ins in instrs:
                parsed = (ins or {}).get("parsed") or {}
                if str(parsed.get("type") or "").lower() != "transfer":
                    continue
                info = parsed.get("info") or {}
                src = str(info.get("source") or "")
                dst = str(info.get("destination") or "")
                lamports = fnum(info.get("lamports"), 0.0)
                if not lamports and info.get("amount") is not None:
                    lamports = fnum(info.get("amount"), 0.0)
                if src and dst and lamports > 0:
                    transfers.append({"source": src, "destination": dst, "lamports": lamports, "sol": lamports / LAMPORTS_PER_SOL})
        except Exception as e:
            self._warn("parse_sol_transfers", e)
        return transfers

    async def trace_wallet(self, wallet: str) -> None:
        try:
            now = now_ts()
            if self.wallets_processed_this_hour >= inum(self.cfg.get("FUNDING_GRAPH_MAX_WALLETS_PER_HOUR"), 200):
                return
            self.wallets_processed_this_hour += 1
            sigs = await self.get_signatures(wallet, 50)
            min_in = fnum(self.cfg.get("FUNDING_GRAPH_MIN_INBOUND_SOL"), 0.05)
            min_out = fnum(self.cfg.get("FUNDING_GRAPH_MIN_OUTBOUND_SOL"), 0.02)
            best_in: Tuple[str, float] = ("", 0.0)
            funded: Dict[str, Dict[str, Any]] = {}
            for srow in sigs:
                sig = str((srow or {}).get("signature") or "")
                if not sig:
                    continue
                try:
                    tx = await self.get_transaction(sig, wallet)
                    for tr in self.parse_sol_transfers(tx):
                        src, dst, sol = str(tr.get("source") or ""), str(tr.get("destination") or ""), fnum(tr.get("sol"), 0.0)
                        if dst == wallet and src != wallet and sol > best_in[1] and sol >= min_in:
                            best_in = (src, sol)
                        if src == wallet and dst != wallet and sol >= min_out:
                            funded[dst] = {"wallet": dst, "funding_sol": sol, "funding_sig": sig, "ts": inum((srow or {}).get("blockTime"), now)}
                except Exception as e:
                    self._warn("trace_wallet_tx", e, {"wallet": wallet, "sig": sig})
            controller = best_in[0] or wallet
            cid = self.cluster_id(controller)
            siblings = sorted(set(funded.keys()))
            async with self.graph_lock:
                row = self.graph.setdefault(wallet, {})
                if not isinstance(row, dict):
                    row = {}; self.graph[wallet] = row
                row.update({
                    "controller": controller,
                    "siblings": sorted(set(row.get("siblings") or []) | set(siblings)),
                    "funded_wallets": sorted(set(row.get("funded_wallets") or []) | set(siblings)),
                    "first_seen_ts": inum(row.get("first_seen_ts"), now),
                    "last_active_ts": now,
                    "last_checked_ts": now,
                    "total_tokens_created": inum(row.get("total_tokens_created"), 0),
                    "cluster_id": cid,
                })
                for dst, finfo in funded.items():
                    drow = self.graph.setdefault(dst, {})
                    if isinstance(drow, dict):
                        drow.update({"controller": controller, "cluster_id": cid, "first_seen_ts": inum(drow.get("first_seen_ts"), now), "last_active_ts": now})
                # legacy compatibility for existing creator_tracker
                controllers = self.graph.setdefault("controllers", {})
                if isinstance(controllers, dict):
                    crow = controllers.setdefault(controller, {"controller": controller, "funded_wallets": {}})
                    ff = crow.setdefault("funded_wallets", {})
                    for dst, finfo in funded.items():
                        ff[dst] = {"ts": finfo.get("ts", now), "funding_sig": finfo.get("funding_sig", ""), "funding_sol": finfo.get("funding_sol", 0)}
                    ff[wallet] = {"ts": now, "funding_sol": best_in[1]}
                    crow["updated_ts"] = now
            await self.update_cluster(cid, controller)
            await self.add_controller(controller, siblings)
            self.wallet_last_checked[wallet] = now
        except Exception as e:
            self._warn("trace_wallet", e, {"wallet": wallet, "trace": traceback.format_exc()[-2000:]})

    async def update_cluster(self, cid: str, controller: str) -> None:
        async with self.cluster_lock:
            members = sorted([w for w, r in self.graph.items() if isinstance(r, dict) and r.get("cluster_id") == cid])
            tokens_created: List[str] = []
            hist = load_json(self.data_dir / str(self.cfg.get("CREATOR_HISTORY_FILE", "creator_history.json")), {}) or {}
            creators = hist.get("creators") if isinstance(hist.get("creators"), dict) else {}
            pumps: List[float] = []
            wins = 0
            total = 0
            dumps_fast = 0
            for w in members:
                toks = ((creators.get(w) or {}).get("tokens") or []) if isinstance(creators.get(w), dict) else []
                for t in toks:
                    if not isinstance(t, dict):
                        continue
                    tokens_created.append(str(t.get("mint") or ""))
                    pump = fnum(t.get("max_pump_pct"), 0.0)
                    pumps.append(pump)
                    total += 1
                    if pump > 0.15:
                        wins += 1
                    if 0 < inum(t.get("time_to_dump_sec"), 999999) < 30:
                        dumps_fast += 1
            avg_pump = sum(pumps) / max(1, len(pumps))
            win_rate = wins / max(1, total)
            danger_score = min(100.0, dumps_fast * 20.0 + max(0.0, 0.5 - win_rate) * 100.0)
            self.cluster_map[cid] = {"members": members, "controller": controller, "tokens_created": [x for x in tokens_created if x], "avg_pump_pct": avg_pump, "win_rate": win_rate, "last_active_ts": now_ts(), "danger_score": danger_score}

    async def add_controller(self, controller: str, funded_wallets: List[str]) -> None:
        if not controller:
            return
        async with self.watch_lock:
            row = self.watch_list.setdefault(controller, {"last_checked_ts": 0, "known_funded_wallets": [], "pending_new_wallet": None, "alert_on_new_transfer": True})
            known = set(row.get("known_funded_wallets") or []) | set(funded_wallets)
            row["known_funded_wallets"] = sorted(known)
            row["alert_on_new_transfer"] = True

    async def watch_controller(self, controller: str, row: Dict[str, Any]) -> None:
        try:
            sigs = await self.get_signatures(controller, 5)
            now = now_ts()
            known = set(row.get("known_funded_wallets") or [])
            seen = self.seen_controller_sigs.setdefault(controller, set())
            for srow in sigs:
                sig = str((srow or {}).get("signature") or "")
                block_time = inum((srow or {}).get("blockTime"), now)
                if not sig or sig in seen or now - block_time > 30:
                    continue
                seen.add(sig)
                tx = await self.get_transaction(sig, controller)
                for tr in self.parse_sol_transfers(tx):
                    if str(tr.get("source") or "") != controller:
                        continue
                    dst = str(tr.get("destination") or "")
                    sol = fnum(tr.get("sol"), 0.0)
                    if not dst or dst in known or sol < fnum(self.cfg.get("FUNDING_GRAPH_MIN_OUTBOUND_SOL"), 0.02):
                        continue
                    cid = self.cluster_id(controller)
                    append_jsonl("controller_alerts.jsonl", {"ts": now, "controller_wallet": controller, "new_wallet_funded": dst, "amount_sol": sol, "alert_type": "new_wallet_funded"})
                    known.add(dst)
                    row["known_funded_wallets"] = sorted(known)
                    row["pending_new_wallet"] = dst
                    row["last_checked_ts"] = now
                    async with self.graph_lock:
                        drow = self.graph.setdefault(dst, {})
                        if isinstance(drow, dict):
                            drow.update({"controller": controller, "siblings": sorted(known), "funded_wallets": [], "first_seen_ts": now, "last_active_ts": now, "total_tokens_created": inum(drow.get("total_tokens_created"), 0), "cluster_id": cid})
                    async with self.pending_lock:
                        self.pending_watch[dst] = {"new_wallet": dst, "controller": controller, "cluster_id": cid, "funded_ts": now, "watch_until_ts": now + inum(self.cfg.get("PENDING_TOKEN_WATCH_WINDOW_SEC"), 300)}
            row["last_checked_ts"] = now
        except Exception as e:
            self._warn("watch_controller", e, {"controller": controller})

    async def confirm_predicted_tokens(self) -> None:
        try:
            if not self.creator_map_path.exists():
                return
            lines = self.creator_map_path.read_text(encoding="utf-8", errors="ignore").splitlines()[-1000:]
            now = now_ts()
            pending = dict(self.pending_watch)
            for line in lines:
                try:
                    ev = json.loads(line)
                except Exception:
                    continue
                creator = str(ev.get("creator_wallet") or ev.get("creator") or "")
                if creator not in pending:
                    continue
                entry = pending[creator]
                mint = str(ev.get("mint") or "")
                funded_ts = inum(entry.get("funded_ts"), now)
                append_jsonl("controller_alerts.jsonl", {"ts": now, "alert_type": "predicted_token_confirmed", "mint": mint, "cluster_id": entry.get("cluster_id"), "controller_wallet": entry.get("controller"), "new_wallet_funded": creator, "seconds_between_fund_and_create": max(0, now - funded_ts)})
        except Exception as e:
            self._warn("confirm_predicted_tokens", e)

    def seed_queue(self) -> List[str]:
        wallets: Set[str] = {w for w, r in self.graph.items() if isinstance(r, dict) and not w in ("creators", "controllers", "mints")}
        try:
            swarm = load_json(self.data_dir / str(self.cfg.get("SWARM_EDGE_PROFILE_FILE", "swarm_edge_profiles.json")), {}) or {}
            for r in swarm.get("copy_buy_wallets", []) or []:
                w = str((r or {}).get("wallet") or "")
                if w:
                    wallets.add(w)
        except Exception:
            pass
        try:
            q = load_json(self.data_dir / "queen_hive_report.json", {}) or {}
            for r in q.get("worker_accumulators", []) or q.get("top_worker_accumulators", []) or []:
                w = str((r or {}).get("wallet") or r or "")
                if w:
                    wallets.add(w)
        except Exception:
            pass
        return list(wallets)

    async def save_all(self) -> None:
        try:
            async with self.graph_lock:
                save_json(self.graph_path, self.graph)
            async with self.cluster_lock:
                save_json(self.cluster_path, self.cluster_map)
            async with self.watch_lock:
                save_json(self.watch_path, self.watch_list)
            async with self.pending_lock:
                save_json(self.pending_path, self.pending_watch)
        except Exception as e:
            self._warn("save_all", e)

    async def wallet_trace_loop(self) -> None:
        while True:
            try:
                bucket = int(time.time() // 3600)
                if bucket != self.hour_bucket:
                    self.hour_bucket = bucket
                    self.wallets_processed_this_hour = 0
                queue = self.seed_queue()
                if not queue:
                    await asyncio.sleep(30)
                    continue
                delay = max(0.5, 90.0 / max(1, len(queue)))
                cutoff = now_ts() - inum(self.cfg.get("FUNDING_GRAPH_WALLET_RECHECK_HOURS"), 6) * 3600
                for wallet in queue:
                    checked = inum(((self.graph.get(wallet) or {}) if isinstance(self.graph.get(wallet), dict) else {}).get("last_checked_ts"), 0)
                    if checked and checked > cutoff:
                        continue
                    await self.trace_wallet(wallet)
                    await asyncio.sleep(delay)
            except Exception as e:
                self._warn("wallet_trace_loop", e, {"trace": traceback.format_exc()[-2000:]})
                await asyncio.sleep(10)

    async def controller_watch_loop(self) -> None:
        while True:
            try:
                for controller, row in list(self.watch_list.items()):
                    if not isinstance(row, dict):
                        continue
                    await self.watch_controller(controller, row)
                await self.confirm_predicted_tokens()
            except Exception as e:
                self._warn("controller_watch_loop", e)
            await asyncio.sleep(max(1.0, fnum(self.cfg.get("CONTROLLER_WATCH_INTERVAL_SEC"), 15.0)))

    async def save_loop(self) -> None:
        while True:
            await asyncio.sleep(60)
            await self.save_all()

    async def run(self) -> None:
        print(f"HIVE_GRAPH_BUILDER_START wallets={len(self.seed_queue())} clusters={len(self.cluster_map)} controllers={len(self.watch_list)} rpc={'set' if self.rpc_url else 'missing'}")
        timeout = aiohttp.ClientTimeout(total=fnum(self.cfg.get("FUNDING_GRAPH_RPC_TIMEOUT_SEC"), 7.0))
        async with aiohttp.ClientSession(timeout=timeout) as session:
            self.session = session
            await asyncio.gather(self.wallet_trace_loop(), self.controller_watch_loop(), self.save_loop())


def load_config(path: str) -> Dict[str, Any]:
    cfg = load_json(path, {}) or {}
    cfg["_CONFIG_PATH"] = path
    return cfg


async def amain() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args()
    cfg = load_config(args.config)
    if not cfg.get("FUNDING_GRAPH_BUILDER_ENABLED", True):
        print("HIVE_GRAPH_BUILDER_DISABLED")
        return
    builder = FundingGraphBuilder(cfg)
    await builder.run()


if __name__ == "__main__":
    try:
        asyncio.run(amain())
    except KeyboardInterrupt:
        print("HIVE_GRAPH_BUILDER_STOPPED")
    except Exception as e:
        append_jsonl("funding_graph_builder_errors.jsonl", {"ts": now_ts(), "where": "__main__", "error": str(e), "trace": traceback.format_exc()[-4000:]})
        print(f"HIVE_GRAPH_BUILDER_FATAL {e}")
