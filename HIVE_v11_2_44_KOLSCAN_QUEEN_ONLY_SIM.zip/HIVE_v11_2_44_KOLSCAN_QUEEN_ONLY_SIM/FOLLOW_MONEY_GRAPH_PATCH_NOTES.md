# v11.2.40 Follow-Money Graph + Runtime Guard Patch

## Runtime error fixes
- Added websocket token-subscription throttles to stop `subscribeTokenTrade` spam from killing the feed with keepalive ping timeouts.
- Added caps:
  - `WSS_MAX_ACTIVE_TOKEN_SUBSCRIPTIONS=35`
  - `WSS_TOKEN_SUBSCRIBE_COOLDOWN_SEC=0.35`
  - `MAX_RESUB_MINTS=20`
- Marked websocket keepalive/watchdog reconnects as recoverable in `runtime_errors.jsonl`.
- Added larger WSS ping/queue controls.

## Bigger wallet web
New file: `follow_money_graph.py`

It builds:
- `FOLLOW_MONEY_GRAPH.json`
- `FOLLOW_MONEY_WATCHLIST.json`
- `FOLLOW_MONEY_WATCHLIST.txt`

It mines local logs for:
- early buyers
- repeat runner wallets
- exit-warning wallets
- creator/dev wallets when creator data exists
- dev/creator sell warnings
- hot creation mints with vetted early buyer confirmation

## Trading changes
- New setup lane: `follow_money_creation_snipe`
- It can enter near creation only when:
  - token age is young
  - a wallet from `FOLLOW_MONEY_WATCHLIST.json` buys fresh
  - buy flow is real
  - sell pressure is low
  - no exit/dev wallet is already selling
- Exits now watch `FOLLOW_MONEY_WATCHLIST.json` exit wallets. If a known exit/dev-warning wallet sells our mint, the bot can close immediately if green or if pressure is turning bad.

## Commands
Run after or during SIM:

```powershell
python follow_money_graph.py --config config.json
python build_vetted_wallet_watchlist.py
python win_rate_optimizer.py
python pnl_edge_miner.py
```

## Note
Your uploaded zip did not contain populated creator/dev maps yet, so the first graph is mostly early-buyer and exit-wallet intelligence. Once the WSS captures `new_token_events.jsonl` and `creator_wallet_map.jsonl` fills, the graph will start linking creators/controllers/dev sells.
