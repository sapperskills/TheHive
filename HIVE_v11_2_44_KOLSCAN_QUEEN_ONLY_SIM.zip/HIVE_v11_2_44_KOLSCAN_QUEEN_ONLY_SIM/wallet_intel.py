from __future__ import annotations
from dataclasses import dataclass, field
import csv
import json
from collections import Counter, defaultdict
from typing import Any, Dict, List, Tuple
from pathlib import Path
from util import load_json, save_json, fnum, inum, now_ts

ROLE_GOOD = {'accumulator', 'alpha'}
ROLE_BAD = {'dump_risk', 'sell_only'}
ROLE_EXIT = {'sell_near_high'}
ROLE_NOISE = {'flipper', 'watch'}

@dataclass
class WalletRoleSummary:
    alpha_count: int = 0
    accumulator_count: int = 0
    flipper_count: int = 0
    sell_near_high_count: int = 0
    sell_only_count: int = 0
    dump_risk_count: int = 0
    danger_count: int = 0
    associated_wallet_count: int = 0
    top_net_buy_sol: float = 0.0
    top_buy_sol: float = 0.0
    top_sell_sol: float = 0.0
    early_buy_count: int = 0
    sold_near_high_count: int = 0
    wallets: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return self.__dict__.copy()

class WalletIntel:
    """Loads wallet memory and turns top-holder behavior into alpha/danger features."""
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        data_dir = Path(config.get('DATA_DIR') or '.')
        self.wallet_rep_path = data_dir / config.get('WALLET_REPUTATION_FILE', 'wallet_reputation.json')
        self.top_traders_path = data_dir / config.get('TOP_TRADERS_FILE', 'top_traders_by_mint.json')
        self.wallet_clusters_path = data_dir / config.get('WALLET_CLUSTERS_FILE', 'wallet_clusters.json')
        self.reputation = load_json(self.wallet_rep_path, {'wallets': {}}) or {'wallets': {}}
        self.top_traders = load_json(self.top_traders_path, {'mints': {}}) or {'mints': {}}
        self.clusters = load_json(self.wallet_clusters_path, {'pairs': {}}) or {'pairs': {}}

    def role_for_wallet(self, wallet: str, row: Dict[str, Any] | None = None) -> str:
        rep = (self.reputation.get('wallets') or {}).get(wallet, {}) if wallet else {}
        role = rep.get('role') or (row or {}).get('role') or 'watch'
        return str(role or 'watch')

    def wallet_score(self, wallet: str) -> float:
        rep = (self.reputation.get('wallets') or {}).get(wallet, {})
        return fnum(rep.get('score'), 0.0)

    def mint_summary(self, mint: str) -> WalletRoleSummary:
        s = WalletRoleSummary()
        mrow = (self.top_traders.get('mints') or {}).get(mint, {}) if mint else {}
        if not isinstance(mrow, dict):
            return s
        rows: List[Dict[str, Any]] = []
        for k in ('top_buyers','top_holders_est','top_sellers'):
            vals = mrow.get(k) or []
            if isinstance(vals, list):
                rows.extend([v for v in vals if isinstance(v, dict)])
        # de-dupe wallet keeping highest abs flow row
        by_wallet: Dict[str, Dict[str, Any]] = {}
        for r in rows:
            w = r.get('wallet')
            if not w: continue
            old = by_wallet.get(w)
            flow = abs(fnum(r.get('net_buy_sol'), 0.0)) + fnum(r.get('buy_sol'),0.0) + fnum(r.get('sell_sol'),0.0)
            old_flow = -1 if not old else abs(fnum(old.get('net_buy_sol'),0.0)) + fnum(old.get('buy_sol'),0.0)+fnum(old.get('sell_sol'),0.0)
            if flow > old_flow:
                by_wallet[w] = r
        s.associated_wallet_count = len(by_wallet)
        for w,r in by_wallet.items():
            role = self.role_for_wallet(w, r)
            buy_sol = fnum(r.get('buy_sol'), 0.0)
            sell_sol = fnum(r.get('sell_sol'), 0.0)
            net = fnum(r.get('net_buy_sol'), buy_sol - sell_sol)
            early = bool(r.get('early_buy')) or inum(r.get('buy_count'),0) > 0
            sold_high = bool(r.get('sold_near_high')) or role == 'sell_near_high'
            score = self.wallet_score(w)
            s.top_buy_sol += max(0.0, buy_sol)
            s.top_sell_sol += max(0.0, sell_sol)
            s.top_net_buy_sol += net
            if early: s.early_buy_count += 1
            if sold_high: s.sold_near_high_count += 1
            if role == 'accumulator': s.accumulator_count += 1
            elif role == 'alpha': s.alpha_count += 1
            elif role == 'flipper': s.flipper_count += 1
            elif role == 'sell_near_high': s.sell_near_high_count += 1
            elif role == 'sell_only': s.sell_only_count += 1
            elif role == 'dump_risk': s.dump_risk_count += 1
            if role in ROLE_BAD or score >= 80:
                s.danger_count += 1
            s.wallets.append({'wallet': w, 'role': role, 'score': score, 'buy_sol': buy_sol, 'sell_sol': sell_sol, 'net_buy_sol': net, 'sold_near_high': sold_high})
        s.wallets.sort(key=lambda x: abs(fnum(x.get('net_buy_sol'),0.0))+fnum(x.get('buy_sol'),0.0), reverse=True)
        return s

    def is_significant_mint(self, mint: str, mc: float = 0.0, runup: float = 0.0) -> bool:
        row = (self.top_traders.get('mints') or {}).get(mint, {}) if mint else {}
        if isinstance(row, dict) and row.get('significant'):
            return True
        s = self.mint_summary(mint)
        return s.top_buy_sol >= fnum(self.config.get('MIN_ALPHA_BUY_SOL'),0.25) or s.accumulator_count >= 1 or s.alpha_count >= 1


    def summary_from_live_events(self, events: List[Dict[str, Any]]) -> WalletRoleSummary:
        """Build a WalletRoleSummary from fresh websocket events only.

        This is what makes v11.1 trade new buys/sells as they arrive instead of
        depending on static top_traders_by_mint rows.
        """
        s = WalletRoleSummary()
        by_wallet: Dict[str, Dict[str, Any]] = {}
        for ev in events or []:
            w = ev.get('wallet') or ev.get('traderPublicKey') or ev.get('user') or ''
            if not w:
                continue
            r = by_wallet.setdefault(w, {'wallet': w, 'buy_sol': 0.0, 'sell_sol': 0.0, 'buy_count': 0, 'sell_count': 0, 'net_buy_sol': 0.0, 'early_buy': False})
            sol = fnum(ev.get('sol') or ev.get('solAmount') or ev.get('amountSol'), 0.0)
            side = str(ev.get('side') or ev.get('txType') or '').lower()
            if side == 'buy':
                r['buy_sol'] += abs(sol)
                r['buy_count'] += 1
                r['net_buy_sol'] += abs(sol)
                r['early_buy'] = True
            elif side == 'sell':
                r['sell_sol'] += abs(sol)
                r['sell_count'] += 1
                r['net_buy_sol'] -= abs(sol)
        s.associated_wallet_count = len(by_wallet)
        for w, r in by_wallet.items():
            role = self.role_for_wallet(w, r)
            score = self.wallet_score(w)
            buy_sol = fnum(r.get('buy_sol'), 0.0)
            sell_sol = fnum(r.get('sell_sol'), 0.0)
            net = fnum(r.get('net_buy_sol'), 0.0)
            s.top_buy_sol += max(0.0, buy_sol)
            s.top_sell_sol += max(0.0, sell_sol)
            s.top_net_buy_sol += net
            if inum(r.get('buy_count'), 0) > 0:
                s.early_buy_count += 1
            if role == 'accumulator': s.accumulator_count += 1
            elif role == 'alpha': s.alpha_count += 1
            elif role == 'flipper': s.flipper_count += 1
            elif role == 'sell_near_high': s.sell_near_high_count += 1
            elif role == 'sell_only': s.sell_only_count += 1
            elif role == 'dump_risk': s.dump_risk_count += 1
            if role in ROLE_BAD or score >= 80:
                s.danger_count += 1
            s.wallets.append({'wallet': w, 'role': role, 'score': score, 'buy_sol': buy_sol, 'sell_sol': sell_sol, 'net_buy_sol': net, 'sold_near_high': role == 'sell_near_high'})
        s.wallets.sort(key=lambda x: abs(fnum(x.get('net_buy_sol'),0.0))+fnum(x.get('buy_sol'),0.0), reverse=True)
        return s


    def _iter_jsonl_file(self, path: str) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        p = Path(path)
        if not p.exists():
            return rows
        try:
            for line in p.read_text(encoding='utf-8', errors='ignore').splitlines():
                if not line.strip():
                    continue
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        rows.append(obj)
                except Exception:
                    continue
        except Exception:
            return rows
        return rows

    def _closed_live_trades(self) -> List[Tuple[Dict[str, Any], Dict[str, Any]]]:
        """Pair LIVE_BUY/LIVE_SELL rows by mint from wallet_predator_trades.csv."""
        path = Path(self.config.get('TRADES_FILE', 'wallet_predator_trades.csv'))
        if not path.exists():
            return []
        try:
            rows = list(csv.DictReader(path.open(encoding='utf-8', errors='ignore')))
        except Exception:
            return []
        open_by_mint: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        closed: List[Tuple[Dict[str, Any], Dict[str, Any]]] = []
        for r in rows:
            side = str(r.get('side') or '')
            mint = str(r.get('mint') or '')
            if not mint:
                continue
            if side.endswith('BUY'):
                open_by_mint[mint].append(r)
            elif side.endswith('SELL'):
                if open_by_mint.get(mint):
                    closed.append((open_by_mint[mint].pop(0), r))
        return closed

    def mine_live_reputation(self) -> Dict[str, Any]:
        """Infer queen/worker roles from this bot's own live history.

        The older build needed wallet_reputation/top_traders files before it could
        identify real queens. Fresh pump feeds usually have none, so every wallet
        stayed role='watch'. This mines a compact reputation ledger from:
          • wallets that bought before this bot's winning trades = worker evidence
          • wallets that sold into this bot's losing exits = queen/dump evidence
          • wallets that bait-buy before losses = trap evidence
        It is deliberately conservative: one event is not enough to be trusted as a
        queen or worker unless the SOL amount is very large.
        """
        live_events = self._iter_jsonl_file('live_wallet_events.jsonl')
        if not live_events:
            return self.reputation
        events_by_mint: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        for e in live_events:
            mint = str(e.get('mint') or '')
            if mint:
                events_by_mint[mint].append(e)
        for evs in events_by_mint.values():
            evs.sort(key=lambda x: fnum(x.get('ts'), 0.0))

        pre_window = fnum(self.config.get('HIVE_REPUTATION_PREBUY_WINDOW_SEC'), 20.0)
        exit_window = fnum(self.config.get('HIVE_REPUTATION_EXIT_WINDOW_SEC'), 4.0)
        win_pnl = fnum(self.config.get('HIVE_REPUTATION_WIN_PNL_PCT'), 0.04)
        loss_pnl = fnum(self.config.get('HIVE_REPUTATION_LOSS_PNL_PCT'), -0.035)
        wallets = self.reputation.setdefault('wallets', {})

        def wrow(w: str) -> Dict[str, Any]:
            r = wallets.setdefault(w, {})
            r.setdefault('role', 'watch')
            r.setdefault('score', 0.0)
            r.setdefault('seen_mints', 0)
            r.setdefault('early_buys', 0)
            r.setdefault('runner_hits', 0)
            r.setdefault('trap_hits', 0)
            r.setdefault('dumped', 0)
            r.setdefault('sold_near_high', 0)
            r.setdefault('buy_sol', 0.0)
            r.setdefault('sell_sol', 0.0)
            r.setdefault('queen_sell_sol', 0.0)
            r.setdefault('worker_buy_sol', 0.0)
            r.setdefault('loss_bait_buys', 0)
            return r

        closed = self._closed_live_trades()
        mints_seen_by_wallet: Dict[str, set] = defaultdict(set)
        for buy, sell in closed:
            mint = str(buy.get('mint') or '')
            if not mint:
                continue
            bt = fnum(buy.get('ts'), 0.0)
            st = fnum(sell.get('ts'), bt)
            pnl_pct = fnum(sell.get('net_pnl_pct'), fnum(sell.get('pnl_pct'), fnum(sell.get('gross_pnl_pct'), 0.0)))
            pnl_sol = fnum(sell.get('pnl_sol'), 0.0)
            sell_reason = str(sell.get('reason') or '')
            is_win = pnl_pct >= win_pnl or pnl_sol > 0.003
            is_loss = pnl_pct <= loss_pnl or pnl_sol < -0.003 or ('dump' in sell_reason or 'early_dump' in sell_reason)
            evs = events_by_mint.get(mint) or []
            pre_buys = [e for e in evs if bt - pre_window <= fnum(e.get('ts'), 0.0) <= bt + 0.75 and str(e.get('side')) == 'buy']
            exit_sells = [e for e in evs if bt <= fnum(e.get('ts'), 0.0) <= st + exit_window and str(e.get('side')) == 'sell']
            late_buys = [e for e in evs if bt <= fnum(e.get('ts'), 0.0) <= st + exit_window and str(e.get('side')) == 'buy']

            if is_win:
                for e in pre_buys:
                    w = str(e.get('wallet') or '')
                    if not w:
                        continue
                    sol = abs(fnum(e.get('sol'), 0.0))
                    r = wrow(w); mints_seen_by_wallet[w].add(mint)
                    r['early_buys'] = inum(r.get('early_buys'), 0) + 1
                    r['runner_hits'] = inum(r.get('runner_hits'), 0) + 1
                    r['buy_sol'] = fnum(r.get('buy_sol'), 0.0) + sol
                    r['worker_buy_sol'] = fnum(r.get('worker_buy_sol'), 0.0) + sol
                    r['score'] = fnum(r.get('score'), 0.0) + 2.5 + min(sol, 3.0) * 0.35 + max(0.0, pnl_pct) * 0.75
            if is_loss:
                # Sellers during/near our losing exit are queen/dump evidence.
                for e in exit_sells:
                    w = str(e.get('wallet') or '')
                    if not w:
                        continue
                    sol = abs(fnum(e.get('sol'), 0.0))
                    r = wrow(w); mints_seen_by_wallet[w].add(mint)
                    r['sold_near_high'] = inum(r.get('sold_near_high'), 0) + 1
                    r['dumped'] = inum(r.get('dumped'), 0) + (1 if sol >= fnum(self.config.get('HIVE_REPUTATION_DUMP_SELL_SOL'), 0.25) else 0)
                    r['sell_sol'] = fnum(r.get('sell_sol'), 0.0) + sol
                    r['queen_sell_sol'] = fnum(r.get('queen_sell_sol'), 0.0) + sol
                    r['score'] = fnum(r.get('score'), 0.0) + 3.5 + min(sol, 5.0) * 0.4
                # Bait buys before losses are not workers; mark as trap evidence.
                for e in pre_buys + late_buys:
                    w = str(e.get('wallet') or '')
                    if not w:
                        continue
                    sol = abs(fnum(e.get('sol'), 0.0))
                    r = wrow(w); mints_seen_by_wallet[w].add(mint)
                    r['trap_hits'] = inum(r.get('trap_hits'), 0) + 1
                    r['loss_bait_buys'] = inum(r.get('loss_bait_buys'), 0) + 1
                    r['buy_sol'] = fnum(r.get('buy_sol'), 0.0) + sol
                    r['score'] = fnum(r.get('score'), 0.0) + 0.5

        # Final role assignment. Queen evidence wins over worker evidence because
        # a dump wallet can also buy before it unloads.
        for w, r in wallets.items():
            seen = len(mints_seen_by_wallet.get(w, set())) or inum(r.get('seen_mints'), 0)
            r['seen_mints'] = max(inum(r.get('seen_mints'), 0), seen)
            runner_hits = inum(r.get('runner_hits'), 0)
            trap_hits = inum(r.get('trap_hits'), 0)
            dumped = inum(r.get('dumped'), 0)
            sold_high = inum(r.get('sold_near_high'), 0)
            queen_sell_sol = fnum(r.get('queen_sell_sol'), 0.0)
            worker_buy_sol = fnum(r.get('worker_buy_sol'), 0.0)
            queen_score = sold_high * 4.0 + trap_hits * 1.4 + dumped * 2.5 + min(queen_sell_sol, 12.0) * 0.35
            worker_score = runner_hits * 3.0 + min(worker_buy_sol, 12.0) * 0.45 - trap_hits * 1.5 - sold_high * 1.0
            r['queen_score'] = round(queen_score, 3)
            r['worker_score'] = round(worker_score, 3)
            if queen_score >= fnum(self.config.get('HIVE_REPUTATION_QUEEN_SCORE_MIN'), 9.0) and queen_score >= worker_score + 2.0:
                r['role'] = 'dump_risk' if dumped > 0 or queen_sell_sol >= 1.0 else 'sell_near_high'
            elif worker_score >= fnum(self.config.get('HIVE_REPUTATION_WORKER_SCORE_MIN'), 6.0) and worker_score > queen_score + 1.0:
                r['role'] = 'alpha' if runner_hits >= 2 or worker_buy_sol >= 2.0 else 'accumulator'
            elif trap_hits >= 2 and runner_hits == 0:
                r['role'] = 'flipper'
            else:
                r['role'] = r.get('role') or 'watch'
        self.reputation['ts'] = now_ts()
        self.reputation['source'] = 'mined_from_live_wallet_events_and_closed_trades'
        try:
            save_json(self.wallet_rep_path, self.reputation)
        except Exception:
            pass
        return self.reputation

    def export_profiles(self, path: str = 'wallet_predator_profiles.json') -> None:
        if self.config.get('HIVE_REPUTATION_AUTO_MINE_ENABLED', True):
            self.mine_live_reputation()
        wallets = self.reputation.get('wallets') or {}
        roles: Dict[str, int] = {}
        top=[]
        queen=[]
        workers=[]
        for w,r in wallets.items():
            role = r.get('role','watch')
            roles[role] = roles.get(role,0)+1
            row={'wallet':w,'role':role,'score':round(fnum(r.get('score'),0.0),3),'early_buys':inum(r.get('early_buys'),0),'runner_hits':inum(r.get('runner_hits'),0),'trap_hits':inum(r.get('trap_hits'),0),'dumped':inum(r.get('dumped'),0),'sold_near_high':inum(r.get('sold_near_high'),0),'seen_mints':inum(r.get('seen_mints'),0),'queen_score':round(fnum(r.get('queen_score'),0.0),3),'worker_score':round(fnum(r.get('worker_score'),0.0),3),'queen_sell_sol':round(fnum(r.get('queen_sell_sol'),0.0),4),'worker_buy_sol':round(fnum(r.get('worker_buy_sol'),0.0),4)}
            top.append(row)
            if role in ('sell_near_high','dump_risk','sell_only','flipper') or row['trap_hits'] > 0 or row['sold_near_high'] > 0:
                # Queen candidates are wallets that shape exits/dumps/traps. We do not follow them blindly.
                row['queen_score'] = row['score'] + row['trap_hits']*1.5 + row['sold_near_high']*0.8 + row['dumped']*2.0
                queen.append(row.copy())
            if role in ('accumulator','alpha') and row['trap_hits'] == 0:
                row['worker_score'] = row['score'] + row['runner_hits']*1.2 + row['early_buys']*0.3
                workers.append(row.copy())
        top.sort(key=lambda x: (x['score'], x['runner_hits']), reverse=True)
        queen.sort(key=lambda x: (x.get('queen_score',0), x.get('trap_hits',0), x.get('sold_near_high',0)), reverse=True)
        workers.sort(key=lambda x: (x.get('worker_score',0), x.get('runner_hits',0)), reverse=True)
        report = {
            'ts': now_ts(),
            'role_counts': roles,
            'top_wallets': top[:250],
            'queen_candidates': queen[:100],
            'worker_accumulators': workers[:100],
            'interpretation': 'Queen candidates are exit/dump/trap wallets; worker_accumulators are the wallets we want confirming fresh buys.'
        }
        save_json(path, {'ts': now_ts(), 'role_counts': roles, 'top_wallets': top[:250]})
        save_json(self.config.get('QUEEN_HIVE_REPORT_FILE','queen_hive_report.json'), report)


class CreatorIntelligence:
    """Repeat-token creator scorecard for dashboard and creator cluster logic."""
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        data_dir = Path(config.get('DATA_DIR') or '.')
        self.path = data_dir / config.get('CREATOR_HISTORY_FILE', 'creator_history.json')
        self.history = load_json(self.path, {'creators': {}, 'mints': {}}) or {'creators': {}, 'mints': {}}

    def _save(self) -> None:
        try:
            save_json(self.path, self.history)
        except Exception:
            pass

    def record_token(self, creator: str, mint: str, ts: int) -> None:
        if not creator or not mint:
            return
        creators = self.history.setdefault('creators', {})
        row = creators.setdefault(creator, {'creator': creator, 'tokens': [], 'updated_ts': ts})
        tokens = row.setdefault('tokens', [])
        if not any(isinstance(t, dict) and t.get('mint') == mint for t in tokens):
            tokens.append({'mint': mint, 'ts': ts, 'max_pump_pct': 0.0, 'time_to_dump_sec': None, 'creator_bought_at_creation': False, 'our_entry': None, 'our_exit': None})
        row['updated_ts'] = ts
        self.history.setdefault('mints', {})[mint] = {'creator': creator, 'ts': ts}
        self._save()

    def update_token_stats(self, creator: str, mint: str, **stats: Any) -> None:
        if not creator or not mint:
            return
        row = (self.history.setdefault('creators', {}).setdefault(creator, {'creator': creator, 'tokens': []}))
        tokens = row.setdefault('tokens', [])
        target = None
        for t in tokens:
            if isinstance(t, dict) and t.get('mint') == mint:
                target = t
                break
        if target is None:
            target = {'mint': mint, 'ts': inum(stats.get('ts'), now_ts())}
            tokens.append(target)
        for k, v in stats.items():
            target[k] = v
        row['updated_ts'] = now_ts()
        self._save()

    def get_creator_score(self, creator: str) -> float:
        row = (self.history.get('creators') or {}).get(creator, {}) if creator else {}
        tokens = [t for t in (row.get('tokens') or []) if isinstance(t, dict)]
        if not tokens:
            return 0.0
        score = 0.0
        prior_count = max(0, len(tokens) - 1)
        score += min(60.0, prior_count * 15.0)
        pumps = [max(0.0, fnum(t.get('max_pump_pct'), 0.0)) for t in tokens]
        if pumps:
            avg_pump = sum(pumps) / max(1, len(pumps))
            # +80 when the average historical max pump is +200% or higher.
            score += min(80.0, avg_pump * 40.0)
        creator_buys = [bool(t.get('creator_bought_at_creation') or t.get('creator_self_buy')) for t in tokens]
        if creator_buys:
            score += min(80.0, (sum(1 for x in creator_buys if x) / max(1, len(creator_buys))) * 80.0)
        dump_times = [fnum(t.get('time_to_dump_sec'), 0.0) for t in tokens if t.get('time_to_dump_sec') not in (None, '')]
        if dump_times and (sum(dump_times) / max(1, len(dump_times))) < 30.0:
            score -= 30.0
        return max(0.0, min(200.0, score))

    def get_top_creators(self, n: int = 20) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        for creator, row in (self.history.get('creators') or {}).items():
            if not isinstance(row, dict):
                continue
            tokens = [t for t in (row.get('tokens') or []) if isinstance(t, dict)]
            score = self.get_creator_score(creator)
            rows.append({
                'creator': creator,
                'score': round(score, 4),
                'token_count': len(tokens),
                'recent_tokens': tokens[-10:],
                'avg_max_pump_pct': round(sum(fnum(t.get('max_pump_pct'), 0.0) for t in tokens) / max(1, len(tokens)), 4),
                'creator_buy_rate': round(sum(1 for t in tokens if t.get('creator_bought_at_creation') or t.get('creator_self_buy')) / max(1, len(tokens)), 4),
                'updated_ts': inum(row.get('updated_ts'), 0),
            })
        rows.sort(key=lambda x: (fnum(x.get('score'), 0.0), inum(x.get('token_count'), 0), inum(x.get('updated_ts'), 0)), reverse=True)
        return rows[:max(1, int(n))]
