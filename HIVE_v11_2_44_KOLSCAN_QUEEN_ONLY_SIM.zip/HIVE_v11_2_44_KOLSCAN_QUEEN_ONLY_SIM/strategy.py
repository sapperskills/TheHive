from __future__ import annotations
from typing import Any, Dict, List
from util import fnum, inum, clamp, now_ts, append_jsonl, load_json
from wallet_intel import WalletIntel, WalletRoleSummary
from queen_worker_graph import QueenWorkerGraph
from creator_tracker import get_global_creator_tracker

GOOD_PATTERNS = {
    'organic_momentum_surge','smart_money_accumulation','second_wave_breakout',
    'absorption_breakout','stair_step_accumulation','tight_float_breakout','recovery_breakout'
}
BOT_NOISE_PATTERNS = {
    'cluster_cycle_drain','bot_dump_cycle','single_wallet_pump','high_cadence_machine',
    'wash_volume_churn','mixed_signal_caution','coordinated_burst','fixed_size_bot_ring'
}
HARD_RUG_PATTERNS = {'dead_after_launch','sniper_dump','fake_volume_mirror'}

class WalletPredatorStrategy:
    """Wallet-first copy trader.

    Rules of thumb:
    - Follow fresh buys from wallets we already profiled as accumulator/alpha.
    - Treat flippers as smaller size, not alpha.
    - Treat sell_near_high as exit pressure, not entry alpha.
    - Counter bot-driven noise by only buying rebound/absorption after tracked wallets step in.
    - ML is not used as a trading gate in this project.
    """
    # v11.2.36: top copy-buy edge wallets ranked by data quality (win_rate * samples).
    # Sourced directly from swarm_edge_profiles.json mined data.
    # Higher-sample wallets ranked first; 100%-win small-sample wallets at the end.
    PRIORITY_COPY_BUY_WALLETS = [
        # win=96% samples=25 avg_up=+29.5%
        'Hfpw7oJUNiJ7Tw1rMcRWTtTnHLUJGYU5BgMaaGJsTYsw',
        # win=88% samples=25 avg_up=+37.8%
        'AVuEnTUDDJU6k6X9Cqp7Ka2Q44nLusAJ7dVXqyz3XSWT',
        # win=82% samples=17 avg_up=+39.7%
        'B4tWmhfCBLvRYugPcu6bgP36DVweLc457pywc1a3QJju',
        # win=82% samples=17 avg_up=+39.4%
        'J69oeraNhBBD5Assk6RPAbdCCVvaVmtDYQjAtd3qvvFs',
        # win=85% samples=13 avg_up=+39.2%
        'DnaHCcS8Pfx4Z5vWRDCeA3YhHjMqAM4addtCHXzkCpsb',
        # win=83% samples=18 avg_up=+69.9%
        '8uLHNVyv33KftdcMUXyjqE2Kd1Fjyp1UMBrc7zo8Z6wM',
        # win=83% samples=12 avg_up=+69.0%
        'hahaA2GjzZbwgAwwryjmTb8VkmLt68hdZVHhtcpknpT',
        # win=78% samples=9 avg_up=+46.7%
        '99w9coDUG97dTjS2c3NWnRweqAyL59PEr6Fr1ZjzsPJK',
        # win=78% samples=9 avg_up=+47.2%
        'HL4ZnUDyo9rAacaGVtyL6cpX6zZAwJ96xsTWHuuUY7NE',
        # win=91% samples=11 avg_up=+79.6% avg_dd=-26.5%
        '8fStGV461vNqwhmQkvYvTFEYkxT4dKqNsyepgtFFDcud',
        # win=88% samples=8 avg_up=+83.1% avg_dd=-23.0%
        '9uC8dNwRTvwKtHQuGzH4xbzZ3vcQfFXdEVKYzqZmMs2C',
        # win=86% samples=7 avg_up=+30.1% avg_dd=-5.6%
        'DEKGYeFrLTa4p1xDYPYKiCfbNn3mJsjUe2wLfGjbWmsf',
        # win=100% samples=7 avg_up=+49.5% (small sample)
        '74PY4YLu2yHJGeHVNfZ1R64vRvEKHVtqpK2fxkTUzJix',
        # win=100% samples=7 avg_up=+45.8% (small sample)
        '3UeHj7Kq7cjMZ1WJsa6druxCckG39QYjUZgJeNREtpKR',
        # win=100% samples=6 avg_up=+63.8%
        'HZXdwRRw27kfpYtTqc7bMfrRgK3LSUaiKDFtqoEihik8',
        # win=100% samples=6 avg_up=+64.4%
        '9KztJF3LXZZuC3nRKamPirhPrhWMehcAuexzufoLpppm',
        # win=100% samples=6 avg_up=+62.4%
        '7T7YppwtAtxxsrrYeqf64h3qRCDwE3FYPYfzM3buvKBL',
        # win=100% samples=5 avg_up=+84.2% avg_dd=+2.7% (best risk/reward)
        '5QC5ydrKn3wigKB27g24PdNPAzkRZitLxdV7tA6c1Yk1',
    ]

    # v11.2.36: top worker accumulator wallets by score (from queen_hive_report.json).
    # When any of these appear in the live hive worker_wallets list, it is a strong
    # signal of a genuine accumulation move — prioritise entry.
    PRIORITY_WORKER_ACCUMULATORS = [
        '5R9BhDMMsKjLLrZYAEDfXAakx6DZ2DAWXFJaeoMB7h6u',   # score=8715 buy_sol=146.7
        'EgK5LW4BtzFQhKYxfeihZjVTB6fekoAzTWj8D254Fh1e',   # score=4848 buy_sol=98.2
        'E3TzrjrmnmZoNeTZzV6QdWbRPLpBKqu1r7Qrgg9YTWWS',   # score=3114 buy_sol=581.1
        '9jjhVcSBdL8HpKSiHqip7EELSFmN8YUapXrdUmWXTKsc',   # score=3110 buy_sol=569.6
        'DxBXAJRbo7RN8sTY7au7xQ4R4JR9NaPR9xopxUH9soV7',   # score=2588 buy_sol=9.8
        'EZzPZaFjNgiwYX4iUBTZWx2NZUkCf498GnqzGrHDoHC',    # score=2495 buy_sol=209.7
        'CFt926D6bJSFKFt34VJDTAqrPRMLQJVLA5vP1oeL3GTt',   # score=1827 buy_sol=224.6
        'EWHUrTN5znGD29cFCxSzM7Bg99cZvLBiPV9dNfisxwx',    # score=1628 buy_sol=493.7
        'EKLgYAjfQwJybQnf6zieHCiCaU1EzZA1YL9rjrCnxcUk',   # score=1343 buy_sol=232.9
        'CwoRXhrvoKtcuMAk133ZVygmuY3EDH86ZDixXsQzCQEA',   # score seen in copy profiles
    ]

    def __init__(self, config: Dict[str, Any], wallet_intel: WalletIntel, creator_tracker: Any = None):
        self.cfg = config
        self.wallet_intel = wallet_intel
        self.creator_tracker = creator_tracker or get_global_creator_tracker()
        self.cooldowns: Dict[str, float] = {}
        self.recent_mint_losses: Dict[str, float] = {}   # v11.2.36: track recent loss ts per mint
        self.hive_graph = QueenWorkerGraph(config) if config.get('QUEEN_WORKER_GRAPH_ENABLED', True) else None
        self.reload_swarm_edge_profiles()
        self.reload_follow_money_graph()
        self.reload_hive_ai_scores()

    def reload_swarm_edge_profiles(self) -> None:
        """Reload mined wallet weakness profiles without restarting live trading."""
        self.swarm_edge_profiles = load_json(self.cfg.get('SWARM_EDGE_PROFILE_FILE','swarm_edge_profiles.json'), {}) or {}
        self.swarm_copy_wallets = {x.get('wallet'): x for x in self.swarm_edge_profiles.get('copy_buy_wallets', []) if x.get('wallet')}
        self.swarm_exit_wallets = {x.get('wallet'): x for x in self.swarm_edge_profiles.get('exit_warning_wallets', []) if x.get('wallet')}
        self.swarm_cycle_wallets = {x.get('wallet'): x for x in self.swarm_edge_profiles.get('cycle_wallets', []) if x.get('wallet')}
        # v11.2.36: merge mined copy profiles with hard-coded priority list so both sources are active
        _priority_set = set(self.PRIORITY_COPY_BUY_WALLETS)
        for w in self.PRIORITY_COPY_BUY_WALLETS:
            if w not in self.swarm_copy_wallets:
                self.swarm_copy_wallets[w] = {'wallet': w, 'role': 'copy_buy_edge', 'win_rate': 0.85, 'samples': 0, 'priority_hardcoded': True}
        self._priority_copy_set = _priority_set
        self._priority_worker_set = set(self.PRIORITY_WORKER_ACCUMULATORS)
        self._rebuild_vetted_wallet_sets(write_report=True)


    def _wallet_rep_role(self, wallet: str) -> str:
        rep = ((getattr(self.wallet_intel, 'reputation', {}) or {}).get('wallets') or {}).get(wallet, {}) if wallet else {}
        return str(rep.get('role') or 'watch')

    def _rebuild_vetted_wallet_sets(self, write_report: bool = False) -> None:
        bad_roles = {'dump_risk', 'sell_near_high', 'sell_only', 'flipper'}
        good_roles = {'alpha', 'accumulator', 'watch'}
        min_wr = fnum(self.cfg.get('VETTED_COPY_MIN_WIN_RATE'), 0.78)
        min_samples = inum(self.cfg.get('VETTED_COPY_MIN_SAMPLES'), 5)
        min_edge = fnum(self.cfg.get('VETTED_COPY_MIN_EDGE_PCT'), 0.015)
        max_dd = fnum(self.cfg.get('VETTED_COPY_MAX_AVG_DD_PCT'), -0.35)
        max_age = fnum(self.cfg.get('VETTED_COPY_MAX_PROFILE_AGE_SEC'), 86400.0)
        now = now_ts()
        entry, exit_only, rejected = {}, {}, []
        for wallet, prof in (self.swarm_copy_wallets or {}).items():
            role = self._wallet_rep_role(wallet)
            samples = inum(prof.get('samples') or prof.get('buy_count'), 0)
            wr = fnum(prof.get('win_rate'), 0.0)
            edge = fnum(prof.get('fee_adjusted_edge_pct'), fnum(prof.get('edge_pct'), 0.0))
            avg_dd = fnum(prof.get('avg_max_dd_pct'), 0.0)
            last_seen_age = fnum(prof.get('last_seen_age_sec'), max(0.0, now - fnum(prof.get('last_seen_ts'), now)))
            reasons = []
            if role in bad_roles: reasons.append('reputation_role_' + role)
            if role not in good_roles: reasons.append('role_not_entry_' + role)
            if wr < min_wr: reasons.append(f'win_rate_{wr:.2f}_lt_{min_wr:.2f}')
            if samples < min_samples: reasons.append(f'samples_{samples}_lt_{min_samples}')
            if edge < min_edge: reasons.append(f'edge_{edge:.3f}_lt_{min_edge:.3f}')
            if avg_dd < max_dd: reasons.append(f'avg_dd_{avg_dd:.3f}_lt_{max_dd:.3f}')
            if last_seen_age > max_age: reasons.append(f'profile_stale_{int(last_seen_age)}s')
            row = {'wallet': wallet, 'role': role, 'samples': samples, 'win_rate': wr, 'fee_adjusted_edge_pct': edge, 'avg_max_dd_pct': avg_dd, 'last_seen_age_sec': last_seen_age, 'source': 'swarm_copy_wallets'}
            if reasons:
                row['reject_reason'] = reasons; rejected.append(row)
                if role in bad_roles: exit_only[wallet] = {**row, 'exit_reason': 'bad_reputation_role'}
            else:
                entry[wallet] = row
        for wallet in getattr(self, 'PRIORITY_COPY_BUY_WALLETS', []):
            role = self._wallet_rep_role(wallet)
            if wallet in entry:
                entry[wallet]['priority_hardcoded'] = True; continue
            if role in bad_roles:
                exit_only[wallet] = {'wallet': wallet, 'role': role, 'source': 'priority_hardcoded', 'exit_reason': 'bad_reputation_role'}
            elif self.cfg.get('ALLOW_HARDCODED_PRIORITY_IF_NOT_DANGER', True):
                entry[wallet] = {'wallet': wallet, 'role': role, 'samples': 0, 'win_rate': 0.85, 'fee_adjusted_edge_pct': min_edge, 'source': 'priority_hardcoded'}
        for wallet, prof in (self.swarm_exit_wallets or {}).items():
            role = self._wallet_rep_role(wallet)
            drop_rate = fnum(prof.get('drop_rate_after_sell'), 0.0)
            samples = inum(prof.get('samples'), 0)
            if drop_rate >= fnum(self.cfg.get('VETTED_EXIT_MIN_DROP_RATE'), 0.60) or role in bad_roles:
                exit_only[wallet] = {'wallet': wallet, 'role': role, 'samples': samples, 'drop_rate_after_sell': drop_rate, 'source': 'swarm_exit_wallets', 'exit_reason': 'sell_warning_profile'}
        for wallet in list(exit_only.keys()):
            if wallet in entry and self._wallet_rep_role(wallet) in bad_roles:
                entry.pop(wallet, None)
        self.vetted_copy_wallets = entry
        self.vetted_copy_set = set(entry)
        self.vetted_exit_wallets = exit_only
        self.vetted_exit_set = set(exit_only)
        if write_report:
            report = {'ts': now, 'mode': 'v11.2.39_vetted_wallet_copy_lane', 'entry_wallet_count': len(entry), 'exit_wallet_count': len(exit_only), 'rejected_count': len(rejected), 'entry_wallets': sorted(entry.values(), key=lambda r: (fnum(r.get('win_rate'), 0), inum(r.get('samples'), 0), fnum(r.get('fee_adjusted_edge_pct'), 0)), reverse=True), 'exit_only_wallets': sorted(exit_only.values(), key=lambda r: (inum(r.get('samples'), 0), fnum(r.get('drop_rate_after_sell'), 0)), reverse=True)[:250], 'rejected_entry_wallets': rejected[:250], 'notes': ['Entry wallets must pass win-rate/samples/edge/drawdown and not have dump/sell-near-high roles.', 'Danger wallets are not copied; their sells are exit-warning signals.']}
            try:
                save_json(self.cfg.get('VETTED_WALLET_REPORT_FILE', 'VETTED_WALLET_REPORT.json'), report)
                with open(self.cfg.get('VETTED_WALLET_TEXT_FILE', 'VETTED_WALLETS.txt'), 'w', encoding='utf-8') as fh:
                    fh.write('ENTRY-APPROVED COPY WALLETS\n')
                    for r in report['entry_wallets']:
                        fh.write(f"{r.get('wallet')} role={r.get('role')} wr={fnum(r.get('win_rate'),0):.2f} samples={inum(r.get('samples'),0)} edge={fnum(r.get('fee_adjusted_edge_pct'),0):.3f} source={r.get('source')}\n")
                    fh.write('\nEXIT-ONLY / DANGER WALLETS\n')
                    for r in report['exit_only_wallets']:
                        fh.write(f"{r.get('wallet')} role={r.get('role')} samples={inum(r.get('samples'),0)} reason={r.get('exit_reason')} source={r.get('source')}\n")
            except Exception:
                pass


    def reload_follow_money_graph(self) -> None:
        """Hot-load local follow-the-money graph built from trade logs."""
        self.follow_money_graph = load_json(self.cfg.get('FOLLOW_MONEY_GRAPH_FILE', 'FOLLOW_MONEY_GRAPH.json'), {}) or {}
        watch = load_json(self.cfg.get('FOLLOW_MONEY_WATCHLIST_FILE', 'FOLLOW_MONEY_WATCHLIST.json'), {}) or {}
        self.follow_money_entry_set = set(str(x) for x in (watch.get('entry_wallets') or []) if x)
        self.follow_money_exit_set = set(str(x) for x in (watch.get('exit_wallets') or []) if x)
        self.follow_money_creator_set = set(str(x) for x in (watch.get('creator_wallets') or []) if x)
        # Merge into existing vetted sets as confirmation wallets, not blind authority.
        if not hasattr(self, 'vetted_exit_set'):
            self.vetted_exit_set = set()
        self.vetted_exit_set |= self.follow_money_exit_set

    def _follow_money_creation_signal(self, f: Dict[str, Any], hive: Dict[str, Any], score: float) -> tuple[bool, str, Dict[str, Any]]:
        """Entry confirmation for fresh creations where the local wallet web sees money moving.

        This buys near creation only when a wallet from FOLLOW_MONEY_WATCHLIST appears
        as a fresh buyer and no dev/exit wallet has sold the mint in the recent tape.
        """
        details: Dict[str, Any] = {}
        if not self.cfg.get('FOLLOW_MONEY_CREATION_ENTRY_ENABLED', True):
            return False, 'follow_money_creation_disabled', details
        if f.get('last_side') != 'buy' or not f.get('last_event_fresh'):
            return False, 'follow_money_not_fresh_buy', details
        age = fnum(f.get('age'), 999999.0)
        if age > fnum(self.cfg.get('FOLLOW_MONEY_CREATION_MAX_AGE_SEC'), 90.0):
            return False, 'follow_money_creation_too_old', {'age': age}
        wallet = f.get('last_event_wallet') or ''
        live_wallets = set(f.get('live_event_wallets') or [])
        entry_hits = [w for w in live_wallets if w in getattr(self, 'follow_money_entry_set', set())]
        if wallet in getattr(self, 'follow_money_entry_set', set()) and wallet not in entry_hits:
            entry_hits.insert(0, wallet)
        if not entry_hits:
            return False, 'follow_money_no_entry_wallet_hit', {'wallet': wallet}
        events = f.get('live_wallet_events') or []
        exit_sells = []
        exit_set = getattr(self, 'follow_money_exit_set', set()) | getattr(self, 'vetted_exit_set', set())
        for e in events:
            ew = str(e.get('wallet') or e.get('traderPublicKey') or '')
            side = str(e.get('side') or e.get('txType') or '').lower()
            if side == 'sell' and ew in exit_set:
                exit_sells.append(ew)
        if exit_sells:
            return False, 'follow_money_exit_wallet_already_selling', {'entry_hits': entry_hits, 'exit_sells': sorted(set(exit_sells))}
        if fnum(f.get('last_event_sol'), 0.0) < fnum(self.cfg.get('FOLLOW_MONEY_CREATION_MIN_LAST_BUY_SOL'), 0.04):
            return False, 'follow_money_last_buy_too_small', {'entry_hits': entry_hits}
        if fnum(f.get('buy_sol_recent'), 0.0) < fnum(self.cfg.get('FOLLOW_MONEY_CREATION_MIN_BUY_SOL_RECENT'), 0.35):
            return False, 'follow_money_recent_buy_sol_too_small', {'entry_hits': entry_hits}
        if inum(f.get('recent_buyers'), 0) < inum(self.cfg.get('FOLLOW_MONEY_CREATION_MIN_BUYERS'), 2):
            return False, 'follow_money_not_enough_buyers', {'entry_hits': entry_hits}
        if fnum(f.get('sell_pressure'), 0.0) > fnum(self.cfg.get('FOLLOW_MONEY_CREATION_MAX_SELL_PRESSURE'), 0.22):
            return False, 'follow_money_sell_pressure_block', {'entry_hits': entry_hits}
        min_score = fnum(self.cfg.get('FOLLOW_MONEY_CREATION_MIN_SCORE'), 95.0)
        if score < min_score:
            return False, 'follow_money_score_too_low', {'score': score, 'entry_hits': entry_hits}
        details = {'entry_hits': entry_hits[:8], 'age': age, 'wallet': wallet, 'buy_sol_recent': f.get('buy_sol_recent'), 'recent_buyers': f.get('recent_buyers')}
        return True, 'follow_money_creation_wallet_web_confirmed', details

    def _early_creation_snipe_signal(self, f: Dict[str, Any], hive: Dict[str, Any], score: float) -> tuple[bool, str, Dict[str, Any]]:
        """v11.2.42: WSS-only fresh creation sniper.

        This lane is intentionally separate from follow-money wallet copy. The newest
        deep-dive showed the best early-snipe replay was: first fresh buy impulse,
        low market cap, no/low sells, quick TP/SL. It is SIM-first and small-size.
        """
        details: Dict[str, Any] = {}
        if not self.cfg.get('EARLY_CREATION_SNIPE_ENABLED', True):
            return False, 'early_creation_snipe_disabled', details
        if f.get('last_side') != 'buy' or not f.get('last_event_fresh'):
            return False, 'early_creation_not_fresh_buy', details
        age = fnum(f.get('age'), 999999.0)
        if age > fnum(self.cfg.get('EARLY_CREATION_SNIPE_MAX_AGE_SEC'), 30.0):
            return False, 'early_creation_too_old', {'age': age}
        mc = fnum(f.get('mc'), 0.0)
        if mc <= 0 or mc > fnum(self.cfg.get('EARLY_CREATION_SNIPE_MAX_MC_SOL'), 40.0):
            return False, 'early_creation_mc_block', {'mc': mc}
        if fnum(f.get('last_event_sol'), 0.0) < fnum(self.cfg.get('EARLY_CREATION_SNIPE_MIN_LAST_BUY_SOL'), 0.60):
            return False, 'early_creation_last_buy_too_small', {'last_event_sol': f.get('last_event_sol')}
        if fnum(f.get('buy_sol_recent'), 0.0) < fnum(self.cfg.get('EARLY_CREATION_SNIPE_MIN_BUY_SOL_RECENT'), 0.60):
            return False, 'early_creation_buy_sol_too_small', {'buy_sol_recent': f.get('buy_sol_recent')}
        if inum(f.get('recent_buyers'), 0) < inum(self.cfg.get('EARLY_CREATION_SNIPE_MIN_BUYERS'), 1):
            return False, 'early_creation_not_enough_buyers', {'recent_buyers': f.get('recent_buyers')}
        if inum(f.get('recent_sells'), 0) > inum(self.cfg.get('EARLY_CREATION_SNIPE_MAX_RECENT_SELLS'), 0):
            return False, 'early_creation_recent_sells_block', {'recent_sells': f.get('recent_sells')}
        if fnum(f.get('sell_pressure'), 0.0) > fnum(self.cfg.get('EARLY_CREATION_SNIPE_MAX_SELL_PRESSURE'), 0.20):
            return False, 'early_creation_sell_pressure_block', {'sell_pressure': f.get('sell_pressure')}
        if fnum(f.get('total_sell_buy_ratio'), 99.0) > fnum(self.cfg.get('EARLY_CREATION_SNIPE_MAX_SELL_BUY_RATIO'), 0.40):
            return False, 'early_creation_sell_buy_ratio_block', {'total_sell_buy_ratio': f.get('total_sell_buy_ratio')}
        if fnum(f.get('rug_risk'), 0.0) > fnum(self.cfg.get('EARLY_CREATION_SNIPE_MAX_RUG_RISK'), 35.0):
            return False, 'early_creation_rug_risk_block', {'rug_risk': f.get('rug_risk')}
        min_score = fnum(self.cfg.get('EARLY_CREATION_SNIPE_MIN_SCORE'), 0.0)
        if min_score > 0 and score < min_score:
            return False, 'early_creation_score_too_low', {'score': score}
        details = {
            'age': age,
            'mc': mc,
            'last_event_sol': f.get('last_event_sol'),
            'buy_sol_recent': f.get('buy_sol_recent'),
            'recent_buyers': f.get('recent_buyers'),
            'recent_buys': f.get('recent_buys'),
            'wallet': f.get('last_event_wallet') or '',
        }
        return True, 'early_creation_first_impulse_snipe', details

    def _vetted_copy_entry_signal(self, f: Dict[str, Any], ws: WalletRoleSummary, hive: Dict[str, Any], score: float) -> tuple[bool, str, Dict[str, Any]]:
        details: Dict[str, Any] = {}
        if not self.cfg.get('VETTED_COPY_WALLET_ENABLED', True): return False, 'vetted_copy_disabled', details
        if f.get('last_side') != 'buy' or not f.get('last_event_fresh'): return False, 'vetted_copy_not_fresh_buy', details
        wallet = f.get('last_event_wallet') or ''
        if wallet not in getattr(self, 'vetted_copy_set', set()): return False, 'wallet_not_vetted_entry', details
        prof = self.vetted_copy_wallets.get(wallet, {})
        role = prof.get('role') or self._wallet_rep_role(wallet)
        if role in ('dump_risk','sell_near_high','sell_only','flipper'): return False, 'vetted_copy_role_block_' + str(role), {'wallet': wallet, 'role': role}
        if fnum(f.get('last_event_sol'), 0.0) < fnum(self.cfg.get('VETTED_COPY_MIN_LAST_BUY_SOL'), 0.05): return False, 'vetted_copy_last_buy_too_small', {'wallet': wallet, 'role': role}
        if fnum(f.get('sell_pressure'), 0.0) > fnum(self.cfg.get('VETTED_COPY_MAX_SELL_PRESSURE'), 0.28): return False, 'vetted_copy_sell_pressure_block', {'wallet': wallet, 'role': role}
        if fnum(f.get('total_sell_buy_ratio'), 0.0) > fnum(self.cfg.get('VETTED_COPY_MAX_SELL_BUY_RATIO'), 0.45): return False, 'vetted_copy_sell_buy_ratio_block', {'wallet': wallet, 'role': role}
        if inum(f.get('recent_sells'), 0) > inum(self.cfg.get('VETTED_COPY_MAX_RECENT_SELLS'), 2): return False, 'vetted_copy_recent_sells_block', {'wallet': wallet, 'role': role}
        if fnum(f.get('age'), 0.0) > fnum(self.cfg.get('VETTED_COPY_MAX_TOKEN_AGE_SEC'), 720.0): return False, 'vetted_copy_token_age_block', {'wallet': wallet, 'role': role}
        ctx = self._recent_tape_context(f, fnum(self.cfg.get('VETTED_COPY_EXIT_LOOKBACK_SEC'), 5.0))
        if ctx.get('exit_warning_sells_5s', 0) > 0: return False, 'vetted_copy_exit_warning_selling', {'wallet': wallet, 'role': role, 'ctx': ctx}
        if score < fnum(self.cfg.get('VETTED_COPY_MIN_SCORE'), 120.0): return False, 'vetted_copy_score_too_low', {'wallet': wallet, 'role': role, 'score': score}
        return True, 'vetted_copy_wallet_buy_confirmed', {'wallet': wallet, 'role': role, 'profile': prof, 'ctx': ctx}


    def _priority_confirmation(self, f: Dict[str, Any], hive: Dict[str, Any] | None = None) -> Dict[str, Any]:
        """Return data-mined wallet confirmation for entry lanes.

        The latest SIM snapshot showed pressure_runner_lift was the noisy lane.
        Busy tape alone is not enough; require at least one known copy-buy wallet
        in the live event window, one priority worker accumulator in the hive worker
        list, or an explicit extreme-flow escape hatch.
        """
        live_wallets = set()
        for w in (f.get('live_event_wallets') or []):
            if isinstance(w, str) and w:
                live_wallets.add(w)
        for e in (f.get('live_wallet_events') or []):
            w = e.get('wallet') or e.get('traderPublicKey') or e.get('user') or ''
            if w:
                live_wallets.add(str(w))
        hive_workers = set((hive or {}).get('worker_wallets') or [])
        copy_hits = sorted([w for w in live_wallets if w in getattr(self, 'vetted_copy_set', set())])
        worker_hits = sorted([w for w in hive_workers if w in getattr(self, '_priority_worker_set', set())])
        min_copy = inum(self.cfg.get('PRESSURE_RUNNER_PRIORITY_CONFIRM_MIN_COPY_WALLETS'), 1)
        min_worker = inum(self.cfg.get('PRESSURE_RUNNER_PRIORITY_CONFIRM_MIN_WORKER_WALLETS'), 1)
        priority_ok = (len(copy_hits) >= min_copy) or (len(worker_hits) >= min_worker)
        extreme_ok = (
            fnum(f.get('buy_sol_recent'), 0.0) >= fnum(self.cfg.get('PRESSURE_RUNNER_EXTREME_FLOW_MIN_BUY_SOL_RECENT'), 25.0) and
            fnum((hive or {}).get('net_hive_sol'), 0.0) >= fnum(self.cfg.get('PRESSURE_RUNNER_EXTREME_FLOW_MIN_TOP_NET_BUY_SOL'), 12.0) and
            fnum(f.get('sell_pressure'), 1.0) <= fnum(self.cfg.get('PRESSURE_RUNNER_EXTREME_FLOW_MAX_SELL_PRESSURE'), 0.20) and
            fnum(f.get('total_sell_buy_ratio'), 99.0) <= fnum(self.cfg.get('PRESSURE_RUNNER_EXTREME_FLOW_MAX_SELL_BUY_RATIO'), 0.35)
        )
        mode = str(self.cfg.get('PRESSURE_RUNNER_CONFIRM_MODE', 'priority_or_extreme_flow'))
        ok = priority_ok if mode == 'priority_only' else (priority_ok or extreme_ok)
        return {
            'ok': bool(ok),
            'mode': mode,
            'priority_ok': bool(priority_ok),
            'extreme_flow_ok': bool(extreme_ok),
            'copy_wallet_hits': copy_hits[:10],
            'worker_wallet_hits': worker_hits[:10],
            'live_wallet_count': len(live_wallets),
            'hive_worker_count': len(hive_workers),
        }



    def reload_hive_ai_scores(self) -> None:
        """Reload local lightweight AI scores without restarting live trading."""
        self.hive_ai_scores = load_json(self.cfg.get('HIVE_AI_SCORES_FILE','hive_ai_scores.json'), {}) or {}
        self.hive_ai_wallets = self.hive_ai_scores.get('wallet_scores', {}) if isinstance(self.hive_ai_scores.get('wallet_scores', {}), dict) else {}
        self.hive_ai_setups = self.hive_ai_scores.get('setup_scores', {}) if isinstance(self.hive_ai_scores.get('setup_scores', {}), dict) else {}
        self.hive_ai_mints = self.hive_ai_scores.get('mint_scores', {}) if isinstance(self.hive_ai_scores.get('mint_scores', {}), dict) else {}

    def _hive_ai_lookup(self, f: Dict[str, Any], setup: str = 'none') -> Dict[str, Any]:
        if not self.cfg.get('HIVE_AI_ENABLED', True):
            return {'enabled': False, 'entry_score': 0.5, 'danger_score': 0.0, 'runner_score': 0.5, 'source': 'disabled'}
        wallet = f.get('last_event_wallet') or ''
        mint = f.get('mint') or ''
        candidates = []
        if wallet and wallet in getattr(self, 'hive_ai_wallets', {}):
            candidates.append(('wallet', self.hive_ai_wallets[wallet]))
        if setup and setup in getattr(self, 'hive_ai_setups', {}):
            candidates.append(('setup', self.hive_ai_setups[setup]))
        if mint and mint in getattr(self, 'hive_ai_mints', {}):
            candidates.append(('mint', self.hive_ai_mints[mint]))
        if not candidates:
            return {'enabled': True, 'entry_score': 0.5, 'danger_score': 0.0, 'runner_score': 0.5, 'source': 'no_profile'}
        # Entry/runner use max proven edge; danger uses max danger source.
        entry=max(fnum(d.get('entry_score'),0.5) for _,d in candidates)
        danger=max(fnum(d.get('danger_score'),0.0) for _,d in candidates)
        runner=max(fnum(d.get('runner_score'),0.5) for _,d in candidates)
        source=max(candidates, key=lambda kv: fnum(kv[1].get('entry_score'),0.5))[0]
        return {'enabled': True, 'entry_score': entry, 'danger_score': danger, 'runner_score': runner, 'source': source}


    def _cfg_csv_set(self, key: str, default: str) -> set:
        v = self.cfg.get(key, default)
        if isinstance(v, list):
            return {str(x).strip() for x in v if str(x).strip()}
        return {x.strip() for x in str(v).replace('|', ',').split(',') if x.strip()}

    def _local_ai_pattern_grade(self, f: Dict[str, Any], ws: WalletRoleSummary, hive: Dict[str, Any], setup: str, ai_pre: Dict[str, Any]) -> Dict[str, Any]:
        """Inline AI grade used at decision time.

        The sidecar mines historical setup/wallet/mint scorecards, but this live
        guard also checks the current tape so the AI blocks bad volume-bot / queen
        worker patterns even when no profile exists yet.
        """
        allow = self._cfg_csv_set('HIVE_AI_ALLOWED_SETUPS', 'pressure_runner_lift,swarm_edge_auto_ride,top_trader_volume_spike')
        bad = self._cfg_csv_set('HIVE_AI_BLOCKED_SETUPS', 'queen_worker_front_run,queen_cycle_ride,queen_dump_recovery_scout,wallet_predator_accumulation,worker_swarm_acceleration,ai_swarm_edge_override,copy_wallet_probe,watch_surge_counter')
        entry = fnum(ai_pre.get('entry_score'), 0.5)
        danger = fnum(ai_pre.get('danger_score'), 0.0)
        flags: List[str] = []
        if setup in allow:
            entry += 0.12; flags.append('allowed_setup')
        if setup in bad:
            entry -= 0.22; danger += 0.30; flags.append('blocked_setup_history')
        if f.get('last_side') != 'buy' or not f.get('last_event_fresh'):
            danger += 0.25; flags.append('not_fresh_buy')
        if inum(f.get('recent_buys'),0) >= inum(self.cfg.get('AI_PATTERN_MIN_RECENT_BUYS'), 12):
            entry += 0.06; flags.append('recent_buys_ok')
        if inum(f.get('recent_buyers'),0) >= inum(self.cfg.get('AI_PATTERN_MIN_RECENT_BUYERS'), 6):
            entry += 0.06; flags.append('recent_buyers_ok')
        if fnum(f.get('buy_sol_recent'),0.0) >= fnum(self.cfg.get('AI_PATTERN_MIN_BUY_SOL_RECENT'), 4.0):
            entry += 0.06; flags.append('buy_sol_recent_ok')
        if fnum(f.get('sell_pressure'),0.0) > fnum(self.cfg.get('AI_PATTERN_MAX_SELL_PRESSURE'), 0.45):
            danger += 0.22; flags.append('sell_pressure_high')
        if fnum(f.get('total_sell_buy_ratio'),0.0) > fnum(self.cfg.get('AI_PATTERN_MAX_SELL_BUY_RATIO'), 1.15):
            danger += 0.20; flags.append('sell_buy_ratio_high')
        if ws.dump_risk_count > inum(self.cfg.get('AI_PATTERN_MAX_DUMP_RISK_WALLETS'), 0):
            danger += 0.18; flags.append('dump_risk_wallet')
        if ws.sell_only_count > inum(self.cfg.get('AI_PATTERN_MAX_SELL_ONLY_WALLETS'), 0):
            danger += 0.16; flags.append('sell_only_wallet')
        if ws.sell_near_high_count > inum(self.cfg.get('AI_PATTERN_MAX_SELL_NEAR_HIGH_WALLETS'), 0):
            danger += 0.14; flags.append('sell_near_high_wallet')
        if hive.get('queen_exit_now') or hive.get('is_late_queen_entry'):
            danger += 0.20; flags.append('queen_exit_or_late')
        if fnum(hive.get('queen_sell_sol'),0.0) > max(0.20, fnum(hive.get('worker_buy_sol'),0.0) * 0.50):
            danger += 0.14; flags.append('queen_sell_pressure')
        entry = max(0.01, min(0.99, entry - danger * 0.25))
        danger = max(0.0, min(0.99, danger))
        if danger >= 0.70 or entry < 0.45:
            grade='F'
        elif danger >= 0.55 or entry < 0.58:
            grade='D'
        elif entry >= 0.80 and danger <= 0.32:
            grade='A'
        elif entry >= 0.68 and danger <= 0.45:
            grade='B'
        else:
            grade='C'
        return {'entry_score': round(entry,4), 'danger_score': round(danger,4), 'runner_score': fnum(ai_pre.get('runner_score'), 0.5), 'grade': grade, 'flags': flags, 'allowed_setups': sorted(allow), 'blocked_setups': sorted(bad)}

    def _base_features(self, row: Dict[str, Any]) -> Dict[str, Any]:
        return {
            'mint': row.get('mint',''),
            'ts': inum(row.get('ts'), now_ts()),
            'mc': fnum(row.get('mc') if row.get('mc') is not None else row.get('current_mc'), 0.0),
            'age': fnum(row.get('age') if row.get('age') is not None else row.get('age_sec'), 0.0),
            'setup': row.get('setup') or 'none',
            'pattern': row.get('bot_pattern') or row.get('pattern') or 'live_wallet_flow',
            'quality_score': fnum(row.get('quality_score'), 0.0),
            'breakout_score': fnum(row.get('breakout_score'), 0.0),
            'rug_risk': fnum(row.get('rug_risk'), 0.0),
            'recent_buys': inum(row.get('recent_buys'), 0),
            'recent_sells': inum(row.get('recent_sells'), 0),
            'recent_buyers': inum(row.get('recent_buyers'), 0),
            'recent_sellers': inum(row.get('recent_sellers'), 0),
            'total_buys': inum(row.get('total_buys'), 0),
            'total_sells': inum(row.get('total_sells'), 0),
            'sell_pressure': fnum(row.get('sell_pressure'), 0.0),
            'total_sell_buy_ratio': fnum(row.get('total_sell_buy_ratio'), 0.0),
            'buy_accel': fnum(row.get('buy_accel'), 0.0),
            'pullback_pct': fnum(row.get('pullback_pct'), 0.0),
            'above_open_pct': fnum(row.get('above_open_pct'), 0.0),
            'breakout_confirmed': bool(row.get('breakout_confirmed')),
            'live_wallet_events': row.get('live_wallet_events') or [],
            'live_event_wallets': row.get('live_event_wallets') or [],
            'last_side': row.get('last_side') or '',
            'last_event_age_sec': fnum(row.get('last_event_age_sec'), 999999.0),
            'last_event_sol': fnum(row.get('last_event_sol'), 0.0),
            'last_event_wallet': row.get('last_event_wallet') or '',
            'last_event_fresh': bool(row.get('last_event_fresh', False)),
            'buy_sol_recent': fnum(row.get('buy_sol_recent'), 0.0),
            'sell_sol_recent': fnum(row.get('sell_sol_recent'), 0.0),
        }

    def _wallet_summary(self, f: Dict[str, Any]) -> WalletRoleSummary:
        if f.get('live_wallet_events') or f.get('live_event_wallets'):
            return self.wallet_intel.summary_from_live_events(f.get('live_wallet_events') or [])
        return self.wallet_intel.mint_summary(f['mint'])

    def _hard_reject(self, f: Dict[str, Any], ws: WalletRoleSummary) -> str:
        if not f['mint']:
            return 'no_mint'

        # v11.2.37 PnL tune: reject corrupted/non-Pump tape before any lane can bypass it.
        # The latest SIM had several losing entries where token amounts were being treated
        # like SOL (last_event_sol/buy_sol_recent in the millions) or market cap was
        # obviously malformed. Those should be data-quality blocks, not trade signals.
        if self.cfg.get('PNL_REQUIRE_PUMPFUN_MINT', True) and not str(f.get('mint') or '').endswith('pump'):
            return 'pnl_non_pumpfun_mint'
        min_mc = fnum(self.cfg.get('PNL_MIN_MC_SOL'), 0.0)
        max_mc = fnum(self.cfg.get('PNL_MAX_MC_SOL'), 0.0)
        if min_mc > 0 and fnum(f.get('mc'), 0.0) < min_mc:
            return f'pnl_mc_too_low_{fnum(f.get("mc"),0.0):.2f}'
        if max_mc > 0 and fnum(f.get('mc'), 0.0) > max_mc:
            return f'pnl_mc_too_high_{fnum(f.get("mc"),0.0):.2f}'
        max_last_event_sol = fnum(self.cfg.get('PNL_MAX_LAST_EVENT_SOL', self.cfg.get('RANKER_MAX_SINGLE_EVENT_SOL')), 0.0)
        if max_last_event_sol > 0 and fnum(f.get('last_event_sol'), 0.0) > max_last_event_sol:
            return f'pnl_last_event_sol_suspicious_{fnum(f.get("last_event_sol"),0.0):.3f}'
        max_recent_buy_sol = fnum(self.cfg.get('PNL_MAX_RECENT_BUY_SOL'), 0.0)
        if max_recent_buy_sol > 0 and fnum(f.get('buy_sol_recent'), 0.0) > max_recent_buy_sol:
            return f'pnl_recent_buy_sol_suspicious_{fnum(f.get("buy_sol_recent"),0.0):.3f}'

        # v11.2.36: block re-entry on a mint that lost money in the last 5 minutes
        recent_loss_ts = self.recent_mint_losses.get(f['mint'], 0)
        if recent_loss_ts > 0 and (inum(f.get('ts'), now_ts()) - recent_loss_ts) < fnum(self.cfg.get('SAME_MINT_LOSS_BLOCK_SEC'), 300.0):
            return f'same_mint_recent_loss_{int(inum(f.get("ts"), now_ts()) - recent_loss_ts)}s'
        if self.cfg.get('FRESH_INCOMING_BUY_ONLY', True):
            if f.get('last_side') != 'buy':
                return 'not_new_incoming_buy'
            if not f.get('last_event_fresh'):
                return f'stale_entry_event_age_{f.get("last_event_age_sec", 999999):.1f}'
            if f.get('last_event_age_sec', 999999) > fnum(self.cfg.get('MAX_ENTRY_EVENT_AGE_SEC'), 8.0):
                return f'entry_event_too_old_{f.get("last_event_age_sec", 999999):.1f}'
            if fnum(self.cfg.get('MIN_LAST_BUY_SOL'), 0.0) > 0 and f.get('last_event_sol', 0.0) < fnum(self.cfg.get('MIN_LAST_BUY_SOL'), 0.01):
                return f'last_buy_sol_too_small_{f.get("last_event_sol", 0.0):.6f}'
            if fnum(self.cfg.get('MIN_RECENT_BUY_SOL'), 0.0) > 0 and f.get('buy_sol_recent', 0.0) < fnum(self.cfg.get('MIN_RECENT_BUY_SOL'), 0.015):
                return f'recent_buy_sol_too_small_{f.get("buy_sol_recent", 0.0):.6f}'
        if self.cooldowns.get(f['mint'], 0) > now_ts():
            return 'mint_cooldown'
        if f['rug_risk'] > fnum(self.cfg.get('MAX_RUG_RISK'), 68.0):
            return f'rug_risk_{f["rug_risk"]:.1f}'
        if f['sell_pressure'] > fnum(self.cfg.get('MAX_SELL_PRESSURE'), 0.62):
            return f'sell_pressure_{f["sell_pressure"]:.2f}'
        if f['total_sell_buy_ratio'] > fnum(self.cfg.get('MAX_SELL_BUY_RATIO'), 1.75):
            return f'sell_buy_ratio_{f["total_sell_buy_ratio"]:.2f}'
        # Hard danger is not absolute when multiple known accumulators are actively buying.
        accumulator_power = ws.accumulator_count + ws.alpha_count
        if ws.dump_risk_count > inum(self.cfg.get('MAX_DUMP_RISK_WALLETS'), 0) and accumulator_power < inum(self.cfg.get('DUMP_RISK_BYPASS_MIN_ACCUMULATORS'), 2):
            return f'dump_risk_wallets_{ws.dump_risk_count}'
        if ws.sell_only_count > inum(self.cfg.get('MAX_SELL_ONLY_WALLETS'), 0) and accumulator_power < inum(self.cfg.get('SELL_ONLY_BYPASS_MIN_ACCUMULATORS'), 2):
            return f'sell_only_wallets_{ws.sell_only_count}'
        if ws.danger_count > inum(self.cfg.get('MAX_DANGER_WALLETS'), 3) and accumulator_power < inum(self.cfg.get('DANGER_BYPASS_MIN_ACCUMULATORS'), 3):
            return f'danger_wallets_{ws.danger_count}'
        if f['pattern'] in HARD_RUG_PATTERNS and not bool(self.cfg.get('ALLOW_HARD_RUG_PATTERN_REBOUNDS', False)):
            return f'hard_rug_pattern_{f["pattern"]}'
        return ''


    def _strict_edge_reject(self, f: Dict[str, Any], ws: WalletRoleSummary, setup: str, score: float) -> str:
        """v11.2.41 SIM edge gate from the deep-dive review.

        This is intentionally applied AFTER a lane is selected, so wallet-copy,
        follow-money, queen/swarm, and AI lanes all have to prove the same clean
        tape: fresh buy, 3+ buyers/buys, strong wallet score, low cap, low rug,
        low sell pressure. Disable STRICT_EDGE_MODE in config for wider data runs.
        """
        if not self.cfg.get('STRICT_EDGE_MODE', False):
            return ''
        setup = str(setup or 'none')
        exempt = self._cfg_csv_set('STRICT_EDGE_EXEMPT_SETUPS', '')
        if setup in exempt:
            return ''
        min_buys = inum(self.cfg.get('STRICT_EDGE_MIN_RECENT_BUYS', self.cfg.get('MIN_RECENT_BUYS', 3)), 3)
        min_buyers = inum(self.cfg.get('STRICT_EDGE_MIN_RECENT_BUYERS', self.cfg.get('MIN_RECENT_BUYERS', 3)), 3)
        min_buy_sol = fnum(self.cfg.get('STRICT_EDGE_MIN_BUY_SOL_RECENT', self.cfg.get('MIN_BUY_SOL_RECENT', 1.6)), 1.6)
        min_wallet_score = fnum(self.cfg.get('STRICT_EDGE_MIN_WALLET_SCORE', self.cfg.get('MIN_WALLET_SCORE', 50.0)), 50.0)
        max_ratio = fnum(self.cfg.get('STRICT_EDGE_MAX_TOTAL_SELL_BUY_RATIO', self.cfg.get('MAX_TOTAL_SELL_BUY_RATIO', 0.85)), 0.85)
        max_rug = fnum(self.cfg.get('STRICT_EDGE_MAX_RUG_RISK', self.cfg.get('MAX_RUG_RISK', 14.0)), 14.0)
        max_mc = fnum(self.cfg.get('STRICT_EDGE_MAX_MC_SOL', self.cfg.get('HARD_MAX_MC_SOL', 100.0)), 100.0)
        min_score = fnum(self.cfg.get('STRICT_EDGE_MIN_SCORE', 0.0), 0.0)
        wallet_score = fnum(f.get('wallet_score'), 0.0)
        if f.get('last_side') != 'buy' or not f.get('last_event_fresh'):
            return 'strict_edge_not_fresh_buy'
        if inum(f.get('recent_buys'), 0) < min_buys:
            return f'strict_edge_recent_buys_{inum(f.get("recent_buys"),0)}_lt_{min_buys}'
        if inum(f.get('recent_buyers'), 0) < min_buyers:
            return f'strict_edge_recent_buyers_{inum(f.get("recent_buyers"),0)}_lt_{min_buyers}'
        if fnum(f.get('buy_sol_recent'), 0.0) < min_buy_sol:
            return f'strict_edge_buy_sol_recent_{fnum(f.get("buy_sol_recent"),0.0):.3f}_lt_{min_buy_sol:.3f}'
        if wallet_score < min_wallet_score:
            return f'strict_edge_wallet_score_{wallet_score:.1f}_lt_{min_wallet_score:.1f}'
        if fnum(f.get('mc'), 0.0) <= 0 or fnum(f.get('mc'), 0.0) > max_mc:
            return f'strict_edge_mc_{fnum(f.get("mc"),0.0):.2f}_gt_{max_mc:.2f}'
        if fnum(f.get('total_sell_buy_ratio'), 99.0) > max_ratio:
            return f'strict_edge_sell_buy_ratio_{fnum(f.get("total_sell_buy_ratio"),99.0):.2f}_gt_{max_ratio:.2f}'
        if fnum(f.get('rug_risk'), 99.0) > max_rug:
            return f'strict_edge_rug_risk_{fnum(f.get("rug_risk"),99.0):.1f}_gt_{max_rug:.1f}'
        if min_score > 0 and score < min_score:
            return f'strict_edge_score_{score:.1f}_lt_{min_score:.1f}'
        return ''

    def _queen_signature(self, f: Dict[str, Any], ws: WalletRoleSummary) -> Dict[str, Any]:
        tracked_power = ws.accumulator_count + ws.alpha_count
        sell_buy_sol_ratio = ws.top_sell_sol / max(0.000001, ws.top_buy_sol)
        last_wallet = f.get('last_event_wallet') or ''
        last_role = self.wallet_intel.role_for_wallet(last_wallet) if last_wallet else 'unknown'
        return {
            'tracked_power': tracked_power,
            'sell_buy_sol_ratio': sell_buy_sol_ratio,
            'last_wallet_role': last_role,
            'queen_pressure': ws.sell_near_high_count + ws.dump_risk_count + ws.sell_only_count + max(0, ws.danger_count),
            'worker_pressure': tracked_power,
        }

    def _queen_guard_reject(self, f: Dict[str, Any], ws: WalletRoleSummary, sig: Dict[str, Any]) -> str:
        if not self.cfg.get('QUEEN_GUARD_ENABLED', True):
            return ''
        tracked_power = int(sig.get('tracked_power', 0))
        min_workers = inum(self.cfg.get('QUEEN_MIN_ALPHA_ACCUMULATORS'), 1)
        if self.cfg.get('QUEEN_BLOCK_LAST_BUY_FROM_EXIT_ROLE', True) and sig.get('last_wallet_role') in ('sell_near_high','sell_only','dump_risk','flipper') and tracked_power < min_workers:
            return f"queen_guard_last_buyer_role_{sig.get('last_wallet_role')}"
        if ws.sell_near_high_count > inum(self.cfg.get('QUEEN_MAX_SELL_NEAR_HIGH_WITHOUT_ALPHA'), 1) and tracked_power < min_workers:
            return f'queen_guard_sell_near_high_{ws.sell_near_high_count}_workers_{tracked_power}'
        if ws.danger_count > inum(self.cfg.get('QUEEN_MAX_DANGER_WITHOUT_ALPHA'), 0) and tracked_power < min_workers:
            return f'queen_guard_danger_{ws.danger_count}_workers_{tracked_power}'
        if ws.flipper_count > inum(self.cfg.get('QUEEN_MAX_FLIPPERS_WITHOUT_ALPHA'), 1) and tracked_power < min_workers:
            return f'queen_guard_flippers_{ws.flipper_count}_workers_{tracked_power}'
        ratio = fnum(sig.get('sell_buy_sol_ratio'), 0.0)
        if ws.top_buy_sol > 0 and ratio > fnum(self.cfg.get('QUEEN_MAX_TOP_SELL_BUY_SOL_RATIO'), 0.55) and tracked_power < min_workers:
            return f'queen_guard_top_sell_buy_sol_ratio_{ratio:.2f}'
        return ''


    def _live_safety_enabled(self) -> bool:
        mode = str(self.cfg.get('MODE') or '')
        return bool(self.cfg.get('LIVE_SAFETY_MODE', True)) and (mode == 'live' or bool(self.cfg.get('LIVE_SAFETY_APPLIES_TO_SIM', True)))

    def _live_safety_reject(self, f: Dict[str, Any], ws: WalletRoleSummary, sig: Dict[str, Any]) -> str:
        """Extra live-test guard built from the v11.2.3 run.

        The last 0.5 SOL run was profitable overall, but hard stops came from entries
        that looked clean by raw buy flow while still carrying queen/exit-role pressure
        or entering after the first burst had already matured. This guard keeps the
        bot aggressive only when the fresh buy is strong AND the hive is not showing
        queen bait.
        """
        if not self._live_safety_enabled():
            return ''
        tracked_power = ws.accumulator_count + ws.alpha_count
        strong_workers = (
            tracked_power >= inum(self.cfg.get('LIVE_STRONG_WORKER_MIN_ACCUMULATORS'), 2) and
            ws.top_net_buy_sol >= fnum(self.cfg.get('LIVE_STRONG_WORKER_MIN_NET_BUY_SOL'), 1.25)
        )
        if (not self.cfg.get('LIVE_IGNORE_MC_LIMITS', True)) and f.get('mc', 0.0) > fnum(self.cfg.get('LIVE_MAX_ENTRY_MC'), 85.0):
            return f'live_guard_mc_too_high_{f.get("mc",0.0):.1f}'
        # v11.2.15: do not treat token age as stale when the *incoming buy event* is fresh.
        # The last run showed thousands of live_guard_age_too_old_* blocks even though
        # WSS event_age was 0.0s. Live copy trading should key off fresh buys, not token age.
        if self.cfg.get('LIVE_USE_TOKEN_AGE_GUARD', False) and f.get('age', 0.0) > fnum(self.cfg.get('LIVE_TOKEN_AGE_MAX_SEC'), fnum(self.cfg.get('LIVE_MAX_ENTRY_AGE_SEC'), 75.0)):
            return f'live_guard_token_age_too_old_{f.get("age",0.0):.1f}'
        if f.get('last_event_age_sec', 999999.0) > fnum(self.cfg.get('MAX_ENTRY_EVENT_AGE_SEC'), 12.0):
            return f'live_guard_event_age_too_old_{f.get("last_event_age_sec",999999.0):.1f}'
        if f.get('last_event_sol', 0.0) < fnum(self.cfg.get('LIVE_MIN_LAST_BUY_SOL'), 0.08):
            return f'live_guard_last_buy_sol_{f.get("last_event_sol",0.0):.4f}'
        if f.get('buy_sol_recent', 0.0) < fnum(self.cfg.get('LIVE_MIN_RECENT_BUY_SOL'), 0.50):
            return f'live_guard_recent_buy_sol_{f.get("buy_sol_recent",0.0):.4f}'
        if ws.top_buy_sol < fnum(self.cfg.get('LIVE_MIN_TOP_BUY_SOL'), 0.50):
            return f'live_guard_top_buy_sol_{ws.top_buy_sol:.4f}'
        if ws.top_net_buy_sol < fnum(self.cfg.get('LIVE_MIN_TOP_NET_BUY_SOL'), 0.50):
            return f'live_guard_top_net_buy_sol_{ws.top_net_buy_sol:.4f}'
        if f.get('sell_pressure', 0.0) > fnum(self.cfg.get('LIVE_MAX_SELL_PRESSURE'), 0.20):
            return f'live_guard_sell_pressure_{f.get("sell_pressure",0.0):.2f}'
        if f.get('total_sell_buy_ratio', 0.0) > fnum(self.cfg.get('LIVE_MAX_SELL_BUY_RATIO'), 0.35):
            return f'live_guard_sell_buy_ratio_{f.get("total_sell_buy_ratio",0.0):.2f}'
        if f.get('recent_sells', 0) > inum(self.cfg.get('LIVE_MAX_RECENT_SELLS'), 2) and f.get('sell_pressure', 0.0) > 0.08:
            return f'live_guard_recent_sells_{f.get("recent_sells",0)}'
        ratio = fnum(sig.get('sell_buy_sol_ratio'), 0.0)
        if ratio > fnum(self.cfg.get('LIVE_BLOCK_TOP_SELL_BUY_RATIO_ABOVE'), 0.18):
            return f'live_guard_top_sell_buy_ratio_{ratio:.2f}'
        if self.cfg.get('LIVE_BLOCK_DUMP_RISK_ANY', True) and ws.dump_risk_count > 0:
            return f'live_guard_dump_risk_{ws.dump_risk_count}'
        if self.cfg.get('LIVE_BLOCK_SELL_ONLY_ANY', True) and ws.sell_only_count > 0:
            return f'live_guard_sell_only_{ws.sell_only_count}'
        if self.cfg.get('LIVE_BLOCK_DANGER_WITHOUT_STRONG_WORKERS', True) and ws.danger_count > 0 and not strong_workers:
            return f'live_guard_danger_{ws.danger_count}_workers_{tracked_power}'
        if self.cfg.get('LIVE_BLOCK_SELL_NEAR_HIGH_WITHOUT_STRONG_WORKERS', True) and ws.sell_near_high_count > 0 and not strong_workers:
            # Single exit-role wallet is tolerated only when an accumulator is the fresh buyer,
            # no actual sell SOL has hit this window, and the crowd/worker swarm is broad.
            single_exit_role_ok = (
                ws.sell_near_high_count == 1 and tracked_power >= 1 and
                f.get('recent_buyers', 0) >= inum(self.cfg.get('LIVE_SELL_NEAR_HIGH_SINGLE_WITH_ACCUM_OK_MIN_BUYERS'), 5) and
                ws.top_sell_sol <= 0.000001 and
                f.get('sell_pressure', 0.0) <= fnum(self.cfg.get('LIVE_SELL_NEAR_HIGH_SINGLE_WITH_ACCUM_OK_MAX_SELL_PRESSURE'), 0.02)
            )
            if not single_exit_role_ok:
                return f'live_guard_sell_near_high_{ws.sell_near_high_count}_workers_{tracked_power}'
        return ''

    def _live_size_tier(self, setup: str, f: Dict[str, Any], ws: WalletRoleSummary, sig: Dict[str, Any], score: float) -> tuple[str, float]:
        """Return the configured universal live buy size.

        v11.2.30 removes tier/scout buy-size drift. All approved buy lanes
        (queen, worker, scout, swarm_edge, recovery, copy/probe) use BUY_SOL.
        The tier label is kept only for logging/diagnostics, not sizing.
        """
        universal = fnum(self.cfg.get('BUY_SOL'), fnum(self.cfg.get('FIXED_BUY_SOL'), 0.1))
        return 'BUY_SOL_UNIVERSAL', universal

    def _wallet_alpha_score(self, ws: WalletRoleSummary) -> float:
        score = 0.0
        score += ws.accumulator_count * fnum(self.cfg.get('ACCUMULATOR_SCORE'), 22.0)
        score += ws.alpha_count * fnum(self.cfg.get('ALPHA_SCORE'), 20.0)
        score += min(ws.top_buy_sol, 12.0) * fnum(self.cfg.get('TOP_BUY_SOL_SCORE'), 5.0)
        score += max(0.0, min(ws.top_net_buy_sol, 12.0)) * fnum(self.cfg.get('NET_BUY_SOL_SCORE'), 6.5)
        score += min(ws.early_buy_count, 12) * fnum(self.cfg.get('EARLY_BUY_SCORE'), 3.5)
        score -= ws.flipper_count * fnum(self.cfg.get('FLIPPER_PENALTY'), 4.0)
        score -= ws.dump_risk_count * fnum(self.cfg.get('DUMP_RISK_PENALTY'), 22.0)
        score -= ws.sell_only_count * fnum(self.cfg.get('SELL_ONLY_PENALTY'), 28.0)
        if not self.cfg.get('ALLOW_SELL_NEAR_HIGH_AS_ENTRY', False):
            score -= ws.sell_near_high_count * fnum(self.cfg.get('SELL_NEAR_HIGH_PENALTY'), 7.0)
        return score

    def _pattern_edge_score(self, pattern: str) -> float:
        # Use pattern_intel/missed-runner memory indirectly by giving bot-noise rebound patterns
        # a chance only when wallet flow confirms. Bad names are not automatic blocks.
        if pattern in GOOD_PATTERNS:
            return 14.0
        if pattern == 'early_watch':
            return 4.0
        if pattern in BOT_NOISE_PATTERNS:
            return -4.0
        return 0.0

    def _flow_score(self, f: Dict[str, Any]) -> float:
        delta = max(0, f['recent_buys'] - f['recent_sells'])
        return (
            f['recent_buys'] * 4.5 +
            f['recent_buyers'] * 5.5 +
            delta * 7.0 +
            min(f['buy_accel'], 10.0) * 3.5 -
            f['recent_sells'] * 3.0
        )

    def _risk_penalty(self, f: Dict[str, Any]) -> float:
        return f['rug_risk'] * 0.30 + f['sell_pressure'] * 34.0 + f['total_sell_buy_ratio'] * 7.0 + f['pullback_pct'] * 6.0

    def _setup_size_mult(self, setup: str) -> float:
        return fnum((self.cfg.get('SETUP_SIZE_MULT') or {}).get(setup), 1.0)

    def _hive_state(self, f: Dict[str, Any]) -> Dict[str, Any]:
        if not self.hive_graph:
            return {}
        try:
            return self.hive_graph.analyze_events(f.get('mint',''), f.get('live_wallet_events') or [], write=True)
        except Exception as e:
            append_jsonl('runtime_errors.jsonl', {'ts': now_ts(), 'where': 'strategy_hive_state', 'mint': f.get('mint'), 'error': repr(e)})
            return {}

    def _hive_entry_bonus(self, hive: Dict[str, Any]) -> float:
        if not hive:
            return 0.0
        bonus = 0.0
        bonus += inum(hive.get('worker_buys'), 0) * fnum(self.cfg.get('QUEEN_WORKER_BUY_SCORE'), 9.0)
        bonus += min(fnum(hive.get('worker_buy_sol'), 0.0), 5.0) * fnum(self.cfg.get('QUEEN_WORKER_SOL_SCORE'), 16.0)
        bonus += min(fnum(hive.get('net_hive_sol'), 0.0), 5.0) * fnum(self.cfg.get('HIVE_NET_SOL_SCORE'), 8.0)
        if hive.get('worker_entry_ok'):
            bonus += fnum(self.cfg.get('QUEEN_WORKER_ENTRY_OK_BONUS'), 18.0)
        if hive.get('worker_swarm_ok'):
            bonus += fnum(self.cfg.get('WORKER_SWARM_OK_BONUS'), 14.0)
        # v11.2.18: watch_surge — clean crowd momentum before any queen selling
        if hive.get('watch_surge_ok'):
            bonus += fnum(self.cfg.get('WATCH_SURGE_BONUS'), 10.0)
        # v11.2.18: winning_counter_score from hive pattern memory (worker_swarm→queen_exit history)
        wcs = fnum(hive.get('winning_counter_score'), 0.0)
        if wcs > 0:
            bonus += wcs * fnum(self.cfg.get('WINNING_COUNTER_SCORE_MULT'), 1.0)
        # v11.2.18: soft_worker signal — watch wallets with high individual SOL
        soft_sol = fnum(hive.get('soft_worker_sol'), 0.0)
        if soft_sol > 0 and hive.get('soft_worker_buys', 0) >= 1:
            bonus += min(soft_sol, 3.0) * fnum(self.cfg.get('SOFT_WORKER_SOL_SCORE'), 6.0)
        # v11.2.18: queen_pre_exit_warning — queen is buying heavily, sell may come soon
        if hive.get('queen_pre_exit_warning'):
            bonus -= fnum(self.cfg.get('QUEEN_PRE_EXIT_PENALTY'), 20.0)
        # v11.2.18: is_late_queen_entry — queen_exit already fired for this mint, block
        if hive.get('is_late_queen_entry'):
            bonus -= fnum(self.cfg.get('LATE_QUEEN_ENTRY_PENALTY'), 50.0)
        if hive.get('queen_exit_now'):
            bonus -= fnum(self.cfg.get('QUEEN_EXIT_SCORE_PENALTY'), 45.0)
        if hive.get('hive_flip_exit'):
            bonus -= fnum(self.cfg.get('HIVE_FLIP_SCORE_PENALTY'), 35.0)
        return bonus

    def _hive_entry_reject(self, hive: Dict[str, Any]) -> str:
        if not hive or not self.cfg.get('QUEEN_WORKER_GRAPH_ENABLED', True):
            return ''
        if hive.get('queen_exit_now'):
            return 'queen_worker_graph_queen_exit_shadow_entry_block'
        if hive.get('hive_flip_exit') and not hive.get('worker_entry_ok'):
            return 'queen_worker_graph_hive_flip_entry_block'
        # v11.2.18: block entries when this mint already saw queen_exit (late entry)
        if hive.get('is_late_queen_entry') and not hive.get('worker_entry_ok') and not hive.get('worker_swarm_ok'):
            return 'queen_worker_graph_late_queen_entry_block'
        # v11.2.18: block when queen is buying heavily (pre-exit warning) with no strong workers
        if hive.get('queen_pre_exit_warning') and not hive.get('worker_entry_ok') and not hive.get('worker_swarm_ok'):
            return 'queen_pre_exit_warning_no_worker_cover'
        return ''

    def _pnl_filtered_hive_entry_ok(self, f: Dict[str, Any], hive: Dict[str, Any], score: float) -> tuple[bool, str]:
        """v11.2.21: data-fit noise filter for the profitable Hive lane.

        The supplied run showed the best PnL-rate when entries had a broad, high-SOL
        worker/soft-worker cluster. Thin worker_swarm signals were net negative, so
        this filter requires enough hive net SOL, enough worker/soft-worker buys,
        enough buyers, and a high score before a queen_worker_front_run entry can fire.
        """
        if not self.cfg.get('HIVE_PNL_FILTER_ENABLED', True):
            return True, ''
        min_score = fnum(self.cfg.get('HIVE_PNL_MIN_SCORE'), fnum(self.cfg.get('QUEEN_WORKER_FRONT_RUN_MIN_SCORE'), 450.0))
        min_worker_buys = inum(self.cfg.get('HIVE_PNL_MIN_WORKER_BUYS'), 4)
        min_net_sol = fnum(self.cfg.get('HIVE_PNL_MIN_NET_HIVE_SOL'), 5.0)
        min_recent_buys = inum(self.cfg.get('HIVE_PNL_MIN_RECENT_BUYS'), 4)
        min_recent_buyers = inum(self.cfg.get('HIVE_PNL_MIN_RECENT_BUYERS'), 4)
        max_sell_pressure = fnum(self.cfg.get('HIVE_PNL_MAX_SELL_PRESSURE'), 0.23)
        max_ratio = fnum(self.cfg.get('HIVE_PNL_MAX_SELL_BUY_RATIO'), 0.24)
        checks = [
            (score >= min_score, f'pnl_filter_score_{score:.1f}_lt_{min_score:.1f}'),
            (inum(hive.get('worker_buys'), 0) >= min_worker_buys, f'pnl_filter_worker_buys_{hive.get("worker_buys",0)}_lt_{min_worker_buys}'),
            (fnum(hive.get('net_hive_sol'), 0.0) >= min_net_sol, f'pnl_filter_net_hive_sol_{fnum(hive.get("net_hive_sol"),0.0):.3f}_lt_{min_net_sol:.3f}'),
            (f.get('recent_buys', 0) >= min_recent_buys, f'pnl_filter_recent_buys_{f.get("recent_buys",0)}_lt_{min_recent_buys}'),
            (f.get('recent_buyers', 0) >= min_recent_buyers, f'pnl_filter_recent_buyers_{f.get("recent_buyers",0)}_lt_{min_recent_buyers}'),
            (f.get('sell_pressure', 0.0) <= max_sell_pressure, f'pnl_filter_sell_pressure_{f.get("sell_pressure",0.0):.2f}_gt_{max_sell_pressure:.2f}'),
            (f.get('total_sell_buy_ratio', 0.0) <= max_ratio, f'pnl_filter_sell_buy_ratio_{f.get("total_sell_buy_ratio",0.0):.2f}_gt_{max_ratio:.2f}'),
        ]
        for ok, reason in checks:
            if not ok:
                return False, reason
        return True, ''

    def _scout_lanes_allowed(self) -> bool:
        """Experimental blocker-replay scout lanes.

        These lanes are intentionally SIM-first. They can be enabled in live only by
        setting SCOUT_LANES_ALLOW_LIVE=true. Normal entries still keep fresh-buy,
        queen, and recent-sell guards.
        """
        if not self.cfg.get('SCOUT_LANES_ENABLED', True):
            return False
        mode = str(self.cfg.get('MODE') or '').lower()
        return mode != 'live' or bool(self.cfg.get('SCOUT_LANES_ALLOW_LIVE', False))


    def _queen_dump_recovery_allowed(self) -> bool:
        """Queen-dump recovery lane is separate from general scout lanes.

        It is intentionally tiny-size and can be allowed in live with
        QUEEN_DUMP_RECOVERY_LIVE=true without opening every other scout lane.
        """
        if not self.cfg.get('QUEEN_DUMP_RECOVERY_ENABLED', True):
            return False
        mode = str(self.cfg.get('MODE') or '').lower()
        return mode != 'live' or bool(self.cfg.get('QUEEN_DUMP_RECOVERY_LIVE', True))

    def _event_role(self, wallet: str) -> str:
        if not wallet:
            return 'unknown'
        try:
            if self.hive_graph:
                return self.hive_graph.role_for_wallet(wallet)
        except Exception:
            pass
        try:
            return self.wallet_intel.role_for_wallet(wallet)
        except Exception:
            return 'watch'

    def _is_queen_exit_role(self, role: str) -> bool:
        role = str(role or '').lower()
        return (
            role.startswith('queen_') or
            role in ('dump_risk', 'sell_only', 'sell_near_high', 'queen_dump_risk', 'queen_sell_only', 'queen_sell_near_high') or
            'dump_risk' in role or 'sell_only' in role or 'sell_near_high' in role
        )

    def _queen_dump_recovery_signal(self, f: Dict[str, Any], ws: WalletRoleSummary, sig: Dict[str, Any], hive: Dict[str, Any], score: float) -> tuple[bool, str, Dict[str, Any]]:
        """Detect the specific edge from the blocker replay:

        queen/dump wallet sells first, then workers refill immediately.
        This is NOT a normal tracked-wallet buy. It only fires after a known
        queen/dump/sell-near-high wallet sold and the next few seconds show a
        fresh refill with enough unique buyers and SOL.
        """
        details: Dict[str, Any] = {}
        if not self._queen_dump_recovery_allowed():
            return False, 'queen_dump_recovery_disabled_or_live_locked', details

        events = sorted((f.get('live_wallet_events') or []), key=lambda e: inum(e.get('ts'), 0))
        if not events:
            return False, 'queen_dump_recovery_no_events', details
        if self.cfg.get('QUEEN_DUMP_RECOVERY_REQUIRE_LAST_SIDE_BUY', True) and f.get('last_side') != 'buy':
            return False, 'queen_dump_recovery_last_side_not_buy', details
        if self.cfg.get('QUEEN_DUMP_RECOVERY_REQUIRE_FRESH_LAST_BUY', True) and not f.get('last_event_fresh'):
            return False, 'queen_dump_recovery_last_buy_not_fresh', details

        # Find the most recent queen/dump-role SELL in the rolling book.
        queen_sell = None
        for e in reversed(events):
            side = str(e.get('side') or e.get('txType') or '').lower()
            wallet = e.get('wallet') or e.get('traderPublicKey') or ''
            role = self._event_role(wallet)
            if side == 'sell' and self._is_queen_exit_role(role):
                queen_sell = {**e, 'role': role}
                break
        if not queen_sell:
            return False, 'queen_dump_recovery_no_recent_queen_sell', details

        qts = inum(queen_sell.get('ts'), 0)
        now = inum(f.get('ts'), now_ts())
        max_age = fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_MAX_QUEEN_SELL_AGE_SEC'), 8.0)
        if qts <= 0 or now - qts > max_age:
            return False, f'queen_dump_recovery_queen_sell_too_old_{now-qts:.1f}', details

        win = fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_WINDOW_SEC'), 3.0)
        after = [e for e in events if inum(e.get('ts'), 0) > qts and inum(e.get('ts'), 0) - qts <= win]
        buys_after = [e for e in after if str(e.get('side') or '').lower() == 'buy']
        sells_after = [e for e in after if str(e.get('side') or '').lower() == 'sell']
        # Only count refill from non-queen buyers; queen buybacks can be bait.
        safe_buys = []
        danger_buy_wallets = []
        for e in buys_after:
            wallet = e.get('wallet') or e.get('traderPublicKey') or ''
            role = self._event_role(wallet)
            if self._is_queen_exit_role(role):
                danger_buy_wallets.append(wallet)
            else:
                safe_buys.append(e)
        fresh_buys = len(safe_buys)
        unique_buyers = len({e.get('wallet') or e.get('traderPublicKey') or '' for e in safe_buys if (e.get('wallet') or e.get('traderPublicKey'))})
        buy_sol = sum(fnum(e.get('sol') if e.get('sol') is not None else e.get('solAmount'), 0.0) for e in safe_buys)
        sell_sol = sum(fnum(e.get('sol') if e.get('sol') is not None else e.get('solAmount'), 0.0) for e in sells_after)
        pressure_after = len(sells_after) / max(1, len(after))
        ratio_after = sell_sol / max(0.000001, buy_sol)
        queen_sells_after = 0
        for e in sells_after:
            wallet = e.get('wallet') or e.get('traderPublicKey') or ''
            if self._is_queen_exit_role(self._event_role(wallet)):
                queen_sells_after += 1

        details = {
            'queen_sell_wallet': queen_sell.get('wallet') or queen_sell.get('traderPublicKey') or '',
            'queen_sell_role': queen_sell.get('role'),
            'queen_sell_age_sec': round(now - qts, 3),
            'refill_window_sec': win,
            'fresh_buys_after_dump': fresh_buys,
            'unique_buyers_after_dump': unique_buyers,
            'buy_sol_after_dump': round(buy_sol, 9),
            'sell_sol_after_dump': round(sell_sol, 9),
            'sell_pressure_after_dump': round(pressure_after, 6),
            'sell_buy_ratio_after_dump': round(ratio_after, 6),
            'queen_sells_after_dump': queen_sells_after,
            'danger_buy_wallets_after_dump': len(set(danger_buy_wallets)),
        }

        checks = [
            (score >= fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_MIN_SCORE'), 0.0), f'queen_dump_recovery_score_{score:.1f}_low'),
            (fresh_buys >= inum(self.cfg.get('QUEEN_DUMP_RECOVERY_MIN_FRESH_BUYS'), 3), f'queen_dump_recovery_fresh_buys_{fresh_buys}_low'),
            (unique_buyers >= inum(self.cfg.get('QUEEN_DUMP_RECOVERY_MIN_UNIQUE_BUYERS'), 2), f'queen_dump_recovery_unique_buyers_{unique_buyers}_low'),
            (buy_sol >= fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_MIN_BUY_SOL'), 2.0), f'queen_dump_recovery_buy_sol_{buy_sol:.3f}_low'),
            (buy_sol > sell_sol, f'queen_dump_recovery_buy_sol_not_dominant_{buy_sol:.3f}_vs_{sell_sol:.3f}'),
            (pressure_after <= fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_MAX_SELL_PRESSURE_AFTER_REFILL'), 0.35), f'queen_dump_recovery_pressure_{pressure_after:.2f}_high'),
            (ratio_after <= fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_MAX_SELL_BUY_RATIO_AFTER_REFILL'), 0.55), f'queen_dump_recovery_ratio_{ratio_after:.2f}_high'),
            (queen_sells_after <= inum(self.cfg.get('QUEEN_DUMP_RECOVERY_MAX_QUEEN_SELLS_AFTER_REFILL'), 0), f'queen_dump_recovery_more_queen_sells_{queen_sells_after}'),
            (len(set(danger_buy_wallets)) <= inum(self.cfg.get('QUEEN_DUMP_RECOVERY_MAX_DANGER_BUYERS_AFTER_REFILL'), 0), f'queen_dump_recovery_danger_buys_{len(set(danger_buy_wallets))}'),
        ]
        for ok, why in checks:
            if not ok:
                return False, why, details
        return True, 'queen_dump_recovery_worker_refill_after_queen_dump', details



    def _pressure_runner_lift_signal(self, f: Dict[str, Any], ws: WalletRoleSummary, sig: Dict[str, Any], hive: Dict[str, Any], score: float) -> tuple[bool, str, Dict[str, Any]]:
        """High-conviction runner lane built from the latest blocker replay.

        The new data showed many tiny/normal blockers are protective, but a small
        subset of blocked entries became runners: broad worker-entry/worker-swarm
        flow, high score, many unique buyers, and still-playable sell pressure.
        This lane lifts soft blockers only in that context. It does not chase a
        single queen wallet or a one-wallet pump.
        """
        details = {
            'hive_state': hive.get('hive_state'),
            'score': round(score, 4),
            'recent_buys': f.get('recent_buys', 0),
            'recent_buyers': f.get('recent_buyers', 0),
            'sell_pressure': f.get('sell_pressure', 0.0),
            'buy_sol_recent': f.get('buy_sol_recent', 0.0),
            'last_side': f.get('last_side'),
            'danger_count': ws.danger_count,
            'dump_risk_count': ws.dump_risk_count,
            'sell_only_count': ws.sell_only_count,
            'top_net_buy_sol': ws.top_net_buy_sol,
        }
        confirm = self._priority_confirmation(f, hive)
        details['priority_confirmation'] = confirm
        if not self.cfg.get('PRESSURE_RUNNER_LIFT_ENABLED', True):
            return False, 'pressure_runner_disabled', details
        if hive.get('hive_state') not in ('worker_entry', 'worker_swarm'):
            return False, f"pressure_runner_hive_{hive.get('hive_state')}_not_worker", details

        # v11.2.36 pressure-runner focus patch:
        # Do not lift stale/dead worker flow. The profitable pressure_runner samples
        # came from strong active BUY pressure, not old worker-front-run leftovers.
        if self.cfg.get('PRESSURE_RUNNER_REQUIRE_LAST_SIDE_BUY', True) and str(f.get('last_side') or '').lower() != 'buy':
            return False, f"pressure_runner_last_side_{f.get('last_side')}_not_buy", details
        if self.cfg.get('PRESSURE_RUNNER_REQUIRE_FRESH_EVENT', True) and not bool(f.get('last_event_fresh')):
            return False, 'pressure_runner_last_event_not_fresh', details

        checks = [
            (score >= fnum(self.cfg.get('PRESSURE_RUNNER_MIN_SCORE'), 750.0), f'pressure_runner_score_{score:.1f}_low'),
            (inum(f.get('recent_buys'), 0) >= inum(self.cfg.get('PRESSURE_RUNNER_MIN_RECENT_BUYS'), 20), f'pressure_runner_recent_buys_{f.get("recent_buys",0)}_low'),
            (inum(f.get('recent_buyers'), 0) >= inum(self.cfg.get('PRESSURE_RUNNER_MIN_RECENT_BUYERS'), 8), f'pressure_runner_recent_buyers_{f.get("recent_buyers",0)}_low'),
            (fnum(f.get('buy_sol_recent'), 0.0) >= fnum(self.cfg.get('PRESSURE_RUNNER_MIN_BUY_SOL_RECENT'), 10.0), f'pressure_runner_buy_sol_recent_{fnum(f.get("buy_sol_recent"),0.0):.3f}_low'),
            (fnum(f.get('sell_pressure'), 1.0) <= fnum(self.cfg.get('PRESSURE_RUNNER_MAX_SELL_PRESSURE'), 0.38), f'pressure_runner_sell_pressure_{fnum(f.get("sell_pressure"),0.0):.2f}_high'),
            (fnum(f.get('total_sell_buy_ratio'), 99.0) <= fnum(self.cfg.get('PRESSURE_RUNNER_MAX_SELL_BUY_RATIO'), 0.85), f'pressure_runner_sell_buy_ratio_{fnum(f.get("total_sell_buy_ratio"),0.0):.2f}_high'),
            (ws.sell_only_count <= inum(self.cfg.get('PRESSURE_RUNNER_MAX_SELL_ONLY_WALLETS'), 0), f'pressure_runner_sell_only_{ws.sell_only_count}'),
            (ws.danger_count <= inum(self.cfg.get('PRESSURE_RUNNER_MAX_DANGER_WALLETS'), 3), f'pressure_runner_danger_{ws.danger_count}'),
            (ws.dump_risk_count <= inum(self.cfg.get('PRESSURE_RUNNER_MAX_DUMP_RISK_WALLETS'), 1), f'pressure_runner_dump_risk_{ws.dump_risk_count}'),
            (ws.top_net_buy_sol >= fnum(self.cfg.get('PRESSURE_RUNNER_MIN_TOP_NET_BUY_SOL'), 1.0), f'pressure_runner_top_net_buy_sol_{ws.top_net_buy_sol:.3f}_low'),
        ]
        if self.cfg.get('PRESSURE_RUNNER_REQUIRE_PRIORITY_CONFIRM', False) and not confirm.get('ok'):
            return False, 'pressure_runner_no_priority_or_extreme_flow_confirmation', details
        for ok, why in checks:
            if not ok:
                return False, why, details
        return True, 'pressure_runner_lift_confirmed_worker_runner', details

    def _queen_cycle_ride_signal(self, f: Dict[str, Any], ws: WalletRoleSummary, sig: Dict[str, Any], hive: Dict[str, Any], score: float) -> tuple[bool, str, Dict[str, Any]]:
        """Ride a positive-net queen/whale buy BEFORE the dump.

        The new data showed wallets like BwWK... can make money by cycling:
        buy hard, dump, rebuy, dump. Waiting for the dump can enter late. This
        lane allows an entry on a fresh BUY from an exit-role wallet only when
        that same wallet is currently net-buying the mint and the tape has not
        shown a fresh post-buy dump yet. Exit logic then ignores tiny early hive
        flips for a few seconds but exits aggressively on fee-safe profit or real
        pressure.
        """
        details: Dict[str, Any] = {}
        if not self.cfg.get('QUEEN_CYCLE_RIDE_ENABLED', True):
            return False, 'queen_cycle_disabled', details
        if f.get('last_side') != 'buy' or not f.get('last_event_fresh'):
            return False, 'queen_cycle_not_fresh_buy', details
        last_wallet = f.get('last_event_wallet') or ''
        last_role = self._event_role(last_wallet)
        if not self._is_queen_exit_role(last_role):
            return False, 'queen_cycle_last_wallet_not_queen_role', details
        events = sorted((f.get('live_wallet_events') or []), key=lambda e: inum(e.get('ts'), 0))
        wallet_events = [e for e in events if (e.get('wallet') or e.get('traderPublicKey') or '') == last_wallet]
        if not wallet_events:
            return False, 'queen_cycle_no_wallet_events', details
        last_ts = inum(f.get('ts'), now_ts())
        lookback = fnum(self.cfg.get('QUEEN_CYCLE_LOOKBACK_SEC'), 12.0)
        recent = [e for e in wallet_events if last_ts - inum(e.get('ts'), 0) <= lookback]
        buys = [e for e in recent if str(e.get('side') or '').lower() == 'buy']
        sells = [e for e in recent if str(e.get('side') or '').lower() == 'sell']
        buy_sol = sum(fnum(e.get('sol') if e.get('sol') is not None else e.get('solAmount'), 0.0) for e in buys)
        sell_sol = sum(fnum(e.get('sol') if e.get('sol') is not None else e.get('solAmount'), 0.0) for e in sells)
        net_sol = buy_sol - sell_sol
        # Any sell from the same queen after the last buy means the dump already started.
        last_buy_ts = max([inum(e.get('ts'), 0) for e in buys] or [0])
        sells_after_last_buy = [e for e in sells if inum(e.get('ts'), 0) > last_buy_ts]
        details = {
            'queen_wallet': last_wallet,
            'queen_role': last_role,
            'queen_cycle_buy_sol': round(buy_sol, 9),
            'queen_cycle_sell_sol': round(sell_sol, 9),
            'queen_cycle_net_sol': round(net_sol, 9),
            'queen_cycle_buys': len(buys),
            'queen_cycle_sells': len(sells),
            'same_queen_sells_after_last_buy': len(sells_after_last_buy),
            'lookback_sec': lookback,
        }
        checks = [
            (fnum(f.get('last_event_sol'), 0.0) >= fnum(self.cfg.get('QUEEN_CYCLE_MIN_LAST_BUY_SOL'), 0.08), 'queen_cycle_last_buy_too_small'),
            (len(buys) >= inum(self.cfg.get('QUEEN_CYCLE_MIN_BUYS'), 2), 'queen_cycle_not_enough_queen_buys'),
            (net_sol >= fnum(self.cfg.get('QUEEN_CYCLE_MIN_NET_SOL'), 0.35), f'queen_cycle_net_sol_{net_sol:.3f}_low'),
            (len(sells_after_last_buy) <= inum(self.cfg.get('QUEEN_CYCLE_MAX_SELLS_AFTER_LAST_BUY'), 0), 'queen_cycle_same_queen_dump_started'),
            (fnum(f.get('sell_pressure'), 0.0) <= fnum(self.cfg.get('QUEEN_CYCLE_MAX_SELL_PRESSURE'), 0.42), 'queen_cycle_sell_pressure_high'),
            (fnum(f.get('total_sell_buy_ratio'), 0.0) <= fnum(self.cfg.get('QUEEN_CYCLE_MAX_SELL_BUY_RATIO'), 0.85), 'queen_cycle_sell_buy_ratio_high'),
            (score >= fnum(self.cfg.get('QUEEN_CYCLE_MIN_SCORE'), 0.0), 'queen_cycle_score_low'),
        ]
        for ok, why in checks:
            if not ok:
                return False, why, details
        return True, 'queen_cycle_positive_net_buy_before_dump', details


    def _recent_tape_context(self, f: Dict[str, Any], sec: float = 5.0) -> Dict[str, Any]:
        """Current-mint tape context used by mined swarm profiles.

        The miner learns thresholds like "this wallet only works when 5s buy SOL
        dominates and there are enough unique buyers." Live decisions must re-check
        that context; otherwise we would be blindly copy-trading stale wallet labels.
        """
        events = sorted((f.get('live_wallet_events') or []), key=lambda e: inum(e.get('ts'), 0))
        now = inum(f.get('ts'), now_ts())
        recent = [e for e in events if now - inum(e.get('ts'), 0) <= sec]
        buys = [e for e in recent if str(e.get('side') or e.get('txType') or '').lower() == 'buy']
        sells = [e for e in recent if str(e.get('side') or e.get('txType') or '').lower() == 'sell']
        def sol(e):
            return fnum(e.get('sol') if e.get('sol') is not None else e.get('solAmount'), 0.0)
        return {
            'buy_sol_5s': sum(sol(e) for e in buys),
            'sell_sol_5s': sum(sol(e) for e in sells),
            'unique_buyers_5s': len({e.get('wallet') or e.get('traderPublicKey') or '' for e in buys if (e.get('wallet') or e.get('traderPublicKey'))}),
            'buys_5s': len(buys),
            'sells_5s': len(sells),
            'exit_warning_sells_5s': len([e for e in sells if (e.get('wallet') or e.get('traderPublicKey') or '') in set(self.swarm_exit_wallets) | getattr(self, 'vetted_exit_set', set())]),
        }

    def _swarm_edge_auto_signal(self, f: Dict[str, Any], ws: WalletRoleSummary, sig: Dict[str, Any], hive: Dict[str, Any], score: float) -> tuple[bool, str, Dict[str, Any]]:
        """Mined wallet weakness lane.

        This is the automatic version of the 7oi/BwWK investigation: it does not
        require hard-coded wallets. swarm_edge_miner.py ranks wallets from raw
        tape, then this lane only enters when the current tape matches the learned
        context for that wallet and there is no fresh exit-warning sell.
        """
        details: Dict[str, Any] = {}
        if not self.cfg.get('SWARM_EDGE_AUTO_RIDE_ENABLED', True):
            return False, 'swarm_edge_disabled', details
        if not self.swarm_copy_wallets and not self.swarm_cycle_wallets:
            return False, 'swarm_edge_no_profiles', details
        if f.get('last_side') != 'buy' or not f.get('last_event_fresh'):
            return False, 'swarm_edge_not_fresh_buy', details
        wallet = f.get('last_event_wallet') or ''
        prof = self.swarm_copy_wallets.get(wallet)
        cycle = self.swarm_cycle_wallets.get(wallet)
        # v11.2.34: uploaded run showed cycle-only swarm_edge_auto_ride was fee-negative.
        # Only auto-ride mined wallets when the miner has a real copy-buy profile;
        # cycle wallets can still be researched in swarm_edge_profiles.json but do
        # not get live entry authority by themselves.
        if self.cfg.get('SWARM_EDGE_REQUIRE_COPY_PROFILE', True) and not prof:
            return False, 'swarm_edge_requires_positive_copy_profile', details
        if not prof and not (self.cfg.get('SWARM_EDGE_ALLOW_CYCLE_WALLETS', False) and cycle):
            return False, 'swarm_edge_wallet_not_profiled', details
        ctx = self._recent_tape_context(f, 5.0)
        pctx = (prof or {}).get('context') or {}
        # Profile thresholds are used if available; config defaults protect thin cycle profiles.
        min_age = fnum(pctx.get('min_token_age_sec'), fnum(self.cfg.get('SWARM_EDGE_MIN_TOKEN_AGE_SEC'), 10.0))
        min_buy_sol = fnum(pctx.get('min_buy_sol_5s'), fnum(self.cfg.get('SWARM_EDGE_MIN_BUY_SOL_5S'), 1.50))
        max_sell_sol = fnum(pctx.get('max_sell_sol_5s'), fnum(self.cfg.get('SWARM_EDGE_MAX_SELL_SOL_5S'), 0.80))
        min_buyers = inum(pctx.get('min_unique_buyers_5s'), inum(self.cfg.get('SWARM_EDGE_MIN_UNIQUE_BUYERS_5S'), 2))
        win_rate = fnum((prof or {}).get('win_rate'), 0.0)
        edge = fnum((prof or {}).get('fee_adjusted_edge_pct'), 0.0)
        details = {
            'wallet': wallet,
            'profile_role': (prof or cycle or {}).get('role'),
            'profile_samples': (prof or cycle or {}).get('samples') or (prof or cycle or {}).get('buy_count'),
            'profile_win_rate': win_rate,
            'profile_fee_edge_pct': edge,
            'profile_context': pctx,
            'tape_context': ctx,
            'token_age_sec': f.get('age'),
        }
        # If this is a pure cycle wallet, demand stronger net queen-cycle confirmation.
        if cycle and not prof:
            qok, qwhy, qdetails = self._queen_cycle_ride_signal(f, ws, sig, hive, score)
            details['cycle_confirmation'] = qdetails
            if not qok:
                return False, 'swarm_edge_cycle_without_qcycle_' + qwhy, details
        checks = [
            (score >= fnum(self.cfg.get('SWARM_EDGE_MIN_SCORE'), 90.0), 'swarm_edge_score_low'),
            (fnum(f.get('age'), 0.0) >= min_age, f'swarm_edge_age_{fnum(f.get("age"),0.0):.1f}_lt_{min_age:.1f}'),
            (ctx['buy_sol_5s'] >= min_buy_sol, f'swarm_edge_buy_sol_5s_{ctx["buy_sol_5s"]:.3f}_low'),
            (ctx['sell_sol_5s'] <= max_sell_sol, f'swarm_edge_sell_sol_5s_{ctx["sell_sol_5s"]:.3f}_high'),
            (ctx['unique_buyers_5s'] >= min_buyers, f'swarm_edge_unique_buyers_{ctx["unique_buyers_5s"]}_low'),
            (ctx['exit_warning_sells_5s'] <= inum(self.cfg.get('SWARM_EDGE_MAX_EXIT_WARNING_SELLS_5S'), 0), 'swarm_edge_exit_warning_wallet_selling'),
            (f.get('sell_pressure', 0.0) <= fnum(self.cfg.get('SWARM_EDGE_MAX_SELL_PRESSURE'), 0.46), 'swarm_edge_sell_pressure_high'),
            (f.get('total_sell_buy_ratio', 0.0) <= fnum(self.cfg.get('SWARM_EDGE_MAX_SELL_BUY_RATIO'), 0.90), 'swarm_edge_sell_buy_ratio_high'),
        ]
        # A copy wallet must have enough mined edge; a cycle wallet can pass via qcycle confirmation above.
        if prof:
            samples = inum((prof or {}).get('samples') or (prof or {}).get('buy_count'), 0)
            checks.extend([
                (samples >= inum(self.cfg.get('SWARM_EDGE_MIN_PROFILE_SAMPLES'), 6), 'swarm_edge_profile_samples_low'),
                (win_rate >= fnum(self.cfg.get('SWARM_EDGE_MIN_PROFILE_WIN_RATE'), 0.62), 'swarm_edge_profile_win_rate_low'),
                (edge >= fnum(self.cfg.get('SWARM_EDGE_MIN_PROFILE_FEE_EDGE_PCT'), 0.04), 'swarm_edge_profile_fee_edge_low'),
            ])
        for ok, why in checks:
            if not ok:
                return False, why, details
        return True, 'swarm_edge_auto_mined_wallet_context', details

    def _scout_pre_hard_allow(self, f: Dict[str, Any], ws: WalletRoleSummary, sig: Dict[str, Any], hive: Dict[str, Any], score: float) -> tuple[bool, str, str]:
        """Return whether an otherwise-blocked decision may continue as a tiny scout.

        This does not relax normal entries. It only lets controlled SIM/scout lanes
        test the specific blocker buckets that the replay report flagged as possibly
        hiding edge: post-sell recovery, rug-risk 65-90, and hive-state blocks.
        """
        if not self._scout_lanes_allowed():
            return False, '', 'scout_lanes_disabled_or_live_locked'
        queen_active = bool(hive.get('queen_exit_now') or hive.get('is_late_queen_entry') or hive.get('queen_pre_exit_warning'))
        danger_roles = ws.dump_risk_count + ws.sell_only_count + ws.danger_count + ws.sell_near_high_count
        ratio = f.get('total_sell_buy_ratio', 0.0)
        sell_pressure = f.get('sell_pressure', 0.0)
        buy_dominates = f.get('buy_sol_recent', 0.0) > max(f.get('sell_sol_recent', 0.0), 0.0)

        if self.cfg.get('POST_SELL_RECOVERY_SCOUT_ENABLED', True):
            ok = (
                f.get('last_side') == 'sell' and
                f.get('recent_buys', 0) >= inum(self.cfg.get('POST_SELL_SCOUT_MIN_RECENT_BUYS'), 2) and
                f.get('recent_buyers', 0) >= inum(self.cfg.get('POST_SELL_SCOUT_MIN_RECENT_BUYERS'), 2) and
                buy_dominates and
                sell_pressure <= fnum(self.cfg.get('POST_SELL_SCOUT_MAX_SELL_PRESSURE'), 0.25) and
                ratio <= fnum(self.cfg.get('POST_SELL_SCOUT_MAX_SELL_BUY_RATIO'), 0.35) and
                not queen_active and danger_roles <= inum(self.cfg.get('POST_SELL_SCOUT_MAX_DANGER_ROLES'), 0)
            )
            if ok:
                return True, 'post_sell_recovery_scout', 'post_sell_recovery_confirmed_by_buys'

        if self.cfg.get('RUG_SCOUT_ENABLED', True):
            rug = f.get('rug_risk', 0.0)
            ok = (
                rug > fnum(self.cfg.get('MAX_RUG_RISK'), 90.0) and
                rug <= fnum(self.cfg.get('RUG_SCOUT_MAX_RUG_RISK'), 90.0) and
                score >= fnum(self.cfg.get('RUG_SCOUT_MIN_SCORE'), 450.0) and
                sell_pressure <= fnum(self.cfg.get('RUG_SCOUT_MAX_SELL_PRESSURE'), 0.20) and
                ratio <= fnum(self.cfg.get('RUG_SCOUT_MAX_SELL_BUY_RATIO'), 0.30) and
                f.get('recent_buys', 0) >= inum(self.cfg.get('RUG_SCOUT_MIN_RECENT_BUYS'), 6) and
                f.get('recent_buyers', 0) >= inum(self.cfg.get('RUG_SCOUT_MIN_RECENT_BUYERS'), 4) and
                ws.top_buy_sol >= fnum(self.cfg.get('RUG_SCOUT_MIN_TOP_BUY_SOL'), 0.50) and
                not queen_active and danger_roles <= inum(self.cfg.get('RUG_SCOUT_MAX_DANGER_ROLES'), 0)
            )
            if ok:
                return True, 'rug_scout', 'rug_risk_over_base_but_clean_hive_flow'

        if self.cfg.get('HIVE_STATE_SCOUT_ENABLED', True):
            ok = (
                score >= fnum(self.cfg.get('HIVE_STATE_SCOUT_MIN_SCORE'), 450.0) and
                f.get('last_side') == 'buy' and f.get('last_event_fresh') and
                f.get('recent_buys', 0) >= inum(self.cfg.get('HIVE_STATE_SCOUT_MIN_RECENT_BUYS'), 4) and
                f.get('recent_buyers', 0) >= inum(self.cfg.get('HIVE_STATE_SCOUT_MIN_RECENT_BUYERS'), 4) and
                fnum(hive.get('net_hive_sol'), 0.0) >= fnum(self.cfg.get('HIVE_STATE_SCOUT_MIN_NET_HIVE_SOL'), 5.0) and
                sell_pressure <= fnum(self.cfg.get('HIVE_STATE_SCOUT_MAX_SELL_PRESSURE'), 0.25) and
                ratio <= fnum(self.cfg.get('HIVE_STATE_SCOUT_MAX_SELL_BUY_RATIO'), 0.35) and
                not queen_active and danger_roles <= inum(self.cfg.get('HIVE_STATE_SCOUT_MAX_DANGER_ROLES'), 0)
            )
            if ok:
                return True, 'hive_state_scout', 'hive_state_block_overridden_by_strong_clean_hive'

        return False, '', 'no_scout_condition'


    def _creator_cluster_signal(self, f: Dict[str, Any]) -> tuple[bool, float, List[str], Dict[str, Any]]:
        """Cached creator/controller cluster entry signal.

        This is deliberately sync-only and does not make RPC calls. creator_tracker.py
        updates the cache in background tasks from live_feed/new-token events.
        """
        if not self.cfg.get('CREATOR_CLUSTER_TRACKING_ENABLED', True):
            return False, 0.0, [], {}
        try:
            tracker = self.creator_tracker or get_global_creator_tracker()
            if not tracker:
                return False, 0.0, [], {}
            mint = f.get('mint') or ''
            cluster = tracker.get_creator_cluster(mint)
            if not cluster:
                return False, 0.0, [], {}
            max_age = fnum(self.cfg.get('CREATOR_CLUSTER_MAX_BUY_AGE_SEC'), 12.0)
            if fnum(f.get('age'), 999999.0) > max_age:
                return False, 0.0, [], {'cluster_size': len(cluster), 'too_old': True}
            events = f.get('live_wallet_events') or []
            buy_events = [e for e in events if str(e.get('side') or e.get('txType') or '').lower() == 'buy']
            first3 = buy_events[:3]
            first3_wallets = [str(e.get('wallet') or e.get('traderPublicKey') or '') for e in first3]
            overlap = [w for w in first3_wallets if w and w in cluster]
            creator = tracker.get_creator_for_mint(mint) if hasattr(tracker, 'get_creator_for_mint') else ''
            creator_self_buy = bool(creator and any(w == creator for w in first3_wallets))
            if not overlap and not creator_self_buy:
                return False, 0.0, [], {'cluster_size': len(cluster), 'first3_wallets': first3_wallets, 'creator': creator}
            bonus = fnum(self.cfg.get('CREATOR_CLUSTER_INSIDER_BONUS'), 120.0)
            tags = ['creator_cluster_insider_buy']
            if creator_self_buy:
                bonus += fnum(self.cfg.get('CREATOR_SELF_BUY_BONUS'), 80.0)
                tags.append('creator_self_buy')
            details = {
                'cluster_size': len(cluster),
                'cluster_overlap_first3': overlap,
                'creator': creator,
                'creator_self_buy': creator_self_buy,
                'first3_wallets': first3_wallets,
            }
            return True, bonus, tags, details
        except Exception as e:
            try:
                append_jsonl('creator_tracker_warnings.jsonl', {'ts': now_ts(), 'where': 'strategy_creator_cluster_signal', 'mint': f.get('mint'), 'error': str(e)[:400]})
            except Exception:
                pass
            return False, 0.0, [], {}

    def decide(self, row: Dict[str, Any]) -> Dict[str, Any]:
        f = self._base_features(row)
        ws = self._wallet_summary(f)
        queen_sig = self._queen_signature(f, ws)
        hive = self._hive_state(f)
        significant = self.wallet_intel.is_significant_mint(f['mint'], f['mc'])
        wallet_score = self._wallet_alpha_score(ws)
        flow_score = self._flow_score(f)
        pattern_score = self._pattern_edge_score(f['pattern'])
        risk_penalty = self._risk_penalty(f)
        hive_bonus = self._hive_entry_bonus(hive)

        # v11.2.36: priority wallet bonuses — data-mined high-win-rate wallets get a score lift.
        priority_wallet_bonus = 0.0
        last_wallet = f.get('last_event_wallet') or ''
        live_wallets = set(f.get('live_event_wallets') or [])
        # Copy-buy edge: last buyer is a priority wallet → strong entry signal
        if last_wallet in getattr(self, 'vetted_copy_set', set()):
            priority_wallet_bonus += fnum(self.cfg.get('PRIORITY_COPY_BUY_SCORE_BONUS'), 65.0)
            reason_prefix_tags = ['vetted_priority_copy_buy_wallet_trigger']
        else:
            reason_prefix_tags = []
        # Any priority copy wallet in the live window → moderate bonus
        copy_present = [w for w in live_wallets if w in getattr(self, 'vetted_copy_set', set())]
        if copy_present:
            priority_wallet_bonus += fnum(self.cfg.get('PRIORITY_COPY_PRESENT_BONUS'), 20.0) * min(len(copy_present), 3)
            reason_prefix_tags.append(f'priority_copy_wallets_in_window_{len(copy_present)}')
        # Worker accumulator in hive worker list → strong swarm confirmation
        hive_workers = set(hive.get('worker_wallets') or []) if hive else set()
        priority_workers_present = [w for w in hive_workers if w in self._priority_worker_set]
        if priority_workers_present:
            priority_wallet_bonus += fnum(self.cfg.get('PRIORITY_WORKER_SCORE_BONUS'), 45.0) * min(len(priority_workers_present), 2)
            reason_prefix_tags.append(f'priority_worker_accumulators_{len(priority_workers_present)}')

        score = f['quality_score'] * 0.25 + f['breakout_score'] * 0.28 + wallet_score + flow_score + pattern_score + hive_bonus + priority_wallet_bonus - risk_penalty
        f['wallet_score'] = round(wallet_score, 4)
        f['flow_score'] = round(flow_score, 4)
        f['risk_penalty'] = round(risk_penalty, 4)
        pre_armed = bool(row.get('pre_armed') or f.get('pre_armed'))
        pre_arm_override = fnum(row.get('pre_arm_score_override') or f.get('pre_arm_score_override'), fnum(self.cfg.get('PRE_ARM_SCORE_OVERRIDE'), 180.0))
        if pre_armed:
            score = max(score, pre_arm_override)
            reason_prefix_tags.append('pre_armed_controller_cluster')
            reason_prefix_tags.append(f'pre_arm_controller={row.get("pre_arm_controller") or f.get("pre_arm_controller") or ""}')
        creator_cluster_ok, creator_cluster_bonus, creator_cluster_tags, creator_cluster_details = self._creator_cluster_signal(f)
        if creator_cluster_ok:
            score += creator_cluster_bonus
            reason_prefix_tags.extend(creator_cluster_tags)
            try:
                append_jsonl('creator_cluster_entry_candidates.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'score_bonus': creator_cluster_bonus, 'details': creator_cluster_details, 'features': f})
            except Exception:
                pass
        follow_money_ok, follow_money_reason, follow_money_details = self._follow_money_creation_signal(f, hive, score)
        if follow_money_ok:
            score += fnum(self.cfg.get('FOLLOW_MONEY_CREATION_BONUS'), 90.0)
            reason_prefix_tags.append('follow_money_creation_signal')
            try:
                append_jsonl('follow_money_creation_candidates.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'ok': True, 'details': follow_money_details, 'score': score, 'features': f})
            except Exception:
                pass
        early_creation_ok, early_creation_reason, early_creation_details = self._early_creation_snipe_signal(f, hive, score)
        if early_creation_ok:
            score += fnum(self.cfg.get('EARLY_CREATION_SNIPE_BONUS'), 70.0)
            reason_prefix_tags.append('early_creation_snipe_signal')
            try:
                append_jsonl('early_creation_snipe_candidates.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'ok': True, 'details': early_creation_details, 'score': score, 'features': f})
            except Exception:
                pass
        reason: List[str] = reason_prefix_tags
        if hive:
            reason.append(f"hive={hive.get('hive_state')}")
            if hive.get('worker_buys') or hive.get('worker_buy_sol'):
                reason.append(f"worker_buys={hive.get('worker_buys',0)}_sol={fnum(hive.get('worker_buy_sol'),0.0):.3f}")
            if hive.get('queen_sells') or hive.get('queen_sell_sol'):
                reason.append(f"queen_sells={hive.get('queen_sells',0)}_sol={fnum(hive.get('queen_sell_sol'),0.0):.3f}")
            # v11.2.18: log watch_surge and winning counter
            if hive.get('watch_surge_ok'):
                reason.append(f"watch_surge_sol={fnum(hive.get('watch_buy_sol'),0.0):.3f}")
            if hive.get('winning_counter_score', 0.0) > 0:
                reason.append(f"winning_counter={hive.get('winning_counter_score',0.0):.1f}")
            if hive.get('soft_worker_buys', 0):
                reason.append(f"soft_workers={hive.get('soft_worker_buys',0)}_sol={fnum(hive.get('soft_worker_sol'),0.0):.3f}")
            if hive.get('queen_pre_exit_warning'):
                reason.append('queen_pre_exit_WARNING')
        if significant:
            score += 10.0
            reason.append('top_trader_significant')
        if ws.accumulator_count or ws.alpha_count:
            reason.append(f'accumulators={ws.accumulator_count}_alpha={ws.alpha_count}')
        if ws.top_net_buy_sol > 0:
            reason.append(f'top_net_buy_sol={ws.top_net_buy_sol:.3f}')
        if f['last_side']:
            reason.append(f'last_side={f["last_side"]}')
            reason.append(f'last_buy_sol={f.get("last_event_sol",0.0):.4f}')
            reason.append(f'event_age={f.get("last_event_age_sec",999):.1f}s')
            reason.append(f'last_role={queen_sig.get("last_wallet_role")}')

        qdr_ok, qdr_reason, qdr_details = self._queen_dump_recovery_signal(f, ws, queen_sig, hive, score)
        pressure_runner_ok, pressure_runner_reason, pressure_runner_details = self._pressure_runner_lift_signal(f, ws, queen_sig, hive, score)
        qcycle_ok, qcycle_reason, qcycle_details = self._queen_cycle_ride_signal(f, ws, queen_sig, hive, score)
        swarm_edge_ok, swarm_edge_reason, swarm_edge_details = self._swarm_edge_auto_signal(f, ws, queen_sig, hive, score)
        if swarm_edge_ok:
            reason.append(swarm_edge_reason)
            reason.append(f"swarm_edge_wallet={swarm_edge_details.get('wallet','')}")
            try:
                append_jsonl('swarm_edge_auto_candidates.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'ok': True, 'details': swarm_edge_details, 'score': score, 'features': f, 'wallet_summary': ws.to_dict(), 'hive_state': hive})
            except Exception:
                pass
        if qcycle_ok:
            reason.append(qcycle_reason)
            reason.append(f"qcycle_net={fnum(qcycle_details.get('queen_cycle_net_sol'),0.0):.3f}")
            try:
                append_jsonl('queen_cycle_ride_candidates.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'ok': True, 'details': qcycle_details, 'score': score, 'features': f, 'wallet_summary': ws.to_dict(), 'hive_state': hive})
            except Exception:
                pass
        if qdr_ok:
            reason.append(qdr_reason)
            reason.append(f"qdr_buys={qdr_details.get('fresh_buys_after_dump',0)}_sol={fnum(qdr_details.get('buy_sol_after_dump'),0.0):.3f}")
            try:
                append_jsonl('queen_dump_recovery_candidates.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'ok': True, 'details': qdr_details, 'score': score, 'features': f, 'wallet_summary': ws.to_dict(), 'hive_state': hive})
            except Exception:
                pass
        if pressure_runner_ok:
            reason.append(pressure_runner_reason)
            try:
                append_jsonl('pressure_runner_lift_candidates.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'ok': True, 'details': pressure_runner_details, 'score': score, 'features': f, 'wallet_summary': ws.to_dict(), 'hive_state': hive})
            except Exception:
                pass

        scout_ok, scout_setup, scout_reason = self._scout_pre_hard_allow(f, ws, queen_sig, hive, score)
        scout_allowed_hard_prefixes = (
            'not_new_incoming_buy', 'rug_risk_', 'sell_pressure_', 'sell_buy_ratio_',
            'queen_worker_graph_hive_flip_entry_block', 'queen_worker_graph_late_queen_entry_block',
            'queen_pre_exit_warning_no_worker_cover',
            'live_guard_sell_pressure_', 'live_guard_sell_buy_ratio_'
        )
        qdr_allowed_hard_prefixes = (
            'not_new_incoming_buy', 'rug_risk_', 'sell_pressure_', 'sell_buy_ratio_',
            'dump_risk_wallets_', 'sell_only_wallets_', 'danger_wallets_',
            'queen_worker_graph_queen_exit_shadow_entry_block', 'queen_worker_graph_hive_flip_entry_block',
            'queen_worker_graph_late_queen_entry_block', 'queen_pre_exit_warning_no_worker_cover',
            'queen_guard', 'live_guard_'
        )
        qcycle_allowed_hard_prefixes = (
            'dump_risk_wallets_', 'sell_only_wallets_', 'danger_wallets_',
            'queen_guard_last_buyer_role_', 'queen_guard_danger_', 'queen_guard_top_sell_buy_sol_ratio_',
            'live_guard_', 'sell_pressure_', 'sell_buy_ratio_'
        )
        swarm_edge_allowed_hard_prefixes = (
            'queen_guard_last_buyer_role_', 'queen_guard_top_sell_buy_sol_ratio_',
            'queen_worker_graph_queen_exit_shadow_entry_block', 'queen_worker_graph_hive_flip_entry_block',
            'live_guard_sell_pressure_', 'live_guard_sell_buy_ratio_', 'sell_pressure_', 'sell_buy_ratio_'
        )
        pressure_runner_allowed_hard_prefixes = (
            'not_new_incoming_buy', 'rug_risk_', 'sell_pressure_', 'sell_buy_ratio_',
            'dump_risk_wallets_', 'danger_wallets_',
            'queen_worker_graph_queen_exit_shadow_entry_block',
            'live_guard_sell_pressure_', 'live_guard_sell_buy_ratio_', 'live_guard_recent_sells_',
            'live_guard_top_buy_sol_', 'live_guard_top_net_buy_sol_'
        )

        hard = self._hard_reject(f, ws)
        pre_arm_skipped_blockers: List[str] = []
        if pre_armed and self.cfg.get('PRE_ARM_SKIP_SOFT_BLOCKERS', True) and hard and str(hard) not in ('no_mint',):
            pre_arm_skipped_blockers.append(str(hard))
            reason.append(f'pre_arm_skipped_soft_blocker={hard}')
            hard = ''
        if hard and ((creator_cluster_ok and str(hard).startswith(scout_allowed_hard_prefixes)) or (scout_ok and str(hard).startswith(scout_allowed_hard_prefixes)) or (qdr_ok and str(hard).startswith(qdr_allowed_hard_prefixes)) or (qcycle_ok and str(hard).startswith(qcycle_allowed_hard_prefixes)) or (swarm_edge_ok and self.cfg.get('SWARM_EDGE_ALLOW_MINED_BYPASS', True) and str(hard).startswith(swarm_edge_allowed_hard_prefixes)) or (pressure_runner_ok and str(hard).startswith(pressure_runner_allowed_hard_prefixes))):
            reason.append(f"{'pressure_runner' if pressure_runner_ok else ('swarm_edge' if swarm_edge_ok else ('qcycle' if qcycle_ok else ('qdr' if qdr_ok else 'scout')))}_bypass={hard}")
            hard = ''
        if not hard:
            hive_hard = self._hive_entry_reject(hive)
            if pre_armed and self.cfg.get('PRE_ARM_SKIP_SOFT_BLOCKERS', True) and hive_hard:
                pre_arm_skipped_blockers.append(str(hive_hard))
                reason.append(f'pre_arm_skipped_soft_blocker={hive_hard}')
                hive_hard = ''
            if hive_hard and ((creator_cluster_ok and str(hive_hard).startswith(scout_allowed_hard_prefixes)) or (scout_ok and str(hive_hard).startswith(scout_allowed_hard_prefixes)) or (qdr_ok and str(hive_hard).startswith(qdr_allowed_hard_prefixes)) or (qcycle_ok and str(hive_hard).startswith(qcycle_allowed_hard_prefixes)) or (swarm_edge_ok and self.cfg.get('SWARM_EDGE_ALLOW_MINED_BYPASS', True) and str(hive_hard).startswith(swarm_edge_allowed_hard_prefixes)) or (pressure_runner_ok and str(hive_hard).startswith(pressure_runner_allowed_hard_prefixes))):
                reason.append(f"{'pressure_runner' if pressure_runner_ok else ('swarm_edge' if swarm_edge_ok else ('qcycle' if qcycle_ok else ('qdr' if qdr_ok else 'scout')))}_bypass={hive_hard}")
                hive_hard = ''
            hard = hive_hard
        if not hard:
            queen_hard = self._queen_guard_reject(f, ws, queen_sig)
            if pre_armed and self.cfg.get('PRE_ARM_SKIP_SOFT_BLOCKERS', True) and queen_hard:
                pre_arm_skipped_blockers.append(str(queen_hard))
                reason.append(f'pre_arm_skipped_soft_blocker={queen_hard}')
                queen_hard = ''
            if queen_hard and ((creator_cluster_ok and str(queen_hard).startswith(qdr_allowed_hard_prefixes)) or (qdr_ok and str(queen_hard).startswith(qdr_allowed_hard_prefixes)) or (qcycle_ok and str(queen_hard).startswith(qcycle_allowed_hard_prefixes)) or (swarm_edge_ok and self.cfg.get('SWARM_EDGE_ALLOW_MINED_BYPASS', True) and str(queen_hard).startswith(swarm_edge_allowed_hard_prefixes)) or (pressure_runner_ok and str(queen_hard).startswith(pressure_runner_allowed_hard_prefixes))):
                reason.append(f"{'pressure_runner' if pressure_runner_ok else ('swarm_edge' if swarm_edge_ok else ('qcycle' if qcycle_ok else 'qdr'))}_bypass={queen_hard}")
                queen_hard = ''
            hard = queen_hard
        if not hard:
            live_hard = self._live_safety_reject(f, ws, queen_sig)
            if pre_armed and self.cfg.get('PRE_ARM_SKIP_SOFT_BLOCKERS', True) and live_hard:
                pre_arm_skipped_blockers.append(str(live_hard))
                reason.append(f'pre_arm_skipped_soft_blocker={live_hard}')
                live_hard = ''
            if live_hard and ((creator_cluster_ok and str(live_hard).startswith(scout_allowed_hard_prefixes)) or (scout_ok and str(live_hard).startswith(scout_allowed_hard_prefixes)) or (qdr_ok and str(live_hard).startswith(qdr_allowed_hard_prefixes)) or (qcycle_ok and str(live_hard).startswith(qcycle_allowed_hard_prefixes)) or (swarm_edge_ok and self.cfg.get('SWARM_EDGE_ALLOW_MINED_BYPASS', True) and str(live_hard).startswith(swarm_edge_allowed_hard_prefixes)) or (pressure_runner_ok and str(live_hard).startswith(pressure_runner_allowed_hard_prefixes))):
                reason.append(f"{'pressure_runner' if pressure_runner_ok else ('swarm_edge' if swarm_edge_ok else ('qcycle' if qcycle_ok else ('qdr' if qdr_ok else 'scout')))}_bypass={live_hard}")
                live_hard = ''
            hard = live_hard
        if hard:
            if str(hard).startswith('queen_guard'):
                append_jsonl('ignored_queen_bait.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'reason': hard, 'wallet_summary': ws.to_dict(), 'queen_signature': queen_sig, 'features': f})
            if str(hard).startswith('live_guard'):
                append_jsonl('ignored_live_guard_entries.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'reason': hard, 'wallet_summary': ws.to_dict(), 'queen_signature': queen_sig, 'features': f, 'score': score})
            return {**f, 'approved': False, 'score': round(score, 2), 'setup': 'none', 'reason': hard, 'buy_sol': 0.0, 'wallet_summary': ws.to_dict(), 'queen_signature': queen_sig, 'hive_state': hive, 'significant': significant}

        setup = ''
        # v11.2.36 pressure-runner focus patch:
        # pressure_runner_lift is now preferred over queen-worker/front-run and
        # swarm edge when it is present because the current SIM data showed it
        # had the best clean PnL.
        forced_scout_setup = 'pre_armed_controller_cluster' if pre_armed else ('pressure_runner_lift' if pressure_runner_ok else ('swarm_edge_auto_ride' if swarm_edge_ok else ('early_creation_snipe' if early_creation_ok else ('follow_money_creation_snipe' if follow_money_ok else ('creator_cluster_insider_snipe' if creator_cluster_ok else ('queen_cycle_ride' if qcycle_ok else ('queen_dump_recovery_scout' if qdr_ok else (scout_setup if scout_ok else ''))))))))
        min_score = fnum(self.cfg.get('MIN_ENTRY_SCORE'), 60.0)
        tracked_power = ws.accumulator_count + ws.alpha_count
        buy_delta = f['recent_buys'] - f['recent_sells']
        clean_flow = f['sell_pressure'] <= fnum(self.cfg.get('CLEAN_FLOW_MAX_SELL_PRESSURE'), 0.42) and f['total_sell_buy_ratio'] <= fnum(self.cfg.get('CLEAN_FLOW_MAX_SELL_BUY_RATIO'), 1.35)
        has_tracked_buy = bool(
            f.get('live_wallet_events') and f['last_side'] == 'buy' and f.get('last_event_fresh') and
            f.get('last_event_sol', 0.0) >= fnum(self.cfg.get('MIN_LAST_BUY_SOL'), 0.01) and
            f.get('buy_sol_recent', 0.0) >= fnum(self.cfg.get('MIN_RECENT_BUY_SOL'), 0.015) and
            (tracked_power >= 1 or (ws.top_net_buy_sol >= fnum(self.cfg.get('LIVE_WALLET_FLOW_MIN_NET_BUY_SOL'), 0.06) and ws.associated_wallet_count >= inum(self.cfg.get('SWARM_QUORUM_MIN_BUYERS'), 4) and queen_sig.get('sell_buy_sol_ratio', 9) <= fnum(self.cfg.get('SWARM_QUORUM_MAX_SELL_BUY_SOL_RATIO'), 0.25)))
        )

        # Lane QW: copy the queen's worker bees early, before queen/dump wallets start selling.
        pnl_filter_ok, pnl_filter_reason = self._pnl_filtered_hive_entry_ok(f, hive, score)
        mined_worker_confirmed = (
            tracked_power >= inum(self.cfg.get('HIVE_MIN_MINED_WORKERS_FOR_ENTRY'), 1) or
            inum(hive.get('worker_buys_true'), 0) >= inum(self.cfg.get('HIVE_MIN_TRUE_WORKER_BUYS_FOR_ENTRY'), 1)
        )
        if self.cfg.get('HIVE_REQUIRE_MINED_WORKER_FOR_FRONT_RUN', False) and not mined_worker_confirmed:
            pnl_filter_ok = False
            pnl_filter_reason = 'pnl_filter_no_mined_worker_confirmed'

        vetted_copy_ok, vetted_copy_reason, vetted_copy_details = self._vetted_copy_entry_signal(f, ws, hive, score)
        if vetted_copy_ok:
            setup = 'priority_copy_wallet_buy'
            reason.append(vetted_copy_reason)
            reason.append('vetted_wallet=' + str(vetted_copy_details.get('wallet','')))
            if self.cfg.get('VETTED_COPY_LOG_CANDIDATES', True):
                append_jsonl('vetted_copy_wallet_candidates.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'ok': True, 'details': vetted_copy_details, 'score': score, 'features': f, 'wallet_summary': ws.to_dict(), 'hive_state': hive})

        elif forced_scout_setup:
            setup = forced_scout_setup
            if pre_armed:
                reason.append('pre_armed_controller_cluster_lane')
                reason.append('pre_arm_soft_blockers_skipped_' + str(len(pre_arm_skipped_blockers)))
            elif early_creation_ok:
                reason.append(early_creation_reason)
                reason.append('early_creation_wallet=' + str(early_creation_details.get('wallet','')))
            elif follow_money_ok:
                reason.append(follow_money_reason)
                reason.append('follow_money_hits=' + ','.join(follow_money_details.get('entry_hits', [])[:4]))
            elif creator_cluster_ok:
                reason.append('creator_cluster_insider_lane_pnl_filter_bypass')
            elif qcycle_ok:
                reason.append('queen_cycle_ride_before_dump_lane')
            elif qdr_ok:
                reason.append('queen_dump_recovery_lane')
            elif pressure_runner_ok:
                reason.append('pressure_runner_lift_lane')
            else:
                reason.append(scout_reason)
                reason.append('tiny_scout_lane_from_blocker_replay')

        elif (
            self.cfg.get('QUEEN_WORKER_FRONT_RUN_ENABLED', False) and
            self.cfg.get('QUEEN_WORKER_GRAPH_ENABLED', True) and has_tracked_buy and hive.get('worker_entry_ok') and
            score >= fnum(self.cfg.get('QUEEN_WORKER_FRONT_RUN_MIN_SCORE'), 450.0) and
            f.get('last_event_sol', 0.0) >= fnum(self.cfg.get('QUEEN_WORKER_FRONT_RUN_MIN_LAST_BUY_SOL'), 0.0) and
            clean_flow and pnl_filter_ok
        ):
            setup = 'queen_worker_front_run'
            reason.append('queen_worker_front_run_worker_buy_before_queen_exit')
            reason.append('pnl_filter_pass')

        # Lane WS: multiple worker/watch wallets accelerate together with no queen sell pressure.
        elif (
            self.cfg.get('WORKER_SWARM_ACCELERATION_ENABLED', True) and self.cfg.get('HIVE_ALLOW_NOISY_WORKER_SWARM', False) and has_tracked_buy and hive.get('worker_swarm_ok') and
            score >= fnum(self.cfg.get('WORKER_SWARM_ACCELERATION_MIN_SCORE'), 70.0) and
            clean_flow
        ):
            setup = 'worker_swarm_acceleration'
            reason.append('worker_swarm_acceleration_clean_hive_flow')

        # Lane WS2: watch_surge — high watch-wallet SOL accumulation before any queen sell.
        # v11.2.18: this is the primary winning counter signal from historical data.
        elif (
            self.cfg.get('WATCH_SURGE_LANE_ENABLED', True) and has_tracked_buy and hive.get('watch_surge_ok') and
            not hive.get('queen_exit_now') and not hive.get('is_late_queen_entry') and
            score >= fnum(self.cfg.get('WATCH_SURGE_MIN_SCORE'), 75.0) and
            fnum(hive.get('net_hive_sol'), 0.0) >= fnum(self.cfg.get('WATCH_SURGE_MIN_NET_HIVE_SOL'), 1.0) and
            clean_flow
        ):
            setup = 'watch_surge_counter'
            reason.append('watch_surge_clean_hive_no_queen_sell')

        # Lane A: freshest tracked wallet buy, fastest copy entry.
        elif (
            self.cfg.get('LIVE_TRACKED_WALLET_BUY_ENABLED', False) and has_tracked_buy and tracked_power >= 1 and
            score >= max(fnum(self.cfg.get('LIVE_WALLET_FLOW_MIN_SCORE'), 42.0), fnum(self.cfg.get('LIVE_TRACKED_WALLET_BUY_MIN_SCORE'), 105.0)) and
            ws.top_net_buy_sol >= fnum(self.cfg.get('LIVE_TRACKED_WALLET_BUY_MIN_TOP_NET_BUY_SOL'), 0.50) and
            f['sell_pressure'] <= fnum(self.cfg.get('LIVE_TRACKED_WALLET_BUY_MAX_SELL_PRESSURE'), 0.12) and
            f['total_sell_buy_ratio'] <= fnum(self.cfg.get('LIVE_TRACKED_WALLET_BUY_MAX_SELL_BUY_RATIO'), 0.25) and
            f['recent_sells'] <= inum(self.cfg.get('LIVE_TRACKED_WALLET_BUY_MAX_RECENT_SELLS'), 1) and
            f['recent_buys'] >= inum(self.cfg.get('LIVE_WALLET_FLOW_MIN_RECENT_BUYS'), 1) and
            clean_flow
        ):
            setup = 'live_tracked_wallet_buy'
            reason.append('fresh_tracked_wallet_buy_flow_strict')


        # Lane A2: Queen Hunter swarm quorum. This follows a clean worker swarm, not a single queen bait wallet.
        elif (
            self.cfg.get('QUEEN_ALLOW_SWARM_QUORUM', True) and has_tracked_buy and tracked_power == 0 and
            ws.associated_wallet_count >= inum(self.cfg.get('SWARM_QUORUM_MIN_BUYERS'), 4) and
            f['recent_buys'] >= inum(self.cfg.get('SWARM_QUORUM_MIN_RECENT_BUYS'), 4) and
            ws.top_net_buy_sol >= fnum(self.cfg.get('SWARM_QUORUM_MIN_NET_BUY_SOL'), 0.75) and
            queen_sig.get('sell_buy_sol_ratio', 9) <= fnum(self.cfg.get('SWARM_QUORUM_MAX_SELL_BUY_SOL_RATIO'), 0.25) and
            (not self._live_safety_enabled() or (
                ws.associated_wallet_count >= inum(self.cfg.get('LIVE_SWARM_MIN_BUYERS'), 5) and
                ws.sell_near_high_count <= (0 if self.cfg.get('LIVE_SWARM_REQUIRE_NO_SELL_NEAR_HIGH', True) else 99) and
                (self.cfg.get('LIVE_IGNORE_MC_LIMITS', True) or f.get('mc',0.0) <= fnum(self.cfg.get('LIVE_SWARM_MAX_MC'), 75.0)) and
                f.get('last_event_sol',0.0) >= fnum(self.cfg.get('LIVE_SWARM_MIN_LAST_BUY_SOL'), 0.10) and
                ws.top_net_buy_sol >= fnum(self.cfg.get('LIVE_SWARM_MIN_NET_BUY_SOL'), 1.5) and
                queen_sig.get('sell_buy_sol_ratio', 9) <= fnum(self.cfg.get('LIVE_SWARM_MAX_SELL_BUY_SOL_RATIO'), 0.12)
            )) and
            score >= fnum(self.cfg.get('SWARM_QUORUM_MIN_SCORE'), 85.0) and clean_flow and
            (not self.cfg.get('HIVE_PNL_FILTER_SWARM_QUORUM', True) or pnl_filter_ok)
        ):
            setup = 'queen_hunter_swarm_quorum'
            reason.append('queen_hunter_clean_worker_swarm')
            if self.cfg.get('HIVE_PNL_FILTER_SWARM_QUORUM', True):
                reason.append('pnl_filter_pass')

        # Lane B: top wallets cluster into a new mint with volume acceleration.
        elif (
            self.cfg.get('ENABLE_VOLUME_SPIKE_LANE', False) and significant and tracked_power >= 1 and
            score >= fnum(self.cfg.get('VOLUME_SPIKE_MIN_SCORE'), 60.0) and
            f['recent_buys'] >= inum(self.cfg.get('VOLUME_SPIKE_MIN_RECENT_BUYS'), 2) and
            buy_delta >= inum(self.cfg.get('VOLUME_SPIKE_MIN_BUY_SELL_DELTA'), 1) and
            f['sell_pressure'] <= fnum(self.cfg.get('VOLUME_SPIKE_MAX_SELL_PRESSURE'), 0.45)
        ):
            setup = 'top_trader_volume_spike'
            reason.append('top_wallet_volume_spike')

        # Lane C: bot-noise Achilles heel - only buy the rebound when known wallets absorb it.
        elif (
            self.cfg.get('ENABLE_REBOUND_SCALP_LANE', False) and f['pattern'] in set(self.cfg.get('REBOUND_PATTERNS') or list(BOT_NOISE_PATTERNS)) and
            (tracked_power >= 1 or ws.top_net_buy_sol >= fnum(self.cfg.get('REBOUND_MIN_NET_BUY_SOL'), 0.15)) and
            score >= fnum(self.cfg.get('REBOUND_MIN_SCORE'), 52.0) and
            f['rug_risk'] <= fnum(self.cfg.get('REBOUND_MAX_RUG_RISK'), 58.0) and
            f['sell_pressure'] <= fnum(self.cfg.get('REBOUND_MAX_SELL_PRESSURE'), 0.48) and
            (f['recent_buys'] >= 1 or ws.top_net_buy_sol > 0) and
            f['above_open_pct'] >= fnum(self.cfg.get('REBOUND_MIN_ABOVE_OPEN_PCT'), -0.25)
        ):
            setup = 'top_trader_rebound_scalp'
            reason.append('bot_noise_absorption_rebound')

        # Lane D: slower accumulator copy, less dependent on recent burst.
        elif (
            self.cfg.get('ENABLE_WALLET_PREDATOR_ACCUMULATION', False) and
            significant and score >= fnum(self.cfg.get('WALLET_PREDATOR_ACCUMULATION_MIN_SCORE'), max(min_score, 95.0)) and
            (tracked_power >= inum(self.cfg.get('MIN_ACCUMULATOR_COUNT'), 1) or ws.top_net_buy_sol >= fnum(self.cfg.get('MIN_ALPHA_BUY_SOL'), 0.20)) and
            ws.top_net_buy_sol >= fnum(self.cfg.get('WALLET_PREDATOR_ACCUMULATION_MIN_NET_BUY_SOL'), 0.75) and
            f['sell_pressure'] <= fnum(self.cfg.get('WALLET_PREDATOR_ACCUMULATION_MAX_SELL_PRESSURE'), 0.18) and
            f['total_sell_buy_ratio'] <= fnum(self.cfg.get('WALLET_PREDATOR_ACCUMULATION_MAX_SELL_BUY_RATIO'), 0.30) and
            f['recent_buys'] >= inum(self.cfg.get('MIN_RECENT_BUYS'), 1) and
            f['recent_buyers'] >= inum(self.cfg.get('MIN_RECENT_BUYERS'), 1)
        ):
            setup = 'wallet_predator_accumulation'
            reason.append('top_holder_accumulation_strict_enabled')

        # Lane E: tiny copy probe for a new tracked wallet buy when data is thin.
        elif (
            self.cfg.get('ENABLE_COPY_WALLET_PROBE', False) and
            significant and score >= fnum(self.cfg.get('COPY_PROBE_MIN_SCORE'), 70.0) and
            (tracked_power >= 1 or ws.top_net_buy_sol >= fnum(self.cfg.get('COPY_PROBE_MIN_NET_BUY_SOL'), 0.25)) and
            clean_flow
        ):
            setup = 'copy_wallet_probe'
            reason.append('thin_flow_copy_probe_strict_enabled')


        # AI risk manager: AI can score/rank/block winning-vs-dead patterns, but it
        # cannot invent trades unless AI_CAN_ENTER_TRADES is explicitly enabled.
        ai_pre = self._hive_ai_lookup(f, setup or 'none')
        ai_grade = self._local_ai_pattern_grade(f, ws, hive, setup or 'none', ai_pre)
        ai_entry_score = fnum(ai_grade.get('entry_score'), 0.5)
        ai_danger_score = fnum(ai_grade.get('danger_score'), 0.0)
        ai_runner_score = fnum(ai_grade.get('runner_score'), 0.5)
        if self.cfg.get('HIVE_AI_ENABLED', True):
            reason.append(f"ai_grade={ai_grade.get('grade')}_entry={ai_entry_score:.2f}_danger={ai_danger_score:.2f}_src={ai_pre.get('source')}")
            try:
                append_jsonl('hive_ai_trade_grades.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'setup': setup or 'none', 'grade': ai_grade.get('grade'), 'entry_score': ai_entry_score, 'danger_score': ai_danger_score, 'runner_score': ai_runner_score, 'flags': ai_grade.get('flags'), 'sidecar': ai_pre, 'features': f, 'wallet_summary': ws.to_dict(), 'hive_state': hive})
            except Exception:
                pass
            allowed_setups = self._cfg_csv_set('HIVE_AI_ALLOWED_SETUPS', 'pressure_runner_lift,swarm_edge_auto_ride,top_trader_volume_spike')
            blocked_setups = self._cfg_csv_set('HIVE_AI_BLOCKED_SETUPS', 'queen_worker_front_run,queen_cycle_ride,queen_dump_recovery_scout,wallet_predator_accumulation,worker_swarm_acceleration,ai_swarm_edge_override,copy_wallet_probe,watch_surge_counter')
            if setup and self.cfg.get('AI_CAN_BLOCK_TRADES', True):
                block_reason = ''
                if setup in blocked_setups:
                    block_reason = f'ai_blocked_bad_setup_{setup}'
                elif self.cfg.get('HIVE_AI_REQUIRE_ALLOWED_SETUP', True) and setup not in allowed_setups:
                    block_reason = f'ai_setup_not_allowed_{setup}'
                elif self.cfg.get('HIVE_AI_REQUIRE_AB_GRADE', True) and str(ai_grade.get('grade')) not in set(str(self.cfg.get('HIVE_AI_ALLOWED_GRADES','A,B')).split(',')):
                    block_reason = f"ai_grade_{ai_grade.get('grade')}_not_allowed"
                elif ai_danger_score >= fnum(self.cfg.get('HIVE_AI_DANGER_SCORE_BLOCK'), 0.45):
                    block_reason = 'ai_danger_block'
                elif ai_entry_score < fnum(self.cfg.get('HIVE_AI_ENTRY_SCORE_ALLOW'), 0.68):
                    block_reason = 'ai_entry_score_low'
                if block_reason:
                    append_jsonl('hive_ai_blocks.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'setup': setup, 'ai': ai_grade, 'sidecar': ai_pre, 'features': f, 'reason': block_reason})
                    setup = ''
                    reason.append(block_reason)
            elif (not setup) and self.cfg.get('AI_CAN_ENTER_TRADES', False) and self.cfg.get('HIVE_AI_ALLOW_SOFT_OVERRIDE', False):
                # Disabled by default. Kept as an emergency experiment switch only.
                if (
                    ai_entry_score >= fnum(self.cfg.get('HIVE_AI_ENTRY_SCORE_ALLOW'), 0.68) and
                    ai_danger_score <= fnum(self.cfg.get('HIVE_AI_MAX_DANGER_FOR_OVERRIDE'), 0.30) and
                    f.get('last_side') == 'buy' and f.get('last_event_fresh') and
                    f.get('sell_pressure', 1.0) <= fnum(self.cfg.get('HIVE_AI_OVERRIDE_MAX_SELL_PRESSURE'), 0.38) and
                    f.get('total_sell_buy_ratio', 99.0) <= fnum(self.cfg.get('HIVE_AI_OVERRIDE_MAX_SELL_BUY_RATIO'), 0.65) and
                    f.get('recent_buys', 0) >= inum(self.cfg.get('HIVE_AI_OVERRIDE_MIN_RECENT_BUYS'), 12)
                ):
                    setup = 'ai_swarm_edge_override'
                    reason.append('ai_soft_override_after_safety_pass')
                    append_jsonl('hive_ai_override_candidates.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'setup': setup, 'ai': ai_grade, 'features': f, 'wallet_summary': ws.to_dict(), 'hive_state': hive})

        if setup and self.cfg.get('STRICT_EDGE_MODE', False):
            strict_reason = self._strict_edge_reject(f, ws, setup, score)
            if strict_reason:
                append_jsonl('strict_edge_blocks.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'setup': setup, 'reason': strict_reason, 'score': round(score, 2), 'features': f, 'wallet_summary': ws.to_dict(), 'hive_state': hive})
                reason.append(strict_reason)
                setup = ''

        approved = bool(setup)
        if pre_armed:
            try:
                append_jsonl('pre_arm_decisions.jsonl', {'ts': now_ts(), 'mint': f.get('mint'), 'approved': approved, 'setup': setup or 'none', 'score': round(score, 2), 'reason': '|'.join(reason), 'skipped_blockers': pre_arm_skipped_blockers, 'row': row})
            except Exception:
                pass
        if not approved:
            if 'pnl_filter_reason' in locals() and pnl_filter_reason:
                reason.append(pnl_filter_reason)
            reason.append(f'no_lane_score_{score:.1f}')
        size_mult = self._setup_size_mult(setup) if approved else 0.0
        min_buy = fnum(self.cfg.get('MIN_BUY_SOL'), 0.005)
        # Copy/scout probes can go below normal min only if explicitly configured, unless fixed sizing is forced.
        if setup == 'copy_wallet_probe' and not self.cfg.get('FORCE_FIXED_BUY_SIZE', False):
            min_buy = fnum(self.cfg.get('COPY_PROBE_MIN_BUY_SOL'), min_buy)
        # v11.2.30+: universal sizing. Every approved setup uses BUY_SOL only.
        # Do not downsize queen/scout/AI lanes behind the user's back.
        risk_tier = ''
        if approved:
            risk_tier, fixed_sol = self._live_size_tier(setup, f, ws, queen_sig, score)
            buy_sol = fixed_sol
            reason.append(f'universal_buy_sol_{fixed_sol:.3f}')
            if risk_tier:
                reason.append(f'live_risk_tier_{risk_tier}')
        else:
            buy_sol = 0.0
        return {
            **f,
            'approved': approved,
            'score': round(score, 2),
            'setup': setup or 'none',
            'reason': '|'.join(reason),
            'buy_sol': buy_sol,
            'wallet_summary': ws.to_dict(),
            'queen_signature': queen_sig,
            'hive_state': hive,
            'significant': significant,
            'wallet_score': round(wallet_score, 2),
            'flow_score': round(flow_score, 2),
            'risk_penalty': round(risk_penalty, 2),
            'live_risk_tier': risk_tier,
            'hive_ai_entry_score': round(ai_entry_score if 'ai_entry_score' in locals() else 0.5, 4),
            'hive_ai_danger_score': round(ai_danger_score if 'ai_danger_score' in locals() else 0.0, 4),
            'hive_ai_runner_score': round(ai_runner_score if 'ai_runner_score' in locals() else 0.5, 4),
            'creator_cluster_signal': creator_cluster_details if 'creator_cluster_details' in locals() else {}, 'follow_money_signal': follow_money_details if 'follow_money_details' in locals() else {},
            'pre_armed': pre_armed,
            'pre_arm_cluster_id': row.get('pre_arm_cluster_id') or f.get('pre_arm_cluster_id'),
            'pre_arm_controller': row.get('pre_arm_controller') or f.get('pre_arm_controller'),
            'pre_arm_seconds_notice': row.get('pre_arm_seconds_notice') or f.get('pre_arm_seconds_notice'),
            'pre_arm_skipped_blockers': pre_arm_skipped_blockers if 'pre_arm_skipped_blockers' in locals() else [],
        }

    def apply_loss_cooldown(self, mint: str, setup: str, seconds: float | None = None) -> None:
        self.cooldowns[mint] = now_ts() + (seconds or fnum(self.cfg.get('SAME_MINT_COOLDOWN_SEC'), 90.0))

    def record_mint_loss(self, mint: str, pnl_sol: float) -> None:
        """v11.2.36: record a net-negative close so _hard_reject can block re-entry for 5min."""
        if pnl_sol < 0:
            self.recent_mint_losses[mint] = now_ts()
            append_jsonl('mint_loss_blocks.jsonl', {'ts': now_ts(), 'mint': mint, 'pnl_sol': pnl_sol, 'block_until': now_ts() + fnum(self.cfg.get('SAME_MINT_LOSS_BLOCK_SEC'), 300.0)})
