from __future__ import annotations
import json, time
from pathlib import Path

PATH = Path('buy_sell_only.jsonl')

def short(x: str, n: int = 6) -> str:
    return x if not x or len(x) <= n*2 else f'{x[:n]}...{x[-n:]}'

print('Watching clean buy/sell tape:', PATH.resolve())
pos = 0
while True:
    if not PATH.exists():
        time.sleep(1); continue
    with PATH.open('r', encoding='utf-8', errors='ignore') as f:
        f.seek(pos)
        for line in f:
            pos = f.tell()
            try:
                e = json.loads(line)
            except Exception:
                continue
            print(f"{e.get('side','').upper():4} mint={short(str(e.get('mint','')),7)} wallet={short(str(e.get('wallet','')),6)} sol={float(e.get('sol') or 0):.6f} mc={float(e.get('mc') or 0):.2f} sig={short(str(e.get('sig','')),6)}")
    time.sleep(0.5)
