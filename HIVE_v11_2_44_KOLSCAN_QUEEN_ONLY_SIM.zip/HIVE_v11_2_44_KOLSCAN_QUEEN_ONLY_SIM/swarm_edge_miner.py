from __future__ import annotations
"""
SWARM EDGE MINER
Builds a compact wallet/signal profile from the files the bot already creates.
Output: swarm_edge_profiles.json

This is intentionally deterministic and cheap enough to run after a session. It
looks for wallets that are useful in one of three ways:
  1) copy_buy_wallets: their BUYs tend to have enough forward upside after fees
  2) exit_warning_wallets: their SELLs tend to precede drawdown / failed runners
  3) cycle_wallets: they buy, dump, and rebuy; only copy them when fresh crowd
     flow confirms the cycle instead of blindly copying every print.
"""
import csv, json, math, statistics
from collections import defaultdict, Counter
from pathlib import Path
from typing import Any, Dict, List, Tuple

from util import fnum, inum, iter_jsonl, save_json, now_ts

DEFAULT_OUT = 'swarm_edge_profiles.json'


def _event_sol(e: Dict[str, Any]) -> float:
    return fnum(e.get('sol') if e.get('sol') is not None else e.get('solAmount'), 0.0)


def load_events(path: str = 'live_wallet_events.jsonl') -> Dict[str, List[Dict[str, Any]]]:
    by_mint: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    p = Path(path)
    if not p.exists():
        return {}
    for e in iter_jsonl(p):
        mint = e.get('mint') or ''
        wallet = e.get('wallet') or e.get('traderPublicKey') or ''
        side = str(e.get('side') or e.get('txType') or '').lower()
        if not mint or not wallet or side not in ('buy','sell'):
            continue
        mc = fnum(e.get('mc') if e.get('mc') is not None else e.get('marketCapSol'), 0.0)
        ts = inum(e.get('ts') if e.get('ts') is not None else e.get('raw_ts'), 0)
        if ts <= 0 or mc <= 0:
            continue
        by_mint[mint].append({'ts': ts, 'side': side, 'wallet': wallet, 'sol': _event_sol(e), 'mc': mc})
    for mint in list(by_mint):
        by_mint[mint].sort(key=lambda x: (x['ts'], 0 if x['side']=='sell' else 1))
    return by_mint


def load_trade_pnl(path: str = 'wallet_predator_trades.csv') -> Dict[str, Dict[str, float]]:
    # Used only as context in report; live wallet events are used for generalization.
    out: Dict[str, Dict[str, float]] = defaultdict(lambda: {'sells':0,'pnl':0.0})
    p = Path(path)
    if not p.exists():
        return {}
    with p.open('r', encoding='utf-8', errors='ignore', newline='') as f:
        for r in csv.DictReader(f):
            if str(r.get('side','')).upper().endswith('SELL'):
                setup = r.get('setup') or 'unknown'
                out[setup]['sells'] += 1
                out[setup]['pnl'] += fnum(r.get('pnl_sol'), 0.0)
    return dict(out)


def local_context(events: List[Dict[str, Any]], idx: int, sec: float = 5.0) -> Dict[str, Any]:
    e = events[idx]
    start = e['ts'] - sec
    buy_sol = 0.0
    sell_sol = 0.0
    buys = 0
    sells = 0
    buyers = set()
    # Events are sorted. Walk backward only through the recent window.
    j = idx
    while j >= 0:
        x = events[j]
        if x['ts'] < start:
            break
        if x['side'] == 'buy':
            buys += 1
            buy_sol += x['sol']
            buyers.add(x['wallet'])
        elif x['side'] == 'sell':
            sells += 1
            sell_sol += x['sol']
        j -= 1
    return {
        'buy_sol_5s': buy_sol,
        'sell_sol_5s': sell_sol,
        'unique_buyers_5s': len(buyers),
        'buys_5s': buys,
        'sells_5s': sells,
        'token_age_sec': max(0, e['ts'] - events[0]['ts']),
    }


def future_path(events: List[Dict[str, Any]], idx: int, horizon: float) -> List[Dict[str, Any]]:
    ts0 = events[idx]['ts']
    out: List[Dict[str, Any]] = []
    # Events are sorted by timestamp. Stop once the look-ahead horizon is passed;
    # this keeps SIM mining fast even with hundreds of thousands of WSS rows.
    for x in events[idx+1:]:
        dt = x['ts'] - ts0
        if dt <= 0:
            continue
        if dt > horizon:
            break
        if x['mc'] > 0:
            out.append(x)
    return out


def first_touch_return(entry_mc: float, fut: List[Dict[str, Any]], tp: float = 0.12, sl: float = 0.15, horizon_ret: bool = True) -> Tuple[float, str, float, float]:
    if entry_mc <= 0 or not fut:
        return 0.0, 'no_future', 0.0, 0.0
    max_up = max((x['mc'] / entry_mc - 1.0) for x in fut)
    max_dd = min((x['mc'] / entry_mc - 1.0) for x in fut)
    for x in fut:
        r = x['mc'] / entry_mc - 1.0
        if r >= tp:
            return tp, 'tp', max_up, max_dd
        if r <= -sl:
            return -sl, 'sl', max_up, max_dd
    last = fut[-1]['mc'] / entry_mc - 1.0 if horizon_ret else 0.0
    return last, 'horizon', max_up, max_dd


def _median(values: List[float], default: float = 0.0) -> float:
    vals = [float(v) for v in values if v is not None]
    if not vals:
        return default
    try:
        return float(statistics.median(vals))
    except Exception:
        return default


def build_recent_copy_calls(events_by_mint: Dict[str, List[Dict[str, Any]]], profiles: Dict[str, Any], cfg: Dict[str, Any] | None = None) -> List[Dict[str, Any]]:
    """Return fresh wallet buys that SIM says are worth copying/watching.

    Anchor recency to the newest event in the file instead of wall-clock time.
    This keeps replay/SIM data useful even when raw event timestamps are shifted or
    collected on another machine. These are not live orders by themselves; the live
    strategy still re-checks current tape, sell pressure, and final safety.
    """
    cfg = cfg or {}
    window = fnum(cfg.get('RECENT_COPY_CALL_WINDOW_SEC'), 900.0)
    max_calls = inum(cfg.get('RECENT_COPY_CALL_MAX_ROWS'), 80)
    min_edge = fnum(cfg.get('RECENT_COPY_CALL_MIN_EDGE_PCT'), fnum(cfg.get('SWARM_EDGE_MIN_PROFILE_FEE_EDGE_PCT'), 0.015))
    min_wr = fnum(cfg.get('RECENT_COPY_CALL_MIN_WIN_RATE'), fnum(cfg.get('SWARM_EDGE_MIN_PROFILE_WIN_RATE'), 0.50))
    min_samples = inum(cfg.get('RECENT_COPY_CALL_MIN_SAMPLES'), max(1, inum(cfg.get('SWARM_EDGE_MIN_PROFILE_SAMPLES'), 1)))

    prof_by_wallet = {str(w.get('wallet') or ''): w for w in profiles.get('copy_buy_wallets') or [] if isinstance(w, dict) and w.get('wallet')}
    exit_wallets = {str(w.get('wallet') or '') for w in profiles.get('exit_warning_wallets') or [] if isinstance(w, dict) and w.get('wallet')}
    if not prof_by_wallet:
        return []

    anchor = 0
    for evs in events_by_mint.values():
        for e in evs:
            anchor = max(anchor, inum(e.get('ts'), 0))
    if anchor <= 0:
        return []

    calls: List[Dict[str, Any]] = []
    for mint, evs in events_by_mint.items():
        if not evs:
            continue
        first_ts = inum(evs[0].get('ts'), 0)
        for i, e in enumerate(evs):
            if e.get('side') != 'buy':
                continue
            ts = inum(e.get('ts'), 0)
            if anchor - ts > window:
                continue
            wallet = str(e.get('wallet') or '')
            prof = prof_by_wallet.get(wallet)
            if not prof:
                continue
            edge = fnum(prof.get('fee_adjusted_edge_pct'), 0.0)
            wr = fnum(prof.get('win_rate'), 0.0)
            samples = inum(prof.get('samples'), 0)
            if edge < min_edge or wr < min_wr or samples < min_samples:
                continue
            ctx = local_context(evs, i, 5.0)
            recent_sells = [x for x in evs[max(0, i-30):i+1] if x.get('side') == 'sell' and ts - inum(x.get('ts'), 0) <= 5.0]
            exit_warn_sells = [x for x in recent_sells if str(x.get('wallet') or '') in exit_wallets]
            pctx = prof.get('context') or {}
            context_ok = (
                ctx.get('buy_sol_5s', 0.0) >= fnum(pctx.get('min_buy_sol_5s'), fnum(cfg.get('SWARM_EDGE_MIN_BUY_SOL_5S'), 0.0))
                and ctx.get('sell_sol_5s', 0.0) <= fnum(pctx.get('max_sell_sol_5s'), fnum(cfg.get('SWARM_EDGE_MAX_SELL_SOL_5S'), 999.0))
                and ctx.get('unique_buyers_5s', 0) >= inum(pctx.get('min_unique_buyers_5s'), inum(cfg.get('SWARM_EDGE_MIN_UNIQUE_BUYERS_5S'), 1))
                and len(exit_warn_sells) <= inum(cfg.get('SWARM_EDGE_MAX_EXIT_WARNING_SELLS_5S'), 999)
            )
            call_score = (wr * 100.0) + (edge * 350.0) + min(35.0, samples * 1.5) + min(30.0, ctx.get('buy_sol_5s', 0.0) * 8.0) - (ctx.get('sell_sol_5s', 0.0) * 12.0)
            calls.append({
                'wallet': wallet,
                'mint': mint,
                'event_ts': ts,
                'age_from_latest_sec': max(0, anchor - ts),
                'token_age_sec': max(0, ts - first_ts),
                'side': 'buy',
                'sol': round(fnum(e.get('sol'), 0.0), 9),
                'mc': round(fnum(e.get('mc'), 0.0), 6),
                'profile_win_rate': round(wr, 6),
                'profile_fee_edge_pct': round(edge, 6),
                'profile_samples': samples,
                'profile_mints': inum(prof.get('mints'), 0),
                'tape_context': ctx,
                'profile_context': pctx,
                'exit_warning_sells_5s': len(exit_warn_sells),
                'context_ok': bool(context_ok),
                'call_score': round(call_score, 6),
                'call_type': 'COPY_NOW' if context_ok else 'WATCH_ONLY',
                'reason': 'recent_profiled_wallet_buy_context_passed' if context_ok else 'recent_profiled_wallet_buy_needs_tape_confirmation',
            })
    calls.sort(key=lambda x: (x.get('context_ok', False), x.get('call_score', 0.0), -x.get('age_from_latest_sec', 999999)), reverse=True)
    return calls[:max_calls]


def write_recent_copy_watch_file(profiles: Dict[str, Any], path: str = 'SIM_BEST_COPY_CALLS.json') -> None:
    """Persist the fresh SIM call list so it can be reviewed without dashboard."""
    save_json(path, {
        'ts': now_ts(),
        'source': 'swarm_edge_miner.recent_copy_call_candidates',
        'copy_now': [r for r in profiles.get('recent_copy_call_candidates', []) if r.get('call_type') == 'COPY_NOW'],
        'watch_only': [r for r in profiles.get('recent_copy_call_candidates', []) if r.get('call_type') != 'COPY_NOW'],
    })


def mine_swarm_edges(events_by_mint: Dict[str, List[Dict[str, Any]]], cfg: Dict[str, Any] | None = None) -> Dict[str, Any]:
    cfg = cfg or {}
    horizon = fnum(cfg.get('SWARM_EDGE_MINE_HORIZON_SEC'), 75.0)
    tp = fnum(cfg.get('SWARM_EDGE_MINE_TP_PCT'), 0.18)
    sl = fnum(cfg.get('SWARM_EDGE_MINE_SL_PCT'), 0.16)
    fee_drag = fnum(cfg.get('SWARM_EDGE_MIN_FEE_DRAG_PCT'), 0.08)  # round-trip pain seen in live wallet delta
    min_events = inum(cfg.get('SWARM_EDGE_MIN_WALLET_EVENTS'), 5)

    buy_stats: Dict[str, Dict[str, Any]] = defaultdict(lambda: {'n':0,'wins':0,'rets':[],'maxups':[],'maxdds':[],'mints':set(),'contexts':[],'first_ts':0,'last_ts':0,'recent_n':0})
    sell_stats: Dict[str, Dict[str, Any]] = defaultdict(lambda: {'n':0,'drops':0,'rets':[],'maxups':[],'maxdds':[],'mints':set(),'contexts':[],'first_ts':0,'last_ts':0,'recent_n':0})
    cycle_stats: Dict[str, Dict[str, Any]] = defaultdict(lambda: {'buy_count':0,'sell_count':0,'mints':set(),'buy_sol':0.0,'sell_sol':0.0,'first_ts':0,'last_ts':0,'recent_buy_count':0})

    max_ts = 0
    for _evs in events_by_mint.values():
        for _e in _evs:
            max_ts = max(max_ts, inum(_e.get('ts'), 0))
    recent_window = fnum(cfg.get('RECENT_WALLET_SCORE_WINDOW_SEC'), 1800.0)

    for mint, evs in events_by_mint.items():
        for i, e in enumerate(evs):
            wallet = e['wallet']
            ets = inum(e.get('ts'), 0)
            is_recent = bool(max_ts and ets >= max_ts - recent_window)
            ctx = local_context(evs, i, 5.0)
            fut = future_path(evs, i, horizon)
            ret, outcome, max_up, max_dd = first_touch_return(e['mc'], fut, tp=tp, sl=sl)
            if e['side'] == 'buy':
                st = buy_stats[wallet]
                st['n'] += 1; st['mints'].add(mint); st['rets'].append(ret); st['maxups'].append(max_up); st['maxdds'].append(max_dd); st['contexts'].append(ctx)
                st['first_ts'] = ets if not st.get('first_ts') else min(inum(st.get('first_ts'), ets), ets)
                st['last_ts'] = max(inum(st.get('last_ts'), 0), ets)
                if is_recent: st['recent_n'] += 1
                if (ret - fee_drag) > 0:
                    st['wins'] += 1
                cy = cycle_stats[wallet]; cy['buy_count'] += 1; cy['mints'].add(mint); cy['buy_sol'] += e['sol']; cy['first_ts'] = ets if not cy.get('first_ts') else min(inum(cy.get('first_ts'), ets), ets); cy['last_ts'] = max(inum(cy.get('last_ts'), 0), ets); cy['recent_buy_count'] += 1 if is_recent else 0
            else:
                # SELL is useful if it tends to precede weak future return / drawdown.
                st = sell_stats[wallet]
                st['n'] += 1; st['mints'].add(mint); st['rets'].append(ret); st['maxups'].append(max_up); st['maxdds'].append(max_dd); st['contexts'].append(ctx)
                st['first_ts'] = ets if not st.get('first_ts') else min(inum(st.get('first_ts'), ets), ets)
                st['last_ts'] = max(inum(st.get('last_ts'), 0), ets)
                if is_recent: st['recent_n'] += 1
                if max_dd <= -0.10 or ret <= -0.08:
                    st['drops'] += 1
                cy = cycle_stats[wallet]; cy['sell_count'] += 1; cy['mints'].add(mint); cy['sell_sol'] += e['sol']; cy['first_ts'] = ets if not cy.get('first_ts') else min(inum(cy.get('first_ts'), ets), ets); cy['last_ts'] = max(inum(cy.get('last_ts'), 0), ets)

    def summarize_context(contexts: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not contexts:
            return {}
        def med(k, default=0.0):
            vals = [fnum(c.get(k), default) for c in contexts]
            try: return float(statistics.median(vals))
            except Exception: return default
        # Do not blindly use median; set thresholds just below the winning profile observed.
        return {
            'min_token_age_sec': max(5.0, min(20.0, med('token_age_sec') * 0.75)),
            'min_buy_sol_5s': max(0.25, med('buy_sol_5s') * 0.70),
            'max_sell_sol_5s': max(0.10, med('sell_sol_5s') * 1.35),
            'min_unique_buyers_5s': max(1, int(math.floor(med('unique_buyers_5s')))),
        }

    copy_wallets=[]
    for w, st in buy_stats.items():
        if st['n'] < min_events or len(st['mints']) < max(2, min_events//3):
            continue
        avg = sum(st['rets'])/max(1,len(st['rets']))
        win_rate = st['wins']/max(1,st['n'])
        avg_up = sum(st['maxups'])/max(1,len(st['maxups']))
        # Must beat fee drag and show runner upside, not just tiny wins.
        edge = avg - fee_drag
        if edge > fnum(cfg.get('SWARM_EDGE_MIN_NET_EDGE_PCT'), 0.015) and win_rate >= fnum(cfg.get('SWARM_EDGE_MIN_WIN_RATE'), 0.52) and avg_up >= fnum(cfg.get('SWARM_EDGE_MIN_AVG_MAX_UP_PCT'), 0.12):
            copy_wallets.append({
                'wallet': w, 'samples': st['n'], 'mints': len(st['mints']), 'win_rate': round(win_rate,4),
                'avg_first_touch_return_pct': round(avg,5), 'fee_adjusted_edge_pct': round(edge,5),
                'avg_max_up_pct': round(avg_up,5), 'avg_max_dd_pct': round(sum(st['maxdds'])/max(1,len(st['maxdds'])),5),
                'context': summarize_context(st['contexts']),
                'role': 'copy_buy_edge',
                'first_seen_ts': inum(st.get('first_ts'), 0),
                'last_seen_ts': inum(st.get('last_ts'), 0),
                'last_seen_age_sec': max(0, max_ts - inum(st.get('last_ts'), 0)) if max_ts else 0,
                'recent_buy_count': inum(st.get('recent_n'), 0),
                'recent_window_sec': recent_window,
            })
    copy_wallets.sort(key=lambda x: (x['fee_adjusted_edge_pct'], x['win_rate'], x['samples']), reverse=True)

    exit_wallets=[]
    for w, st in sell_stats.items():
        if st['n'] < max(2, min_events//2):
            continue
        drop_rate = st['drops']/max(1,st['n'])
        avg_dd = sum(st['maxdds'])/max(1,len(st['maxdds']))
        avg_ret = sum(st['rets'])/max(1,len(st['rets']))
        if drop_rate >= fnum(cfg.get('SWARM_EDGE_EXIT_MIN_DROP_RATE'), 0.55) or avg_dd <= -fnum(cfg.get('SWARM_EDGE_EXIT_MIN_AVG_DD_PCT'), 0.12):
            exit_wallets.append({
                'wallet': w, 'samples': st['n'], 'mints': len(st['mints']), 'drop_rate_after_sell': round(drop_rate,4),
                'avg_after_sell_return_pct': round(avg_ret,5), 'avg_after_sell_max_dd_pct': round(avg_dd,5),
                'avg_after_sell_max_up_pct': round(sum(st['maxups'])/max(1,len(st['maxups'])),5),
                'role': 'exit_warning',
                'first_seen_ts': inum(st.get('first_ts'), 0),
                'last_seen_ts': inum(st.get('last_ts'), 0),
                'last_seen_age_sec': max(0, max_ts - inum(st.get('last_ts'), 0)) if max_ts else 0,
                'recent_sell_count': inum(st.get('recent_n'), 0),
                'recent_window_sec': recent_window,
            })
    exit_wallets.sort(key=lambda x: (x['drop_rate_after_sell'], -x['avg_after_sell_return_pct'], x['samples']), reverse=True)

    cycle_wallets=[]
    for w, st in cycle_stats.items():
        mints=len(st['mints'])
        if mints < 2 or st['buy_count'] < 3 or st['sell_count'] < 2:
            continue
        total = st['buy_sol'] + st['sell_sol']
        if total <= 0: continue
        cycle_wallets.append({
            'wallet': w, 'mints': mints, 'buy_count': st['buy_count'], 'sell_count': st['sell_count'],
            'buy_sol': round(st['buy_sol'],6), 'sell_sol': round(st['sell_sol'],6), 'net_sol': round(st['buy_sol']-st['sell_sol'],6),
            'role': 'cycle_wallet',
            'first_seen_ts': inum(st.get('first_ts'), 0),
            'last_seen_ts': inum(st.get('last_ts'), 0),
            'last_seen_age_sec': max(0, max_ts - inum(st.get('last_ts'), 0)) if max_ts else 0,
            'recent_buy_count': inum(st.get('recent_buy_count'), 0),
            'recent_window_sec': recent_window,
        })
    cycle_wallets.sort(key=lambda x: (x['mints'], x['buy_sol']+x['sell_sol']), reverse=True)

    out = {
        'created_ts': now_ts(),
        'inputs': {'mints': len(events_by_mint), 'horizon_sec': horizon, 'tp_pct': tp, 'sl_pct': sl, 'fee_drag_pct': fee_drag, 'newest_event_ts': max_ts, 'recent_wallet_score_window_sec': recent_window},
        'copy_buy_wallets': copy_wallets[:100],
        'exit_warning_wallets': exit_wallets[:150],
        'cycle_wallets': cycle_wallets[:100],
        'strategy_notes': [
            'Do not copy a wallet blindly. Require its mined context thresholds and current tape confirmation.',
            'Exit-warning wallets are not always instant exits; they tighten trail and prevent new entries unless worker refill confirms.',
            'Cycle wallets are only copied when the latest event is a fresh buy, same-wallet net buy is positive, and 5s crowd flow confirms.'
        ]
    }
    out['recent_copy_call_candidates'] = build_recent_copy_calls(events_by_mint, out, cfg)
    return out


def main() -> None:
    cfg = {}
    if Path('config.json').exists():
        try: cfg = json.loads(Path('config.json').read_text(encoding='utf-8'))
        except Exception: cfg = {}
    events = load_events(cfg.get('LIVE_WALLET_EVENTS_FILE','live_wallet_events.jsonl'))
    profiles = mine_swarm_edges(events, cfg)
    # Add realized setup PnL context for dashboards/reports.
    profiles['trade_setup_pnl'] = load_trade_pnl(cfg.get('TRADES_FILE','wallet_predator_trades.csv'))
    save_json(cfg.get('SWARM_EDGE_PROFILE_FILE', DEFAULT_OUT), profiles)
    write_recent_copy_watch_file(profiles, cfg.get('RECENT_COPY_CALL_FILE', 'SIM_BEST_COPY_CALLS.json'))
    try:
        from live_money_flow_ranker import write_hot_sim_plays
        hot = write_hot_sim_plays(cfg)
        profiles['hot_sim_play_summary'] = hot.get('summary', {})
    except Exception as e:
        try:
            Path('hot_sim_play_errors.jsonl').open('a', encoding='utf-8').write(json.dumps({'ts': now_ts(), 'where': 'swarm_edge_miner_main_hot_sim', 'error': str(e)}) + '\n')
        except Exception:
            pass
    try:
        from dashboard_server import profitable_wallets_text
        Path('MOST_PROFITABLE_WALLETS.txt').write_text(profitable_wallets_text(100), encoding='utf-8')
    except Exception as e:
        Path('profitable_wallet_export_errors.jsonl').open('a', encoding='utf-8').write(json.dumps({'ts': now_ts(), 'where': 'swarm_edge_miner_main_export', 'error': str(e)}) + '\n')
    print(f"SWARM_EDGE_MINER wrote {cfg.get('SWARM_EDGE_PROFILE_FILE', DEFAULT_OUT)} copy={len(profiles['copy_buy_wallets'])} exit={len(profiles['exit_warning_wallets'])} cycle={len(profiles['cycle_wallets'])} calls={len(profiles.get('recent_copy_call_candidates', []))}")


if __name__ == '__main__':
    main()
