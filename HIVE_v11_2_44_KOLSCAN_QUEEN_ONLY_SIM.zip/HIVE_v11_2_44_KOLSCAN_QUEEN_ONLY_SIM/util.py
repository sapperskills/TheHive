from __future__ import annotations
import json, time, os, csv, zipfile, shutil
from pathlib import Path
from typing import Any, Dict, Iterable

BOT_BUILD = 'v11.2.40-follow-money-graph-runtime-guard'
PROCESS_START_TS = int(time.time())
SOURCE_FOLDER = str(Path(__file__).resolve().parent)


def now_ts() -> int:
    return int(time.time())


def load_json(path: str | Path, default: Any = None) -> Any:
    try:
        p = Path(path)
        if p.exists():
            return json.loads(p.read_text(encoding='utf-8'))
    except Exception:
        pass
    return default


def save_json(path: str | Path, obj: Any) -> None:
    """Best-effort JSON writer for live loops.

    Windows can raise PermissionError when a dashboard, editor, antivirus, or
    a second bot process briefly touches the target file. Runtime intel writes
    must never crash trading/WSS. This writer retries atomic replace with a
    unique tmp file, then falls back to direct write, then to a .fallback file.
    """
    p = Path(path)
    data = json.dumps(obj, indent=2, sort_keys=True)
    p.parent.mkdir(parents=True, exist_ok=True)
    last_err = None
    # Use unique tmp names so two processes do not fight over ucf_upgrade_intel.json.tmp.
    for i in range(8):
        tmp = p.with_name(f"{p.name}.{os.getpid()}.{int(time.time()*1000)}.{i}.tmp")
        try:
            tmp.write_text(data, encoding='utf-8')
            os.replace(str(tmp), str(p))
            return
        except PermissionError as e:
            last_err = e
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:
                pass
            time.sleep(0.075 * (i + 1))
        except Exception as e:
            last_err = e
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:
                pass
            time.sleep(0.025 * (i + 1))
    # Direct write fallback. If this also fails, do not crash the bot.
    try:
        p.write_text(data, encoding='utf-8')
        return
    except Exception as e:
        last_err = e
    try:
        fallback = p.with_name(f"{p.name}.fallback.{os.getpid()}.{int(time.time())}.json")
        fallback.write_text(data, encoding='utf-8')
    except Exception:
        pass
    try:
        print(f"SAFE_JSON_WRITE_WARN file={p} err={last_err}")
    except Exception:
        pass


def append_jsonl(path: str | Path, obj: Dict[str, Any]) -> None:
    with Path(path).open('a', encoding='utf-8') as f:
        f.write(json.dumps(obj, separators=(',', ':'), sort_keys=True) + '\n')


def iter_jsonl(path: str | Path) -> Iterable[Dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return
    with p.open('r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    yield obj
            except Exception:
                continue


def fnum(v: Any, default: float = 0.0) -> float:
    """Zero-safe float parse: 0.0 is never replaced by default."""
    if v is None:
        return default
    if isinstance(v, bool):
        return 1.0 if v else 0.0
    try:
        if isinstance(v, str) and v.strip() == '':
            return default
        return float(v)
    except Exception:
        return default


def inum(v: Any, default: int = 0) -> int:
    try:
        return int(fnum(v, default))
    except Exception:
        return default


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def short_mint(mint: str) -> str:
    return (mint or '')[:8]


def ensure_csv(path: str | Path, headers: list[str]) -> None:
    """Ensure a CSV exists with the exact schema expected by the current build.

    Older HIVE builds wrote a 7-column trade header, then later appended 11-column
    rows. That made DictReader map setup/mc/pnl into the wrong fields and caused
    dashboard/live-risk PnL to look profitable even when the wallet was losing
    after fees. If a schema mismatch is detected, archive the old file and start
    a clean one instead of silently corrupting future rows.
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    needs_header = (not p.exists()) or p.stat().st_size == 0
    if not needs_header:
        try:
            with p.open('r', newline='', encoding='utf-8', errors='ignore') as f:
                first = next(csv.reader(f), [])
            if list(first) != list(headers):
                stamp = int(time.time())
                archived = p.with_name(f"{p.stem}.schema_mismatch_{stamp}{p.suffix}")
                try:
                    os.replace(str(p), str(archived))
                    print(f"CSV_SCHEMA_MISMATCH_ARCHIVED file={p} archived={archived}")
                except Exception as e:
                    print(f"CSV_SCHEMA_MISMATCH_ARCHIVE_WARN file={p} err={e}")
                needs_header = True
        except StopIteration:
            needs_header = True
        except Exception:
            # If the header cannot be read, rotate rather than risk corrupt PnL.
            stamp = int(time.time())
            try:
                os.replace(str(p), str(p.with_name(f"{p.stem}.unreadable_{stamp}{p.suffix}")))
            except Exception:
                pass
            needs_header = True
    if needs_header:
        with p.open('w', newline='', encoding='utf-8') as f:
            csv.writer(f).writerow(headers)


def append_csv(path: str | Path, headers: list[str], row: Dict[str, Any]) -> None:
    ensure_csv(path, headers)
    with Path(path).open('a', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=headers, extrasaction='ignore')
        w.writerow(row)


def boot_proof(config_path: str = 'config.json') -> Dict[str, Any]:
    return {
        'bot_build': BOT_BUILD,
        'source_folder': SOURCE_FOLDER,
        'config_path': str(Path(config_path).resolve()),
        'process_start_ts': PROCESS_START_TS,
    }


def make_debug_bundle(config: Dict[str, Any]) -> str:
    data_dir = Path(config.get('DATA_DIR') or '.').resolve()
    out_dir = data_dir / (config.get('DEBUG_BUNDLE_DIR') or 'ucf_debug_bundle_latest')
    out_zip = data_dir / (config.get('DEBUG_BUNDLE_ZIP') or 'ucf_debug_bundle_latest.zip')
    if out_dir.exists():
        shutil.rmtree(out_dir, ignore_errors=True)
    out_dir.mkdir(parents=True, exist_ok=True)
    names = [
        'main.py','strategy.py','wallet_intel.py','executor.py','creator_tracker.py','funding_graph_builder.py','feed_latency_monitor.py','live_trader.py','live_feed.py','debug_bundle.py','util.py',
        'config.json','default_config.json','wallet_reputation.json','wallet_clusters.json',
        'top_traders_by_mint.json','creator_history.json','funding_graph.json','cluster_map.json','controller_watch_list.json','pending_token_watch.json','controller_alerts.jsonl','pre_arm_hits.jsonl','pre_arm_misses.jsonl','pre_arm_decisions.jsonl','feed_latency_log.jsonl','feed_alerts.jsonl','creator_wallet_map.jsonl','creator_cluster_exits.jsonl','creator_cluster_entry_candidates.jsonl','missed_runners.json','bot_pattern_memory.json','pattern_intel.json',
        'wallet_predator_decisions.jsonl','wallet_predator_trades.csv','wallet_predator_positions.json',
        'wallet_predator_profiles.json','live_wallet_events.jsonl','live_trades.jsonl','sim_market_brain.jsonl','sim_trades.csv','sim_state.json',
        'ucf_upgrade_intel.json','performance_intel.json','queen_hive_report.json','mint_cooldowns.json','live_risk_state.json','ignored_queen_bait.jsonl','ignored_live_guard_entries.jsonl','ignored_live_risk_blocks.jsonl','runtime_errors.jsonl','position_lifecycle.jsonl','mint_cooldown_events.jsonl'
    ]
    copied=[]
    for name in names:
        p = data_dir / name
        if not p.exists():
            p = Path(__file__).resolve().parent / name
        if p.exists() and p.is_file():
            dest = out_dir / name
            try:
                if p.stat().st_size < 25_000_000:
                    shutil.copy2(p, dest)
                    copied.append(name)
            except Exception:
                pass
    summary = {
        'bot_build': BOT_BUILD,
        'created_ts': now_ts(),
        'boot_proof': boot_proof(str(data_dir/'config.json')),
        'copied_files': copied,
        'purpose': 'self contained troubleshooting bundle for wallet-predator copy trader'
    }
    save_json(out_dir / 'PATCH_DEBUG_SUMMARY.json', summary)
    if out_zip.exists():
        out_zip.unlink()
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in out_dir.rglob('*'):
            if p.is_file():
                z.write(p, p.relative_to(out_dir.parent))
    return str(out_zip)
