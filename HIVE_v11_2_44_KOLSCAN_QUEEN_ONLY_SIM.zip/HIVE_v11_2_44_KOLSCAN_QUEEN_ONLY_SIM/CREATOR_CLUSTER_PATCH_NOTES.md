# THE HIVE v11.2.36 Creator Cluster Patch

Added production-ready creator/controller cluster tracking:

- `creator_tracker.py`: async Solana RPC creator extraction, controller funding graph, cached cluster lookup.
- `strategy.py`: creator cluster first-3-buyer bonus and creator self-buy bonus via `creator_cluster_insider_snipe` lane. This lane bypasses the HIVE PnL filter but still respects core hard safety gates.
- `executor.py`: hard full-exit when a creator/controller cluster wallet sells the active mint. Logs to `creator_cluster_exits.jsonl`.
- `wallet_intel.py`: `CreatorIntelligence` scorecard and top creator ranking.
- `dashboard_server.py`: `/api/creator_intel` plus a dashboard Creator Intel panel with copyable full addresses.
- `main.py`: schedules non-blocking creator tracking tasks on new token events.
- `config.json` and `default_config.json`: creator cluster config keys added.

RPC safety:
- All creator RPC calls are async, timeout-wrapped, semaphore-limited, and warning-logged.
- Strategy/executor use cached state only, so slow RPC cannot stall buy/sell decision loops.

Important files created at runtime:
- `creator_history.json`
- `funding_graph.json`
- `creator_wallet_map.jsonl`
- `creator_cluster_entry_candidates.jsonl`
- `creator_cluster_exits.jsonl`
- `creator_tracker_warnings.jsonl`
