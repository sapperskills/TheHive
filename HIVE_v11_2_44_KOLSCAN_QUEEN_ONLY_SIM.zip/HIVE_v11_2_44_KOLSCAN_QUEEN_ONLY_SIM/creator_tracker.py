from __future__ import annotations

"""Creator/controller cluster tracking for THE HIVE.

This module is designed to be safe inside the live WSS loop:
- all RPC work is async and semaphore/rate limited
- public entry points catch/log exceptions instead of raising
- strategy/executor reads use cached JSON/in-memory state only
"""

import asyncio
import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from util import append_jsonl, fnum, inum, load_json, now_ts, save_json

LAMPORTS_PER_SOL = 1_000_000_000

_GLOBAL_TRACKER: Optional["CreatorTracker"] = None


def set_global_creator_tracker(tracker: Optional["CreatorTracker"]) -> None:
    global _GLOBAL_TRACKER
    _GLOBAL_TRACKER = tracker


def get_global_creator_tracker() -> Optional["CreatorTracker"]:
    return _GLOBAL_TRACKER


def get_creator_cluster(mint: str) -> Set[str]:
    """Compatibility helper used by sync strategy/executor code."""
    try:
        if _GLOBAL_TRACKER:
            return _GLOBAL_TRACKER.get_creator_cluster(mint)
    except Exception:
        pass
    return set()


class CreatorTracker:
    def __init__(self, cfg: Dict[str, Any]):
        self.cfg = cfg
        self.data_dir = Path(cfg.get("DATA_DIR") or ".")
        self.rpc_url = str(cfg.get("RPC_URL") or "").strip()
        self.history_file = self.data_dir / str(cfg.get("CREATOR_HISTORY_FILE", "creator_history.json"))
        self.graph_file = self.data_dir / str(cfg.get("CREATOR_FUNDING_GRAPH_FILE", "funding_graph.json"))
        self.map_file = self.data_dir / str(cfg.get("CREATOR_WALLET_MAP_FILE", "creator_wallet_map.jsonl"))
        self.warning_file = self.data_dir / str(cfg.get("CREATOR_TRACKER_WARN_FILE", "creator_tracker_warnings.jsonl"))
        self._sem = asyncio.Semaphore(max(1, inum(cfg.get("CREATOR_RPC_CONCURRENCY"), 2)))
        self._last_rpc_ts = 0.0
        self._tasks: Set[asyncio.Task] = set()
        self._seen_mints: Set[str] = set()
        self.history: Dict[str, Any] = load_json(self.history_file, {"creators": {}, "mints": {}}) or {"creators": {}, "mints": {}}
        self.graph: Dict[str, Any] = load_json(self.graph_file, {"creators": {}, "controllers": {}, "mints": {}}) or {"creators": {}, "controllers": {}, "mints": {}}
        set_global_creator_tracker(self)

    def _warn(self, where: str, err: Any, extra: Dict[str, Any] | None = None) -> None:
        try:
            append_jsonl(self.warning_file, {"ts": now_ts(), "where": where, "error": str(err)[:500], **(extra or {})})
        except Exception:
            pass

    async def _rate_limit(self) -> None:
        min_gap = fnum(self.cfg.get("CREATOR_RPC_MIN_GAP_SEC"), 0.18)
        if min_gap <= 0:
            return
        delta = time.time() - self._last_rpc_ts
        if delta < min_gap:
            await asyncio.sleep(min_gap - delta)
        self._last_rpc_ts = time.time()

    async def _rpc_call(self, method: str, params: List[Any]) -> Dict[str, Any]:
        if not self.rpc_url:
            raise RuntimeError("RPC_URL not configured")
        import aiohttp
        timeout = fnum(self.cfg.get("CREATOR_RPC_TIMEOUT_SEC"), 3.5)
        payload = {"jsonrpc": "2.0", "id": int(time.time() * 1000) % 1000000, "method": method, "params": params}
        async with self._sem:
            await self._rate_limit()
            async with aiohttp.ClientSession() as session:
                async with session.post(self.rpc_url, json=payload, timeout=timeout) as resp:
                    text = await resp.text()
                    if resp.status >= 300:
                        raise RuntimeError(f"RPC {method} HTTP {resp.status}: {text[:350]}")
                    try:
                        obj = json.loads(text)
                    except Exception:
                        raise RuntimeError(f"RPC {method} non-json response: {text[:350]}")
        if obj.get("error"):
            raise RuntimeError(f"RPC {method} error: {obj.get('error')}")
        return obj

    def schedule_new_token_event(self, ev: Dict[str, Any]) -> None:
        if not self.cfg.get("CREATOR_CLUSTER_TRACKING_ENABLED", True):
            return
        try:
            mint = str(ev.get("mint") or ev.get("token") or ev.get("ca") or ev.get("address") or "").strip()
            if not mint or mint in self._seen_mints:
                return
            self._seen_mints.add(mint)
            task = asyncio.create_task(self.observe_new_token_event(ev))
            self._tasks.add(task)
            task.add_done_callback(lambda t: self._tasks.discard(t))
        except RuntimeError:
            # No running loop; safe to ignore in sync sims.
            return
        except Exception as e:
            self._warn("schedule_new_token_event", e)

    async def observe_new_token_event(self, ev: Dict[str, Any]) -> None:
        try:
            await asyncio.wait_for(self._observe_new_token_event(ev), timeout=fnum(self.cfg.get("CREATOR_OBSERVE_TIMEOUT_SEC"), 9.0))
        except asyncio.TimeoutError:
            self._warn("observe_new_token_event_timeout", "timeout", {"mint": ev.get("mint")})
        except Exception as e:
            self._warn("observe_new_token_event", e, {"mint": ev.get("mint")})

    async def _observe_new_token_event(self, ev: Dict[str, Any]) -> None:
        mint = str(ev.get("mint") or ev.get("token") or ev.get("ca") or ev.get("address") or "").strip()
        if not mint:
            return
        sig = str(ev.get("signature") or ev.get("sig") or ev.get("txSignature") or ev.get("transactionSignature") or "").strip()
        if not sig and self.cfg.get("CREATOR_FIND_MINT_SIGNATURE_IF_MISSING", True):
            sig = await self._find_mint_signature(mint)
        if not sig:
            self._warn("missing_mint_signature", "no signature on new token event", {"mint": mint})
            return
        tx = await self._get_transaction(sig)
        creator = self._extract_fee_payer(tx)
        if not creator:
            self._warn("missing_creator", "could not extract signer[0]/fee payer", {"mint": mint, "sig": sig})
            return
        ts = now_ts()
        self.graph.setdefault("mints", {})[mint] = {"creator": creator, "ts": ts, "sig": sig}
        append_jsonl(self.map_file, {"ts": ts, "mint": mint, "creator_wallet": creator, "signature": sig})
        self._record_creator_token(creator, mint, ts, sig)
        prior = max(0, len((self.history.get("creators", {}).get(creator, {}) or {}).get("tokens", [])) - 1)
        if prior >= inum(self.cfg.get("CREATOR_MIN_PRIOR_TOKENS"), 2):
            controller, fsig, sol = await self._find_controller_wallet(creator)
            if controller:
                self._record_controller(creator, controller, ts, fsig, sol)
        self._save_state()

    async def _find_mint_signature(self, mint: str) -> str:
        try:
            limit = max(1, min(10, inum(self.cfg.get("CREATOR_MINT_SIG_LOOKUP_LIMIT"), 4)))
            obj = await self._rpc_call("getSignaturesForAddress", [mint, {"limit": limit, "commitment": str(self.cfg.get("COMMITMENT", "processed"))}])
            vals = ((obj.get("result") or []) if isinstance(obj, dict) else [])
            if vals:
                return str(vals[-1].get("signature") or vals[0].get("signature") or "")
        except Exception as e:
            self._warn("find_mint_signature", e, {"mint": mint})
        return ""

    async def _get_transaction(self, sig: str) -> Dict[str, Any]:
        params = [sig, {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 0, "commitment": str(self.cfg.get("COMMITMENT", "processed"))}]
        obj = await self._rpc_call("getTransaction", params)
        res = obj.get("result") or {}
        return res if isinstance(res, dict) else {}

    def _account_keys(self, tx: Dict[str, Any]) -> List[Any]:
        return ((((tx.get("transaction") or {}).get("message") or {}).get("accountKeys")) or [])

    def _key_to_str(self, k: Any) -> str:
        if isinstance(k, str):
            return k
        if isinstance(k, dict):
            return str(k.get("pubkey") or "")
        return ""

    def _extract_fee_payer(self, tx: Dict[str, Any]) -> str:
        keys = self._account_keys(tx)
        signer0 = ""
        for k in keys:
            if isinstance(k, dict) and k.get("signer"):
                signer0 = self._key_to_str(k)
                break
        if signer0:
            return signer0
        return self._key_to_str(keys[0]) if keys else ""

    async def _find_controller_wallet(self, creator: str) -> Tuple[str, str, float]:
        try:
            limit = max(5, min(50, inum(self.cfg.get("CREATOR_CONTROLLER_SIGNATURE_LIMIT"), 20)))
            min_sol = fnum(self.cfg.get("CREATOR_CONTROLLER_MIN_INBOUND_SOL"), 0.35)
            obj = await self._rpc_call("getSignaturesForAddress", [creator, {"limit": limit, "commitment": str(self.cfg.get("COMMITMENT", "processed"))}])
            sigs = obj.get("result") or []
            for row in sigs:
                sig = str((row or {}).get("signature") or "")
                if not sig:
                    continue
                try:
                    tx = await self._get_transaction(sig)
                    sender, sol = self._extract_inbound_sol_sender(tx, creator)
                    if sender and sol >= min_sol and sender != creator:
                        return sender, sig, sol
                except Exception as e:
                    self._warn("controller_tx_scan", e, {"creator": creator, "sig": sig})
                    continue
        except Exception as e:
            self._warn("find_controller_wallet", e, {"creator": creator})
        return "", "", 0.0

    def _extract_inbound_sol_sender(self, tx: Dict[str, Any], recipient: str) -> Tuple[str, float]:
        keys = [self._key_to_str(k) for k in self._account_keys(tx)]
        meta = tx.get("meta") or {}
        pre = meta.get("preBalances") or []
        post = meta.get("postBalances") or []
        if recipient in keys and len(pre) == len(post) == len(keys):
            ri = keys.index(recipient)
            delta = (inum(post[ri], 0) - inum(pre[ri], 0)) / LAMPORTS_PER_SOL
            if delta > 0:
                best_sender = ""
                best_drop = 0.0
                for i, k in enumerate(keys):
                    drop = (inum(pre[i], 0) - inum(post[i], 0)) / LAMPORTS_PER_SOL
                    if k != recipient and drop > best_drop:
                        best_sender, best_drop = k, drop
                if best_sender:
                    return best_sender, delta
        # Fallback: parsed system transfer instructions.
        try:
            instrs = (((tx.get("transaction") or {}).get("message") or {}).get("instructions")) or []
            for ins in instrs:
                parsed = (ins or {}).get("parsed") or {}
                info = parsed.get("info") or {}
                if str(parsed.get("type") or "").lower() == "transfer" and str(info.get("destination") or "") == recipient:
                    lamports = fnum(info.get("lamports"), 0.0)
                    sol = lamports / LAMPORTS_PER_SOL if lamports > 10000 else fnum(info.get("sol"), 0.0)
                    src = str(info.get("source") or "")
                    if src and sol > 0:
                        return src, sol
        except Exception:
            pass
        return "", 0.0

    def _record_creator_token(self, creator: str, mint: str, ts: int, sig: str = "") -> None:
        creators = self.history.setdefault("creators", {})
        row = creators.setdefault(creator, {"creator": creator, "tokens": [], "updated_ts": ts})
        tokens = row.setdefault("tokens", [])
        if not any(t.get("mint") == mint for t in tokens if isinstance(t, dict)):
            tokens.append({"mint": mint, "ts": ts, "sig": sig, "max_pump_pct": 0.0, "time_to_dump_sec": None, "our_entry": None, "our_exit": None})
        row["updated_ts"] = ts
        self.history.setdefault("mints", {})[mint] = {"creator": creator, "ts": ts, "sig": sig}

    def _record_controller(self, creator: str, controller: str, ts: int, sig: str, sol: float) -> None:
        creators = self.graph.setdefault("creators", {})
        creators[creator] = {"controller": controller, "updated_ts": ts, "funding_sig": sig, "funding_sol": sol}
        controllers = self.graph.setdefault("controllers", {})
        crow = controllers.setdefault(controller, {"controller": controller, "funded_wallets": {}})
        funded = crow.setdefault("funded_wallets", {})
        funded[creator] = {"ts": ts, "funding_sig": sig, "funding_sol": sol}
        crow["updated_ts"] = ts

    def _save_state(self) -> None:
        try:
            save_json(self.history_file, self.history)
            save_json(self.graph_file, self.graph)
        except Exception as e:
            self._warn("save_state", e)

    def get_creator_for_mint(self, mint: str) -> str:
        try:
            m = (self.graph.get("mints") or {}).get(mint) or (self.history.get("mints") or {}).get(mint) or {}
            return str(m.get("creator") or "")
        except Exception:
            return ""

    def get_creator_cluster(self, mint: str) -> Set[str]:
        try:
            # Hot-reload funding_graph.json opportunistically so the offline
            # funding_graph_builder process can update clusters without restart.
            try:
                self.graph = load_json(self.graph_file, self.graph) or self.graph
            except Exception:
                pass
            creator = self.get_creator_for_mint(mint)
            if not creator:
                # Builder compatibility: creator map may exist even if in-memory mints is stale.
                try:
                    if self.map_file.exists():
                        for line in self.map_file.read_text(encoding="utf-8", errors="ignore").splitlines()[-1500:]:
                            try:
                                ev = json.loads(line)
                            except Exception:
                                continue
                            if str(ev.get("mint") or "") == mint:
                                creator = str(ev.get("creator_wallet") or ev.get("creator") or "")
                                break
                except Exception:
                    pass
            if not creator:
                return set()
            cluster: Set[str] = {creator}
            # New builder format: funding_graph[wallet] -> {controller, cluster_id, siblings...}
            wrow = self.graph.get(creator) if isinstance(self.graph.get(creator), dict) else {}
            cid = str((wrow or {}).get("cluster_id") or "")
            controller = str((wrow or {}).get("controller") or "")
            if controller:
                cluster.add(controller)
            if cid:
                cluster_path = self.data_dir / "cluster_map.json"
                cmap = load_json(cluster_path, {}) or {}
                members = ((cmap.get(cid) or {}).get("members") or []) if isinstance(cmap.get(cid), dict) else []
                cluster.update(str(w) for w in members if w)
                for w, r in self.graph.items():
                    if isinstance(r, dict) and str(r.get("cluster_id") or "") == cid:
                        cluster.add(str(w))
                        cluster.update(str(x) for x in (r.get("siblings") or []) if x)
                        cluster.update(str(x) for x in (r.get("funded_wallets") or []) if x)
            # Legacy creator_tracker format.
            cinfo = (self.graph.get("creators") or {}).get(creator) or {}
            legacy_controller = str(cinfo.get("controller") or "")
            if legacy_controller:
                cluster.add(legacy_controller)
                lookback = inum(self.cfg.get("CREATOR_CONTROLLER_LOOKBACK_DAYS"), 30) * 86400
                cutoff = now_ts() - lookback
                funded = (((self.graph.get("controllers") or {}).get(legacy_controller) or {}).get("funded_wallets") or {})
                for w, r in funded.items():
                    if inum((r or {}).get("ts"), 0) >= cutoff:
                        cluster.add(str(w))
            return {w for w in cluster if w}
        except Exception as e:
            self._warn("get_creator_cluster", e, {"mint": mint})
            return set()

    def recent_cluster_activity(self, window_sec: int = 60) -> bool:
        try:
            p = self.data_dir / "live_wallet_events.jsonl"
            if not p.exists():
                return False
            cutoff = now_ts() - max(1, int(window_sec))
            clusters: Set[str] = set()
            for c in (self.graph.get("creators") or {}).keys():
                clusters.add(c)
            for ctrl, row in (self.graph.get("controllers") or {}).items():
                clusters.add(ctrl)
                clusters.update((row.get("funded_wallets") or {}).keys())
            # tail read only to keep dashboard cheap
            lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()[-500:]
            for line in reversed(lines):
                try:
                    e = json.loads(line)
                except Exception:
                    continue
                if inum(e.get("ts"), 0) < cutoff:
                    break
                if str(e.get("wallet") or "") in clusters and str(e.get("side") or "").lower() == "buy":
                    return True
        except Exception:
            return False
        return False

    def top_creator_rows(self, n: int = 20) -> List[Dict[str, Any]]:
        try:
            from wallet_intel import CreatorIntelligence
            ci = CreatorIntelligence(self.cfg)
            rows = ci.get_top_creators(n)
            for r in rows:
                creator = r.get("creator") or ""
                ctrl = ((self.graph.get("creators") or {}).get(creator) or {}).get("controller") or ""
                members = sorted(self.get_creator_cluster_for_creator(creator))
                r["controller_wallet"] = ctrl
                r["cluster_members"] = members
            return rows
        except Exception as e:
            self._warn("top_creator_rows", e)
            return []

    def get_creator_cluster_for_creator(self, creator: str) -> Set[str]:
        fake_mint = ""
        try:
            for m, row in (self.graph.get("mints") or {}).items():
                if (row or {}).get("creator") == creator:
                    fake_mint = m
                    break
            if fake_mint:
                return self.get_creator_cluster(fake_mint)
            cluster = {creator} if creator else set()
            cinfo = (self.graph.get("creators") or {}).get(creator) or {}
            controller = str(cinfo.get("controller") or "")
            if controller:
                cluster.add(controller)
                funded = (((self.graph.get("controllers") or {}).get(controller) or {}).get("funded_wallets") or {})
                cluster.update(str(w) for w in funded.keys())
            return {w for w in cluster if w}
        except Exception:
            return {creator} if creator else set()
