# v11.2.20 HIVE Fast Sniper Runner

Clean-core build for fresh data collection.

## Behavior
- Default exit is fast sniper: take quick profit and move on.
- Runner mode is only earned when unrealized PnL is >= 8%, buy flow is still stronger than sell flow, queen exit is not firing, and sell pressure/ratio are clean.
- TP1/TP2 and breakeven lock are disabled.
- Fixed buy size is 0.1 SOL.
- Old raw logs and learned data are not included so the run starts clean.

## Key config
- `HIVE_EXIT_MODE`: `FAST_SNIPER_THEN_RUNNER`
- `FAST_SNIPER_MIN_NET_PCT`: `0.035`
- `FAST_SNIPER_IDEAL_NET_PCT`: `0.06`
- `FAST_SNIPER_MAX_HOLD_SEC`: `45`
- `FAST_SNIPER_STALE_FLOW_SEC`: `12`
- `RUNNER_MIN_UNREALIZED_PCT`: `0.08`
- `RUNNER_TRAIL_PCT`: `0.045`
- `RUNNER_MAX_HOLD_SEC`: `180`

Run clean, collect fresh logs, then compare reasons in `wallet_predator_trades.csv`, `hive_fast_sniper_events.jsonl`, and `queen_worker_exit_pressure.jsonl`.
