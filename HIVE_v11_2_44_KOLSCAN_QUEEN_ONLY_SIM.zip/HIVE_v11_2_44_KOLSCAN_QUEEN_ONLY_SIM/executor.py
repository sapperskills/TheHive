from __future__ import annotations
from typing import Any, Dict, List
from util import fnum, inum, now_ts, save_json, load_json, append_jsonl, append_csv, clamp, short_mint
from live_trader import LiveTrader
from queen_worker_graph import QueenWorkerGraph
from creator_tracker import get_global_creator_tracker
from feed_latency_monitor import get_global_feed_latency_monitor

TRADE_HEADERS = ['ts','side','mint','setup','sol','mc','gross_pnl_sol','estimated_cost_sol','pnl_sol','gross_pnl_pct','net_pnl_pct','reason','score','sig_or_error']

class PositionManager:
    def __init__(self, config: Dict[str, Any], creator_tracker: Any = None):
        self.cfg = config
        self.creator_tracker = creator_tracker or get_global_creator_tracker()
        self.positions_file = config.get('POSITIONS_FILE','wallet_predator_positions.json')
        self.trades_file = config.get('TRADES_FILE','wallet_predator_trades.csv')
        self.positions: Dict[str, Dict[str, Any]] = load_json(self.positions_file, {}) or {}
        if config.get('CLEAR_STALE_POSITIONS_ON_START', True) and not config.get('RESUME_OPEN_POSITIONS', False):
            if self.positions:
                if config.get('ARCHIVE_STALE_POSITIONS_ON_START', True):
                    append_jsonl('stale_position_archive.jsonl', {'ts': now_ts(), 'reason': 'cleared_on_start_fresh_only', 'positions': self.positions})
                self.positions = {}
                save_json(self.positions_file, self.positions)
        self.live = LiveTrader(config)
        # v11.2.17: executor also needs the hive graph. v11.2.16 only
        # initialized it in strategy.py, so live exit checks crashed with:
        # AttributeError: PositionManager has no attribute hive_graph.
        self.hive_graph = QueenWorkerGraph(config) if config.get('QUEEN_WORKER_GRAPH_ENABLED', True) else None
        self.reload_swarm_edge_profiles()
        self.reload_follow_money_graph()
        self.reload_hive_ai_scores()
        self.cooldown_file = config.get('COOLDOWN_FILE','mint_cooldowns.json')
        self.cooldowns: Dict[str, float] = load_json(self.cooldown_file, {}) or {}
        self.entry_counts: Dict[str, int] = {}
        try:
            import csv as _csv
            p = __import__('pathlib').Path(self.trades_file)
            if p.exists():
                with p.open(newline='', encoding='utf-8', errors='ignore') as f:
                    for r in _csv.DictReader(f):
                        if 'BUY' in (r.get('side') or ''):
                            m = r.get('mint') or ''
                            self.entry_counts[m] = self.entry_counts.get(m, 0) + 1
        except Exception:
            pass


    def reload_swarm_edge_profiles(self) -> None:
        """Reload mined exit-warning wallets without restarting live trading."""
        self.swarm_edge_profiles = load_json(self.cfg.get('SWARM_EDGE_PROFILE_FILE','swarm_edge_profiles.json'), {}) or {}
        self.swarm_exit_wallets = {x.get('wallet'): x for x in self.swarm_edge_profiles.get('exit_warning_wallets', []) if x.get('wallet')}


    def reload_follow_money_graph(self) -> None:
        """Load exit wallets discovered by follow_money_graph.py."""
        try:
            watch = load_json(self.cfg.get('FOLLOW_MONEY_WATCHLIST_FILE','FOLLOW_MONEY_WATCHLIST.json'), {}) or {}
            self.follow_money_exit_wallets = set(str(x) for x in (watch.get('exit_wallets') or []) if x)
            self.follow_money_entry_wallets = set(str(x) for x in (watch.get('entry_wallets') or []) if x)
        except Exception:
            self.follow_money_exit_wallets = set()
            self.follow_money_entry_wallets = set()

    def reload_hive_ai_scores(self) -> None:
        """Executor-safe AI score reload hook.

        v11.2.31 added a call to this hook in PositionManager.__init__,
        but only Strategy had the method, causing:
        AttributeError: 'PositionManager' object has no attribute 'reload_hive_ai_scores'.

        PositionManager does not currently make direct entry decisions from AI;
        it only needs a lightweight cache so main.py can hot-reload AI files
        without crashing. Strategy remains the trading decision user of these scores.
        """
        try:
            self.hive_ai_scores = load_json(self.cfg.get('HIVE_AI_SCORES_FILE','hive_ai_scores.json'), {}) or {}
        except Exception as e:
            self.hive_ai_scores = {}
            append_jsonl('hive_ai_reload_errors.jsonl', {'ts': now_ts(), 'where': 'PositionManager', 'error': str(e)})


    def has_position(self) -> bool:
        return bool(self.positions)

    def max_positions_ok(self) -> bool:
        return len(self.positions) < inum(self.cfg.get('MAX_OPEN_POSITIONS'), 1)

    def _is_no_token_balance_error(self, err: str) -> bool:
        e = str(err or '').lower()
        return ('no token balance found' in e) or ('no token account' in e) or ('token balance not found' in e)

    def _pending_sell_recent(self, mint: str, now: int | None = None) -> bool:
        pos = self.positions.get(mint) or {}
        pend = pos.get('pending_live_sell') or {}
        if not pend:
            return False
        now = now or now_ts()
        retry_sec = fnum(self.cfg.get('LIVE_PENDING_SELL_RETRY_SEC'), 8.0)
        return (now - inum(pend.get('ts'), 0)) < retry_sec

    def observe_own_wallet_trade(self, row: Dict[str, Any]) -> Dict[str, Any] | None:
        """Use subscribed token-trade WSS events to confirm our own buys/sells.

        This deliberately avoids wallet-balance polling. Pump trade-local can lag
        or return `No token balance found` even after a successful sell; the old
        runner-guard bot proved the cleanest confirmation is the token-trade stream.
        """
        if not self.cfg.get('LIVE_USE_WSS_TRADE_CONFIRMATION', True):
            return None
        mint = row.get('mint') or ''
        if not mint:
            return None
        wallet = str(row.get('last_event_wallet') or '').strip()
        side = str(row.get('last_side') or '').lower()
        if side not in ('buy', 'sell'):
            return None
        pub = str(self.cfg.get('PUBLIC_KEY') or getattr(self.live, 'public_key', '') or '').strip()
        now = inum(row.get('ts'), now_ts())
        # WIN-RATE GUARD v11.2.36-WR: never adopt random WSS wallet buys as our own.
        # The SIM/run logs showed thousands of `live_wss_adopted_untracked_buy` positions with
        # very low win rate when PUBLIC_KEY was blank or not resolved. That turned copy-flow
        # events into fake local positions and polluted dashboard PnL/wallet intelligence.
        if self.cfg.get('LIVE_REQUIRE_PUBLIC_KEY_MATCH_FOR_WSS_ADOPT', True):
            if not pub or not wallet or wallet != pub:
                if side in ('buy', 'sell') and self.cfg.get('LOG_IGNORED_NON_OWN_WSS_CONFIRMATIONS', False):
                    append_jsonl('ignored_non_own_wss_confirmations.jsonl', {'ts': now, 'mint': mint, 'wallet': wallet, 'side': side, 'reason': 'public_key_match_required'})
                return None
        elif pub and wallet and wallet != pub:
            return None
        pos = self.positions.get(mint)
        if not pos:
            if side == 'buy' and self.cfg.get('LIVE_ADOPT_UNTRACKED_OWN_BUY', True):
                # v11.2.19: do not re-adopt our own delayed WSS buy after a completed exit.
                # The v11.2.18 logs showed repeated phantom adopted positions followed by
                # "No token balance found" sell failures. A mint on cooldown means we just
                # traded/closed it, so this WSS buy is stale local echo, not a new bag.
                if self.cfg.get('LIVE_ADOPT_BLOCK_WHEN_RECENT_COOLDOWN', True):
                    cd_reason = self._cooldown_active_reason(mint)
                    if cd_reason:
                        append_jsonl(self.cfg.get('LIVE_UNTRACKED_OWN_BUY_FILE','live_untracked_own_buys.jsonl'), {'ts': now, 'mint': mint, 'wallet': wallet, 'sol': row.get('last_event_sol'), 'mc': row.get('mc') or row.get('current_mc'), 'action': 'skip_adopt_recent_cooldown', 'reason': cd_reason})
                        return {'side': side, 'mint': mint, 'confirmed': True, 'adopted': False, 'reason': cd_reason}
                # If a live buy ever reaches chain but local tracking missed it, adopt it immediately.
                # This is a last-resort guard against untracked bags and duplicate re-entry loops.
                sol = fnum(row.get('last_event_sol'), fnum(self.cfg.get('BUY_SOL'), 0.0))
                decision = {
                    'mint': mint, 'ts': now, 'mc': fnum(row.get('mc') if row.get('mc') is not None else row.get('current_mc'), 0.0),
                    'setup': self.cfg.get('LIVE_ADOPTED_BUY_SETUP','live_wss_adopted_untracked_buy'),
                    'score': 0.0, 'buy_sol': sol, 'reason': 'adopted_own_wallet_buy_wss',
                    'wallet_summary': {'wallets': [{'wallet': wallet, 'role': 'own_wallet', 'buy_sol': sol, 'net_buy_sol': sol}]},
                    'live_risk_tier': 'ADOPTED', 'buy_wss_confirmed': True, 'buy_balance_confirmed': True,
                }
                adopted = self._record_buy_position(decision, 'adopted_own_wallet_buy_wss', 'LIVE_BUY_ADOPTED_WSS', '', skip_prechecks=True)
                if adopted:
                    adopted['buy_wss_confirmed'] = True
                    adopted['buy_wss_confirmed_ts'] = now
                    adopted['buy_wss_wallet'] = wallet
                    adopted['buy_wss_sol'] = sol
                    self.positions[mint] = adopted
                    save_json(self.positions_file, self.positions)
                    append_jsonl(self.cfg.get('LIVE_UNTRACKED_OWN_BUY_FILE','live_untracked_own_buys.jsonl'), {'ts': now, 'mint': mint, 'wallet': wallet, 'sol': sol, 'mc': decision['mc'], 'action': 'adopted'})
                    print(f"LIVE_UNTRACKED_BUY_ADOPTED mint={short_mint(mint)} wallet={wallet[:8]} sol={sol:.6f}")
                    return {'side': side, 'mint': mint, 'confirmed': True, 'adopted': True}
            if side == 'sell':
                append_jsonl('live_untracked_own_sells.jsonl', {'ts': now, 'mint': mint, 'wallet': wallet, 'sol': row.get('last_event_sol'), 'action': 'own_sell_no_local_position'})
            return None
        if side == 'buy':
            if now < inum(pos.get('entry_ts'), now) - 2:
                return None
            pos['buy_wss_confirmed'] = True
            pos['buy_balance_confirmed'] = True
            pos['pending_buy_balance_confirm'] = False
            pos['buy_wss_confirmed_ts'] = now
            pos['buy_wss_wallet'] = wallet
            pos['buy_wss_sol'] = fnum(row.get('last_event_sol'), 0.0)
            self.positions[mint] = pos
            save_json(self.positions_file, self.positions)
            append_jsonl('live_wss_trade_confirmations.jsonl', {'ts': now, 'mint': mint, 'side': side, 'wallet': wallet, 'sol': row.get('last_event_sol'), 'action': 'buy_confirmed'})
            print(f"LIVE_BUY_WSS_CONFIRMED mint={short_mint(mint)} wallet={wallet[:8]} sol={fnum(row.get('last_event_sol'),0):.6f}")
            return {'side': side, 'mint': mint, 'confirmed': True}
        # side == sell
        pend = pos.get('pending_live_sell') or {}
        sent_at = inum(pend.get('ts'), 0)
        if sent_at and now < sent_at - 3:
            return None
        pos['sell_wss_confirmed_ts'] = now
        pos['sell_wss_wallet'] = wallet
        pos['sell_wss_sol'] = fnum(row.get('last_event_sol'), 0.0)
        pos.pop('pending_live_sell', None)
        self.positions[mint] = pos
        save_json(self.positions_file, self.positions)
        append_jsonl('live_wss_trade_confirmations.jsonl', {'ts': now, 'mint': mint, 'side': side, 'wallet': wallet, 'sol': row.get('last_event_sol'), 'action': 'sell_confirmed', 'pending': pend})
        print(f"LIVE_SELL_WSS_CONFIRMED mint={short_mint(mint)} wallet={wallet[:8]} sol={fnum(row.get('last_event_sol'),0):.6f}")
        return {'side': side, 'mint': mint, 'confirmed': True}

    def _estimated_round_trip_cost_sol(self, sold_sol: float, pct: float = 1.0) -> float:
        """Fee/slippage-aware PnL guard.

        Pump.fun/PumpPortal execution can show positive MC-to-MC PnL while the
        wallet is down after priority fees, platform fees, spread, and slippage.
        This estimate is deliberately conservative and is used for dashboard PnL,
        live risk accounting, and fee-safe exits.
        """
        sold_sol = max(0.0, fnum(sold_sol, 0.0))
        pct = clamp(fnum(pct, 1.0), 0.0, 1.0)
        bps = fnum(self.cfg.get('ESTIMATED_ROUND_TRIP_COST_BPS'), 350.0)
        fixed = fnum(self.cfg.get('ESTIMATED_ROUND_TRIP_FIXED_SOL'), fnum(self.cfg.get('PRIORITY_FEE_SOL'), 0.0006) * 2.0)
        return sold_sol * (bps / 10000.0) + fixed * pct

    def _estimated_net_pnl(self, sold_sol: float, gross_pnl_pct: float, pct: float = 1.0) -> tuple[float, float, float]:
        gross = fnum(sold_sol, 0.0) * fnum(gross_pnl_pct, 0.0)
        cost = self._estimated_round_trip_cost_sol(sold_sol, pct) if self.cfg.get('PNL_USE_NET_ESTIMATE', True) else 0.0
        net = gross - cost
        denom = max(1e-12, fnum(sold_sol, 0.0))
        return gross, cost, net / denom

    def _wallet_actual_pnl_for_full_exit(self, pos: Dict[str, Any]) -> tuple[bool, float]:
        """Return actual wallet SOL delta for a fully closed live round trip.

        This is more truthful than MC-based PnL because it includes platform fee,
        priority fee, slippage, and any trade-local spread. It assumes one open
        position at a time, which this bot enforces by default.
        """
        if not self.cfg.get('LIVE_PNL_USE_WALLET_SOL_DELTA', True):
            return False, 0.0
        pre = fnum(pos.get('wallet_sol_before_buy'), -1.0)
        after = fnum(pos.get('_wallet_sol_after_sell'), -1.0)
        if pre >= 0 and after >= 0:
            return True, after - pre
        return False, 0.0

    def _record_zero_balance_sync(self, mint: str, pct: float, mc: float, reason: str, ts: int | None, sig_or_error: str = '') -> Dict[str, Any] | None:
        """Close local live position when chain/trade-local says the wallet has no token balance.

        This prevents infinite TP/stale sell retry loops after a real sell, manual sell, or
        already-cleared dust account. By default it does not book estimated profit, because
        there is no fresh sell signature from this attempt.
        """
        pos = self.positions.get(mint)
        if not pos:
            return None
        remaining = fnum(pos.get('remaining_pct'), 1.0)
        entry = fnum(pos.get('entry_mc'), mc)
        est_pnl_pct = (mc / entry - 1.0) if entry > 0 else 0.0
        count_pnl = bool(self.cfg.get('LIVE_ZERO_BALANCE_CLOSE_COUNTS_PNL', False))
        sold_sol = fnum(pos.get('sol'), 0.0) * remaining if count_pnl else 0.0
        gross_pnl_sol, estimated_cost_sol, net_pnl_pct = self._estimated_net_pnl(sold_sol, est_pnl_pct, remaining) if count_pnl else (0.0, 0.0, 0.0)
        pnl_sol = gross_pnl_sol - estimated_cost_sol if count_pnl and self.cfg.get('PNL_USE_NET_ESTIMATE', True) else gross_pnl_sol
        self.positions.pop(mint, None)
        save_json(self.positions_file, self.positions)
        side = 'LIVE_SELL_ZERO_BALANCE_SYNC'
        append_csv(self.trades_file, TRADE_HEADERS, {
            'ts': ts or now_ts(), 'side': side, 'mint': mint, 'setup': pos.get('setup'),
            'sol': sold_sol, 'mc': mc, 'gross_pnl_sol': gross_pnl_sol, 'estimated_cost_sol': estimated_cost_sol,
            'pnl_sol': pnl_sol, 'gross_pnl_pct': est_pnl_pct if count_pnl else 0, 'net_pnl_pct': net_pnl_pct if count_pnl else 0,
            'reason': reason, 'score': pos.get('score', 0), 'sig_or_error': sig_or_error
        })
        append_jsonl('position_lifecycle.jsonl', {
            'ts': ts or now_ts(), 'event': side.lower(), 'mint': mint, 'setup': pos.get('setup'),
            'mc': mc, 'sold_pct': remaining, 'pnl_pct': est_pnl_pct if count_pnl else 0,
            'pnl_sol': pnl_sol, 'reason': reason, 'remaining_pct': 0,
            'sig_or_error': sig_or_error, 'zero_balance_sync': True
        })
        append_jsonl('live_sell_zero_balance_sync.jsonl', {
            'ts': ts or now_ts(), 'mint': mint, 'setup': pos.get('setup'), 'mc': mc,
            'remaining_pct': remaining, 'reason': reason, 'sig_or_error': sig_or_error,
            'counted_pnl': count_pnl
        })
        self._set_cooldown(mint, reason + '|zero_balance_sync', pnl_sol)
        if count_pnl:
            self._risk_record_sell(pnl_sol, reason + '|zero_balance_sync', mint)
        print(f"{side} mint={short_mint(mint)} setup={pos.get('setup')} reason={reason} err={str(sig_or_error)[:120]}")
        return {'pnl_pct': est_pnl_pct if count_pnl else 0, 'pnl_sol': pnl_sol, 'reason': reason, 'zero_balance_sync': True}


    def _dust_thresholds(self) -> tuple[int, float]:
        return inum(self.cfg.get('LIVE_SELL_DUST_RAW_THRESHOLD'), 10), fnum(self.cfg.get('LIVE_SELL_DUST_UI_THRESHOLD'), 0.0)

    async def _wait_for_live_balance(self, mint: str, purpose: str, timeout_sec: float | None = None) -> tuple[int, float]:
        """Poll live wallet token balance briefly after buy/sell.

        This borrows the old engine idea of confirming positions by the wallet
        stream/RPC instead of trusting a local guess. Returning (-1, -1) means
        unknown, not zero.
        """
        import asyncio, time
        if not self.cfg.get('LIVE_TOKEN_BALANCE_CHECK_ENABLED', True):
            return -1, -1.0
        timeout = fnum(timeout_sec, fnum(self.cfg.get('LIVE_BUY_BALANCE_WAIT_SEC'), 12.0))
        poll = max(0.15, fnum(self.cfg.get('LIVE_BUY_BALANCE_POLL_SEC'), 0.75))
        end = time.time() + max(0.0, timeout)
        last = (-1, -1.0)
        while True:
            raw, ui = await self.live.get_token_balance_raw_ui(mint)
            last = (raw, ui)
            append_jsonl(self.cfg.get('LIVE_POSITION_RECONCILE_LOG', 'live_position_reconcile.jsonl'), {
                'ts': now_ts(), 'mint': mint, 'purpose': purpose, 'raw': raw, 'ui': ui
            })
            if raw > 0 or time.time() >= end:
                return raw, ui
            await asyncio.sleep(poll)

    async def _confirm_live_buy_balance(self, mint: str, pos: Dict[str, Any], sig: str) -> None:
        if not self.cfg.get('LIVE_WAIT_FOR_BUY_BALANCE', True):
            return
        raw, ui = await self._wait_for_live_balance(mint, 'buy_confirm', fnum(self.cfg.get('LIVE_BUY_BALANCE_WAIT_SEC'), 12.0))
        if raw > 0:
            pos['entry_token_raw'] = raw
            pos['entry_token_ui'] = ui
            pos['last_token_raw'] = raw
            pos['last_token_ui'] = ui
            pos['buy_balance_confirmed'] = True
            pos['buy_balance_confirmed_ts'] = now_ts()
            pos['pending_buy_balance_confirm'] = False
            self.positions[mint] = pos
            save_json(self.positions_file, self.positions)
            append_jsonl(self.cfg.get('LIVE_BUY_BALANCE_CONFIRM_LOG', 'live_buy_balance_confirm.jsonl'), {
                'ts': now_ts(), 'mint': mint, 'raw': raw, 'ui': ui, 'sig': sig, 'confirmed': True
            })
            print(f"LIVE_BUY_BALANCE_CONFIRMED mint={short_mint(mint)} raw={raw} ui={ui}")
        else:
            pos['pending_buy_balance_confirm'] = True
            pos['buy_balance_confirmed'] = False
            pos['last_token_raw'] = raw
            pos['last_token_ui'] = ui
            self.positions[mint] = pos
            save_json(self.positions_file, self.positions)
            append_jsonl(self.cfg.get('LIVE_BUY_BALANCE_CONFIRM_LOG', 'live_buy_balance_confirm.jsonl'), {
                'ts': now_ts(), 'mint': mint, 'raw': raw, 'ui': ui, 'sig': sig, 'confirmed': False
            })
            print(f"LIVE_BUY_BALANCE_PENDING mint={short_mint(mint)} raw={raw} ui={ui}")

    async def _sync_position_from_wallet_balance(self, mint: str, mc: float, reason: str, ts: int | None = None) -> Dict[str, Any] | None:
        """Update local remaining_pct from actual wallet token balance.

        If wallet balance is zero/dust, close local state. This is the key fix
        to avoid leftovers and stale local positions after real sells/manual sells.
        """
        pos = self.positions.get(mint)
        if not pos or not self.cfg.get('LIVE_POSITION_RECONCILE_ENABLED', True):
            return pos
        raw, ui = await self.live.get_token_balance_raw_ui(mint)
        dust_raw, dust_ui = self._dust_thresholds()
        append_jsonl(self.cfg.get('LIVE_POSITION_RECONCILE_LOG', 'live_position_reconcile.jsonl'), {
            'ts': ts or now_ts(), 'mint': mint, 'reason': reason, 'raw': raw, 'ui': ui,
            'entry_raw': pos.get('entry_token_raw'), 'local_remaining_pct': pos.get('remaining_pct')
        })
        if raw >= 0 and raw <= dust_raw and ui <= dust_ui:
            self._record_zero_balance_sync(mint, fnum(pos.get('remaining_pct'), 1.0), mc, reason + '|wallet_balance_zero', ts, f'raw={raw} ui={ui}')
            return None
        if raw > 0:
            entry_raw = inum(pos.get('entry_token_raw'), 0)
            remaining_before = fnum(pos.get('remaining_pct'), 1.0)
            # If entry raw was never captured, infer it from current raw / current remaining.
            if entry_raw <= 0 and remaining_before > 0:
                entry_raw = max(raw, int(raw / max(remaining_before, 1e-9)))
                pos['entry_token_raw'] = entry_raw
                pos['entry_token_ui'] = ui / max(remaining_before, 1e-9) if ui >= 0 else ui
            if entry_raw > 0 and self.cfg.get('LIVE_USE_ACTUAL_BALANCE_FOR_REMAINING_PCT', True):
                actual_remaining = clamp(float(raw) / float(entry_raw), 0.0, 1.0)
                pos['remaining_pct'] = actual_remaining
            pos['last_token_raw'] = raw
            pos['last_token_ui'] = ui
            pos['last_balance_sync_ts'] = ts or now_ts()
            pos.pop('pending_live_sell', None)
            self.positions[mint] = pos
            save_json(self.positions_file, self.positions)
            return pos
        # raw == -1 means unknown/RPC error; don't close on unknown.
        return pos

    async def _record_live_sell_reconciled(self, mint: str, requested_pct: float, mc: float, reason: str, ts: int | None, sig: str, before_raw: int, before_ui: float, is_full_remaining_exit: bool) -> Dict[str, Any] | None:
        """After LIVE_SELL_OK, reconcile actual wallet balance before closing/reducing local state."""
        import asyncio
        settle = fnum(self.cfg.get('LIVE_SELL_BALANCE_SETTLE_SEC'), 1.25)
        polls = max(1, inum(self.cfg.get('LIVE_SELL_BALANCE_CONFIRM_POLLS'), 3))
        poll_sleep = max(0.1, fnum(self.cfg.get('LIVE_SELL_BALANCE_CONFIRM_POLL_SEC'), 0.8))
        after_raw, after_ui = -1, -1.0
        dust_raw, dust_ui = self._dust_thresholds()
        if self.cfg.get('LIVE_RECONCILE_AFTER_SELL', True) and self.cfg.get('LIVE_TOKEN_BALANCE_CHECK_ENABLED', True):
            await asyncio.sleep(settle)
            for i in range(polls):
                after_raw, after_ui = await self.live.get_token_balance_raw_ui(mint)
                append_jsonl(self.cfg.get('LIVE_SELL_CONFIRM_LOG', 'live_sell_confirmations.jsonl'), {
                    'ts': ts or now_ts(), 'mint': mint, 'poll': i + 1, 'before_raw': before_raw, 'before_ui': before_ui,
                    'after_raw': after_raw, 'after_ui': after_ui, 'requested_pct': requested_pct, 'reason': reason, 'sig': sig
                })
                if after_raw >= 0:
                    break
                await asyncio.sleep(poll_sleep)
        pos = self.positions.get(mint)
        if not pos:
            return None
        remaining_before = fnum(pos.get('remaining_pct'), 1.0)
        actual_pct = requested_pct
        if after_raw >= 0:
            entry_raw = inum(pos.get('entry_token_raw'), 0)
            if after_raw <= dust_raw and after_ui <= dust_ui:
                actual_pct = remaining_before
            elif entry_raw > 0:
                actual_remaining = clamp(float(after_raw) / float(entry_raw), 0.0, 1.0)
                actual_pct = clamp(remaining_before - actual_remaining, 0.0, remaining_before)
                # If RPC settled slowly and shows no reduction, fall back to requested pct.
                if actual_pct <= 0.000001:
                    actual_pct = requested_pct
            if after_raw > dust_raw and is_full_remaining_exit and self.cfg.get('LIVE_SELL_SWEEP_DUST_ENABLED', True):
                # Full exit intended but balance remains: send a 100% sweep and re-check.
                sweep_retries = max(0, inum(self.cfg.get('LIVE_SELL_SWEEP_RETRIES'), 3))
                sweep_sleep = fnum(self.cfg.get('LIVE_SELL_SWEEP_SLEEP_SEC'), 1.0)
                sweep_sigs = []
                for sweep_i in range(1, sweep_retries + 1):
                    await asyncio.sleep(sweep_sleep)
                    ok2, sig2 = await self.live.execute('sell', mint, '100%', denominated_in_sol=False)
                    sweep_sigs.append(sig2)
                    raw2, ui2 = await self.live.get_token_balance_raw_ui(mint)
                    append_jsonl(self.cfg.get('LIVE_SELL_SWEEP_LOG_FILE', 'live_sell_sweeps.jsonl'), {
                        'ts': ts or now_ts(), 'mint': mint, 'sweep_i': sweep_i, 'ok': ok2, 'sig_or_error': sig2,
                        'raw_after': raw2, 'ui_after': ui2, 'reason': reason
                    })
                    if (raw2 >= 0 and raw2 <= dust_raw and ui2 <= dust_ui) or (not ok2 and self._is_no_token_balance_error(sig2)):
                        actual_pct = remaining_before
                        sig = sig + '|sweeps=' + ','.join(str(x) for x in sweep_sigs)
                        break
        res = self._record_sell(mint, actual_pct, mc, 'LIVE_SELL', reason, ts, sig)
        # After recording a partial sell, force local remaining to actual wallet balance when known.
        if mint in self.positions and after_raw is not None and after_raw > dust_raw:
            pos2 = self.positions[mint]
            entry_raw = inum(pos2.get('entry_token_raw'), 0)
            if entry_raw > 0:
                pos2['remaining_pct'] = clamp(float(after_raw) / float(entry_raw), 0.0, 1.0)
            pos2['last_token_raw'] = after_raw
            pos2['last_token_ui'] = after_ui
            pos2.pop('pending_live_sell', None)
            self.positions[mint] = pos2
            save_json(self.positions_file, self.positions)
        elif mint in self.positions and after_raw >= 0 and after_raw <= dust_raw and after_ui <= dust_ui:
            # Safety: if _record_sell did not close due to pct math, close now.
            self._record_zero_balance_sync(mint, fnum(self.positions[mint].get('remaining_pct'), 0.0), mc, reason + '|post_sell_zero_balance_force_close', ts, sig)
        return res

    def _live_safety_enabled(self) -> bool:
        mode = str(self.cfg.get('MODE') or '')
        return bool(self.cfg.get('LIVE_SAFETY_CIRCUIT_BREAKER_ENABLED', True)) and (mode == 'live' or bool(self.cfg.get('LIVE_SAFETY_APPLIES_TO_SIM', True)))

    def _risk_file(self) -> str:
        return self.cfg.get('LIVE_RISK_STATE_FILE', 'live_risk_state.json')

    def _risk_state(self) -> Dict[str, Any]:
        day = int(now_ts() // 86400)
        st = load_json(self._risk_file(), {}) or {}
        if st.get('day') != day:
            st = {'day': day, 'buy_count': 0, 'sell_count': 0, 'realized_pnl_sol': 0.0, 'hard_stops': 0, 'consecutive_losses': 0, 'last_update_ts': now_ts()}
            save_json(self._risk_file(), st)
        return st

    def _live_risk_block_reason(self, prospective_sol: float = 0.0) -> str:
        if not self._live_safety_enabled():
            return ''
        st = self._risk_state()
        pnl = fnum(st.get('realized_pnl_sol'), 0.0)
        if pnl <= -abs(fnum(self.cfg.get('LIVE_MAX_DAILY_LOSS_SOL'), 0.08)):
            return f'live_circuit_daily_loss_{pnl:.4f}'
        if inum(st.get('hard_stops'), 0) >= inum(self.cfg.get('LIVE_MAX_HARD_STOPS_PER_DAY'), 1):
            return f'live_circuit_hard_stops_{inum(st.get("hard_stops"),0)}'
        if inum(st.get('consecutive_losses'), 0) >= inum(self.cfg.get('LIVE_MAX_CONSECUTIVE_LOSSES'), 2):
            return f'live_circuit_consecutive_losses_{inum(st.get("consecutive_losses"),0)}'
        if inum(st.get('buy_count'), 0) >= inum(self.cfg.get('LIVE_MAX_TRADES_PER_DAY'), 8):
            return f'live_circuit_trade_count_{inum(st.get("buy_count"),0)}'
        # Guard open loss before adding another position. Usually max positions=1, but keep this safe.
        open_loss = 0.0
        for pos in self.positions.values():
            entry = fnum(pos.get('entry_mc'), 0.0); last = fnum(pos.get('last_mc'), entry); sol = fnum(pos.get('sol'), 0.0)
            if entry > 0:
                open_loss += min(0.0, sol * (last / entry - 1.0))
        if open_loss <= -abs(fnum(self.cfg.get('LIVE_MAX_OPEN_LOSS_SOL'), 0.06)):
            return f'live_circuit_open_loss_{open_loss:.4f}'
        return ''

    def _risk_record_buy(self, sol: float, setup: str, mint: str) -> None:
        if not self._live_safety_enabled():
            return
        st = self._risk_state(); st['buy_count'] = inum(st.get('buy_count'), 0) + 1; st['last_update_ts'] = now_ts()
        st['last_buy'] = {'ts': now_ts(), 'mint': mint, 'setup': setup, 'sol': sol}
        save_json(self._risk_file(), st)

    def _risk_record_sell(self, pnl_sol: float, reason: str, mint: str) -> None:
        if not self._live_safety_enabled():
            return
        st = self._risk_state(); st['sell_count'] = inum(st.get('sell_count'), 0) + 1; st['realized_pnl_sol'] = fnum(st.get('realized_pnl_sol'), 0.0) + fnum(pnl_sol, 0.0); st['last_update_ts'] = now_ts()
        if reason == 'hard_stop': st['hard_stops'] = inum(st.get('hard_stops'), 0) + 1
        st['consecutive_losses'] = inum(st.get('consecutive_losses'), 0) + 1 if pnl_sol < 0 else 0
        st['last_sell'] = {'ts': now_ts(), 'mint': mint, 'reason': reason, 'pnl_sol': pnl_sol}
        save_json(self._risk_file(), st)

    def _buy_sol_for_decision(self, decision: Dict[str, Any]) -> float:
        """Universal buy sizing.

        v11.2.30 intentionally ignores per-lane/scout/tier sizing so every
        approved live buy uses the single config key BUY_SOL. This prevents
        queen/scout lanes from silently using a different size than normal buys.
        """
        return fnum(self.cfg.get('BUY_SOL'), fnum(self.cfg.get('FIXED_BUY_SOL'), 0.1))

    def _pre_buy_block_reason(self, decision: Dict[str, Any], sol: float | None = None) -> str:
        """Return reason that would stop a buy BEFORE any live transaction is sent.

        This is intentionally duplicated ahead of the live send path. A prior build
        sent the live buy first, then discovered cooldown/max-entry/risk blocks in
        `_record_buy_position`, leaving real wallet buys untracked.
        """
        mint = decision.get('mint') or ''
        if not mint:
            return 'missing_mint'
        if not self.max_positions_ok():
            return f'max_open_positions_{len(self.positions)}'
        cd = self._cooldown_active_reason(mint, decision)
        if cd:
            return cd
        if sol is None:
            sol = self._buy_sol_for_decision(decision)
        rb = self._live_risk_block_reason(fnum(sol, 0.0))
        if rb:
            return rb
        return ''

    def _log_prebuy_block(self, decision: Dict[str, Any], reason: str, sol: float | None = None) -> None:
        try:
            append_jsonl(self.cfg.get('PREBUY_BLOCKS_FILE','prebuy_blocks.jsonl'), {
                'ts': now_ts(), 'mint': decision.get('mint'), 'reason': reason,
                'sol': sol, 'setup': decision.get('setup'), 'score': decision.get('score'),
                'decision': decision,
            })
        except Exception:
            pass
        print(f"PREBUY_BLOCK mint={short_mint(decision.get('mint',''))} reason={reason} sol={fnum(sol,0):.4f}")

    def _decision_has_runner_reentry_edge(self, decision: Dict[str, Any]) -> bool:
        """Allow controlled same-mint re-entry when the tape is still a runner.

        The v11.2.26 data showed the 900/1800s cooldown blocked many later
        runner windows on the same mint after the first fee-negative churn exit.
        This does not remove cooldown globally; it only bypasses it when the
        current decision still has strong queen/refill flow and enough room to
        clear fees.
        """
        if not self.cfg.get('COOLDOWN_REENTRY_BYPASS_ENABLED', True):
            return False
        setup = str(decision.get('setup') or '')
        if setup not in ('queen_dump_recovery_scout', 'queen_cycle_ride', 'queen_worker_front_run', 'swarm_edge_auto_ride'):
            return False
        score = fnum(decision.get('score'), 0.0)
        if score < fnum(self.cfg.get('COOLDOWN_REENTRY_MIN_SCORE'), 400.0):
            return False
        if inum(decision.get('recent_buys'), 0) < inum(self.cfg.get('COOLDOWN_REENTRY_MIN_RECENT_BUYS'), 12):
            return False
        if fnum(decision.get('sell_pressure'), 1.0) > fnum(self.cfg.get('COOLDOWN_REENTRY_MAX_SELL_PRESSURE'), 0.58):
            return False
        if fnum(decision.get('total_sell_buy_ratio'), 99.0) > fnum(self.cfg.get('COOLDOWN_REENTRY_MAX_SELL_BUY_RATIO'), 1.25):
            return False
        hive = decision.get('hive_state') or {}
        worker_sol = fnum(hive.get('worker_buy_sol'), 0.0) + fnum(hive.get('soft_worker_sol'), 0.0)
        queen_sell = fnum(hive.get('queen_sell_sol'), 0.0)
        if worker_sol < 2.0 and fnum(decision.get('buy_sol_recent'), 0.0) < 2.0:
            return False
        # avoid re-entering pure queen dump with no refill cover
        if queen_sell > 0 and worker_sol <= 0:
            return False
        return True

    def _cooldown_active_reason(self, mint: str, decision: Dict[str, Any] | None = None) -> str:
        until = fnum(self.cooldowns.get(mint), 0.0)
        if until > now_ts():
            if decision and self._decision_has_runner_reentry_edge(decision):
                append_jsonl('cooldown_reentry_bypasses.jsonl', {'ts': now_ts(), 'mint': mint, 'seconds_left': int(until-now_ts()), 'decision': decision})
            else:
                return f'mint_cooldown_{int(until-now_ts())}s'
        max_entries = inum(self.cfg.get('MAX_ENTRIES_PER_MINT_PER_RUN'), 2)
        if max_entries > 0 and self.entry_counts.get(mint, 0) >= max_entries:
            return f'max_entries_per_mint_{self.entry_counts.get(mint,0)}'
        return ''

    def _set_cooldown(self, mint: str, reason: str, pnl_sol: float = 0.0) -> None:
        if not mint: return
        sec = fnum(self.cfg.get('EXIT_MINT_COOLDOWN_SEC'), 180.0)
        if reason == 'hard_stop':
            sec = fnum(self.cfg.get('HARD_STOP_MINT_COOLDOWN_SEC'), 900.0)
        elif pnl_sol < 0 or reason in ('wallet_dump_or_sell_pressure_exit','stale_unseen_flow_exit','no_buy_flow_exit','stale_no_profit_exit'):
            sec = fnum(self.cfg.get('LOSS_MINT_COOLDOWN_SEC'), 420.0)
        elif pnl_sol > 0:
            sec = fnum(self.cfg.get('PROFIT_MINT_COOLDOWN_SEC'), 45.0)
        if sec > 0:
            self.cooldowns[mint] = now_ts() + sec
            save_json(self.cooldown_file, self.cooldowns)
            append_jsonl('mint_cooldown_events.jsonl', {'ts': now_ts(), 'mint': mint, 'seconds': sec, 'reason': reason, 'pnl_sol': pnl_sol})

    def _record_buy_position(self, decision: Dict[str, Any], reason: str, side_label: str, sig_or_error: str = '', skip_prechecks: bool = False) -> Dict[str, Any]:
        mint = decision['mint']
        mc = fnum(decision.get('mc'),0.0)
        sol = self._buy_sol_for_decision(decision)
        if not skip_prechecks:
            block_reason = self._pre_buy_block_reason(decision, sol)
            if block_reason:
                if str(block_reason).startswith('mint_cooldown') or str(block_reason).startswith('max_entries_per_mint'):
                    append_jsonl('ignored_cooldown_entries.jsonl', {'ts': now_ts(), 'mint': mint, 'reason': block_reason, 'decision': decision})
                else:
                    append_jsonl('ignored_live_risk_blocks.jsonl', {'ts': now_ts(), 'mint': mint, 'reason': block_reason, 'decision': decision, 'sol': sol, 'risk_state': self._risk_state()})
                self._log_prebuy_block(decision, block_reason, sol)
                return None
        pos = {
            'mint': mint,
            'setup': decision.get('setup'),
            'entry_ts': inum(decision.get('ts'), now_ts()),
            'entry_mc': mc,
            'last_mc': mc,
            'high_mc': mc,
            'sol': sol,
            'remaining_pct': 1.0,
            'tp1_done': False,
            'tp2_done': False,
            'score': fnum(decision.get('score'),0.0),
            'reason': decision.get('reason',''),
            'wallet_summary': decision.get('wallet_summary',{}),
            'sig': sig_or_error if side_label == 'LIVE_BUY' else '',
            'entry_token_raw': inum(decision.get('entry_token_raw'), 0),
            'entry_token_ui': fnum(decision.get('entry_token_ui'), 0.0),
            'buy_balance_confirmed': bool(decision.get('buy_balance_confirmed', False)),
            'pending_buy_balance_confirm': bool(decision.get('pending_buy_balance_confirm', False)),
            'wallet_sol_before_buy': fnum(decision.get('wallet_sol_before_buy'), -1.0),
            'wallet_sol_after_buy': fnum(decision.get('wallet_sol_after_buy'), -1.0),
        }
        self.positions[mint] = pos
        self.entry_counts[mint] = self.entry_counts.get(mint, 0) + 1
        save_json(self.positions_file, self.positions)
        append_csv(self.trades_file, TRADE_HEADERS, {'ts': inum(decision.get('ts'), now_ts()),'side':side_label,'mint':mint,'setup':pos['setup'],'sol':sol,'mc':mc,'gross_pnl_sol':0,'estimated_cost_sol':0,'pnl_sol':0,'gross_pnl_pct':0,'net_pnl_pct':0,'reason':reason,'score':pos['score'],'sig_or_error':sig_or_error + ('|pnl_source=' + pnl_source if 'pnl_source' in locals() else '')})
        append_jsonl('position_lifecycle.jsonl', {'ts':inum(decision.get('ts'), now_ts()),'event':side_label.lower(),'mint':mint,'setup':pos['setup'],'mc':mc,'sol':sol,'score':pos['score'],'reason':reason,'sig_or_error':sig_or_error,'live_risk_tier':decision.get('live_risk_tier')})
        self._risk_record_buy(sol, str(pos['setup']), mint)
        print(f"{side_label}_SIGNAL mint={short_mint(mint)} setup={pos['setup']} sol={sol:.4f} mc={mc:.4f} score={pos['score']:.1f} tier={decision.get('live_risk_tier','')} reason={pos['reason']}")
        return pos

    async def buy_async(self, decision: Dict[str, Any], reason: str = 'wallet_predator_entry') -> Dict[str, Any] | None:
        if not self.max_positions_ok():
            return None
        mint = decision['mint']
        sol = self._buy_sol_for_decision(decision)
        if self.cfg.get('MODE') == 'live':
            if self.cfg.get('LIVE_PRECHECK_BEFORE_BUY_SEND', True):
                block_reason = self._pre_buy_block_reason(decision, sol)
                if block_reason:
                    self._log_prebuy_block(decision, block_reason, sol)
                    return None
            if self.cfg.get('LIVE_PNL_USE_WALLET_SOL_DELTA', True):
                try:
                    decision['wallet_sol_before_buy'] = await self.live.get_sol_balance()
                except Exception:
                    decision['wallet_sol_before_buy'] = -1.0
            ok, sig = await self.live.execute('buy', mint, sol, denominated_in_sol=True)
            if self.cfg.get('LIVE_PNL_USE_WALLET_SOL_DELTA', True):
                try:
                    decision['wallet_sol_after_buy'] = await self.live.get_sol_balance()
                except Exception:
                    decision['wallet_sol_after_buy'] = -1.0
            if not ok:
                append_csv(self.trades_file, TRADE_HEADERS, {'ts': inum(decision.get('ts'), now_ts()),'side':'LIVE_BUY_FAIL','mint':mint,'setup':decision.get('setup'),'sol':sol,'mc':decision.get('mc',0),'gross_pnl_sol':0,'estimated_cost_sol':0,'pnl_sol':0,'gross_pnl_pct':0,'net_pnl_pct':0,'reason':reason,'score':decision.get('score',0),'sig_or_error':sig})
                if self.cfg.get('LIVE_RECORD_FAILED_BUYS_AS_PAPER', False):
                    return self._record_buy_position(decision, reason + '|live_failed_paper_record', 'PAPER_BUY', sig)
                return None
            pos = self._record_buy_position(decision, reason, 'LIVE_BUY', sig, skip_prechecks=True)
            if pos:
                pos['buy_tx_sent'] = True
                pos['buy_wss_confirmed'] = False
                pos['pending_buy_balance_confirm'] = False
                self.positions[mint] = pos
                save_json(self.positions_file, self.positions)
                if self.cfg.get('LIVE_WAIT_FOR_BUY_BALANCE', False):
                    await self._confirm_live_buy_balance(mint, pos, sig)
            return self.positions.get(mint) or pos
        return self._record_buy_position(decision, reason, 'PAPER_BUY')

    def buy(self, decision: Dict[str, Any], reason: str = 'wallet_predator_entry') -> Dict[str, Any] | None:
        return self._record_buy_position(decision, reason, 'PAPER_BUY')

    async def sell_async(self, mint: str, pct: float, mc: float, reason: str, ts: int | None = None) -> Dict[str, Any] | None:
        if self.cfg.get('MODE') == 'live':
            pos = self.positions.get(mint) or {}
            if not pos:
                return None
            if self.cfg.get('LIVE_RECONCILE_BEFORE_SELL', False):
                pos = await self._sync_position_from_wallet_balance(mint, mc, 'pre_sell_reconcile|' + reason, ts) or {}
                if not pos:
                    return None
            remaining_before = fnum(pos.get('remaining_pct'), 1.0)
            pct = clamp(pct, 0.0, remaining_before)
            if pct <= 0:
                return None

            if self.cfg.get('LIVE_SELL_PERCENT_OF_CURRENT_BALANCE', True):
                current_pct = 1.0 if remaining_before <= 0 else clamp(pct / remaining_before, 0.0, 1.0)
            else:
                current_pct = clamp(pct, 0.0, 1.0)
            is_full_remaining_exit = pct >= max(0.0, remaining_before - 0.001)
            percent = int(round(current_pct * 100))
            if is_full_remaining_exit and self.cfg.get('LIVE_SELL_FULL_EXIT_FORCE_100_PERCENT', True):
                percent = 100
            amount = f"{max(1, min(100, percent))}%"

            before_raw, before_ui = -1, -1.0
            if self.cfg.get('LIVE_TOKEN_BALANCE_CHECK_ENABLED', False):
                before_raw, before_ui = await self.live.get_token_balance_raw_ui(mint)
                dust_raw0, dust_ui0 = self._dust_thresholds()
                if before_raw >= 0 and before_raw <= dust_raw0 and before_ui <= dust_ui0:
                    return self._record_zero_balance_sync(mint, pct, mc, reason + '|pre_sell_zero_balance', ts, f'raw={before_raw} ui={before_ui}')

            attempts = max(1, inum(self.cfg.get('LIVE_SELL_RETRY_ATTEMPTS'), 3))
            delay = fnum(self.cfg.get('LIVE_SELL_RETRY_SLEEP_SEC'), 0.75)
            last_err = ''
            for attempt in range(1, attempts + 1):
                if self.cfg.get('LIVE_PNL_USE_WALLET_SOL_DELTA', True):
                    try:
                        pos['wallet_sol_before_sell'] = await self.live.get_sol_balance()
                    except Exception:
                        pos['wallet_sol_before_sell'] = -1.0
                ok, sig = await self.live.execute('sell', mint, amount, denominated_in_sol=False)
                if ok:
                    if self.cfg.get('LIVE_PNL_USE_WALLET_SOL_DELTA', True):
                        try:
                            import asyncio
                            await asyncio.sleep(fnum(self.cfg.get('LIVE_PNL_SOL_BALANCE_SETTLE_SEC'), 0.8))
                            pos['_wallet_sol_after_sell'] = await self.live.get_sol_balance()
                            self.positions[mint] = pos
                            save_json(self.positions_file, self.positions)
                        except Exception:
                            pos['_wallet_sol_after_sell'] = -1.0
                    # LIVE_SELL_RECORD_ON_SEND
                    # Fast live path: trust sendTransaction/trade-local success and let WSS confirm in background.
                    # This mirrors the older runner-guard bot and prevents wallet-balance polling from blocking exits.
                    res = self._record_sell(mint, pct, mc, 'LIVE_SELL', reason, ts, sig)
                    if mint in self.positions:
                        p2 = self.positions[mint]
                        p2['pending_live_sell'] = {'ts': ts or now_ts(), 'pct': pct, 'amount': amount, 'pct_current_balance': current_pct, 'reason': reason, 'sig': sig, 'awaiting_wss': True}
                        self.positions[mint] = p2
                        save_json(self.positions_file, self.positions)
                    append_jsonl('live_sell_sent_wss_pending.jsonl', {'ts': ts or now_ts(), 'mint': mint, 'pct': pct, 'amount': amount, 'reason': reason, 'sig': sig})
                    return res
                last_err = sig
                append_csv(self.trades_file, TRADE_HEADERS, {'ts': ts or now_ts(),'side':'LIVE_SELL_FAIL','mint':mint,'setup':pos.get('setup'),'sol':0,'mc':mc,'gross_pnl_sol':0,'estimated_cost_sol':0,'pnl_sol':0,'gross_pnl_pct':0,'net_pnl_pct':0,'reason':f'{reason}|attempt_{attempt}_{amount}|orig_pct_{pct:.4f}|current_pct_{current_pct:.4f}','score':pos.get('score',0),'sig_or_error':sig})
                append_jsonl('live_sell_failures.jsonl', {'ts': ts or now_ts(), 'mint': mint, 'attempt': attempt, 'attempts': attempts, 'amount': amount, 'pct_original_position': pct, 'pct_current_balance': current_pct, 'remaining_before': remaining_before, 'mc': mc, 'reason': reason, 'error': sig, 'before_raw': before_raw, 'before_ui': before_ui})
                print(f"LIVE_SELL_RETRY mint={short_mint(mint)} attempt={attempt}/{attempts} amount={amount} orig_pct={pct:.3f} current_pct={current_pct:.3f} reason={reason} error={str(sig)[:140]}")
                if attempt < attempts:
                    try:
                        import asyncio
                        await asyncio.sleep(delay)
                    except Exception:
                        pass
            if self._is_no_token_balance_error(last_err) and self.cfg.get('LIVE_NO_TOKEN_BALANCE_IS_CLOSED', True):
                # trade-local says no balance; in WSS-confirm mode treat this as already sold/gone and release local state.
                if not self.cfg.get('LIVE_TOKEN_BALANCE_CHECK_ENABLED', False):
                    return self._record_zero_balance_sync(mint, pct, mc, reason + '|trade_local_no_token_balance_wss_mode', ts, last_err)
                if self.cfg.get('LIVE_TOKEN_BALANCE_CHECK_ENABLED', False):
                    raw1, ui1 = await self.live.get_token_balance_raw_ui(mint)
                    dust_raw1, dust_ui1 = self._dust_thresholds()
                    if raw1 >= 0 and raw1 <= dust_raw1 and ui1 <= dust_ui1:
                        return self._record_zero_balance_sync(mint, pct, mc, reason + '|trade_local_no_token_balance_confirmed_zero', ts, last_err)
                    if raw1 > dust_raw1:
                        pos = self.positions.get(mint) or pos
                        pos['last_token_raw'] = raw1
                        pos['last_token_ui'] = ui1
                        pos['pending_live_sell'] = {'ts': ts or now_ts(), 'pct': pct, 'amount': amount, 'pct_current_balance': current_pct, 'reason': reason, 'last_error': last_err, 'raw_balance_after_error': raw1}
                        self.positions[mint] = pos
                        save_json(self.positions_file, self.positions)
                        return None
                if self.cfg.get('LIVE_SYNC_CLOSE_ON_NO_TOKEN_BALANCE_ERROR', True):
                    return self._record_zero_balance_sync(mint, pct, mc, reason + '|trade_local_no_token_balance', ts, last_err)

            if self.cfg.get('LIVE_SELL_FAIL_KEEP_POSITION', True):
                pos = self.positions.get(mint) or pos
                pos['pending_live_sell'] = {'ts': ts or now_ts(), 'pct': pct, 'amount': amount, 'pct_current_balance': current_pct, 'reason': reason, 'last_error': last_err}
                self.positions[mint] = pos
                save_json(self.positions_file, self.positions)
            if self.cfg.get('LIVE_RECORD_FAILED_SELL_AS_PAPER', False):
                return self._record_sell(mint, pct, mc, 'PAPER_SELL_FAILED_LIVE', reason, ts, last_err)
            return None
        return self._record_sell(mint, pct, mc, 'PAPER_SELL', reason, ts, '')

    def sell(self, mint: str, pct: float, mc: float, reason: str, ts: int | None = None) -> Dict[str, Any] | None:
        return self._record_sell(mint, pct, mc, 'PAPER_SELL', reason, ts, '')

    def _record_sell(self, mint: str, pct: float, mc: float, side_label: str, reason: str, ts: int | None = None, sig_or_error: str = '') -> Dict[str, Any] | None:
        pos = self.positions.get(mint)
        if not pos: return None
        pct = clamp(pct, 0.0, fnum(pos.get('remaining_pct'),1.0))
        if pct <= 0: return None
        entry = fnum(pos.get('entry_mc'), mc)
        pnl_pct = (mc / entry - 1.0) if entry > 0 else 0.0
        sold_sol = fnum(pos.get('sol'),0.0) * pct
        gross_pnl_sol, estimated_cost_sol, net_pnl_pct = self._estimated_net_pnl(sold_sol, pnl_pct, pct)
        pnl_sol = gross_pnl_sol - estimated_cost_sol if self.cfg.get('PNL_USE_NET_ESTIMATE', True) else gross_pnl_sol
        pnl_source = 'mc_net_estimate' if self.cfg.get('PNL_USE_NET_ESTIMATE', True) else 'mc_gross'
        # For full live exits, prefer actual wallet SOL delta if available.
        closed_full_preview = (fnum(pos.get('remaining_pct'), 1.0) - pct) <= 0.001
        actual_ok, actual_pnl = self._wallet_actual_pnl_for_full_exit(pos) if side_label == 'LIVE_SELL' and closed_full_preview else (False, 0.0)
        if actual_ok:
            pnl_sol = actual_pnl
            net_pnl_pct = pnl_sol / max(1e-12, fnum(pos.get('sol'), sold_sol))
            # Keep gross as market-cap estimate, but make fee/slip the difference so dashboard shows why fake-green differs.
            estimated_cost_sol = gross_pnl_sol - pnl_sol
            pnl_source = 'wallet_sol_delta'
        pos['remaining_pct'] = fnum(pos.get('remaining_pct'),1.0) - pct
        closed_full = pos['remaining_pct'] <= 0.001
        if closed_full:
            self.positions.pop(mint, None)
        else:
            self.positions[mint] = pos
        save_json(self.positions_file, self.positions)
        append_csv(self.trades_file, TRADE_HEADERS, {'ts': ts or now_ts(),'side':side_label,'mint':mint,'setup':pos.get('setup'),'sol':sold_sol,'mc':mc,'gross_pnl_sol':gross_pnl_sol,'estimated_cost_sol':estimated_cost_sol,'pnl_sol':pnl_sol,'gross_pnl_pct':pnl_pct,'net_pnl_pct':net_pnl_pct,'reason':reason,'score':pos.get('score',0),'sig_or_error':sig_or_error + ('|pnl_source=' + pnl_source if 'pnl_source' in locals() else '')})
        if closed_full:
            self._set_cooldown(mint, reason, pnl_sol)
        self._risk_record_sell(pnl_sol, reason, mint)
        append_jsonl('position_lifecycle.jsonl', {'ts':ts or now_ts(),'event':side_label.lower(),'mint':mint,'setup':pos.get('setup'),'mc':mc,'sold_pct':pct,'gross_pnl_pct':pnl_pct,'net_pnl_pct':net_pnl_pct,'gross_pnl_sol':gross_pnl_sol,'estimated_cost_sol':estimated_cost_sol,'pnl_pct':net_pnl_pct if self.cfg.get('PNL_USE_NET_ESTIMATE', True) else pnl_pct,'pnl_sol':pnl_sol,'reason':reason,'remaining_pct':pos.get('remaining_pct',0),'sig_or_error':sig_or_error + ('|pnl_source=' + pnl_source if 'pnl_source' in locals() else '')})
        print(f"{side_label}_SIGNAL mint={short_mint(mint)} setup={pos.get('setup')} pct={pct:.2f} gross_pct={pnl_pct:.3f} net_pct={net_pnl_pct:.3f} pnl_sol={pnl_sol:.6f} reason={reason}")
        return {'gross_pnl_pct':pnl_pct,'net_pnl_pct':net_pnl_pct,'gross_pnl_sol':gross_pnl_sol,'estimated_cost_sol':estimated_cost_sol,'pnl_pct':net_pnl_pct if self.cfg.get('PNL_USE_NET_ESTIMATE', True) else pnl_pct,'pnl_sol':pnl_sol,'reason':reason}


    def _runner_allowed(self, pos: Dict[str, Any], row: Dict[str, Any], hive: Dict[str, Any], pnl_pct: float, age: float) -> bool:
        """v11.2.20: runner is earned, not assumed.

        Default behavior is fast sniper: grab the quick profit and move on.
        A token may graduate into runner mode only when it already has a real
        unrealized gain and the queen/worker flow is still clean.
        """
        if not self.cfg.get('RUNNER_ENABLED', True):
            return False
        if pnl_pct < fnum(self.cfg.get('RUNNER_MIN_UNREALIZED_PCT'), 0.08):
            return False
        sell_pressure = fnum(row.get('sell_pressure'), 0.0)
        ratio = fnum(row.get('total_sell_buy_ratio'), 0.0)
        recent_buys = inum(row.get('recent_buys'), 0)
        recent_sells = inum(row.get('recent_sells'), 0)
        if self.cfg.get('RUNNER_REQUIRE_BUY_PRESSURE', True) and recent_buys <= recent_sells:
            return False
        if self.cfg.get('RUNNER_REQUIRE_QUEEN_SAFE', True):
            if hive and (hive.get('queen_exit_now') or hive.get('hive_flip_exit') or hive.get('queen_sells', 0) > 0 or hive.get('queen_sell_sol', 0.0) > 0):
                return False
        else:
            # v11.2.27: queen-dump recovery is expected to have queen sells in
            # history. Treat queen pressure as acceptable only when worker refill
            # is still dominating the live tape.
            if str(pos.get('setup')) in ('queen_dump_recovery_scout','queen_cycle_ride','swarm_edge_auto_ride'):
                worker_sol = fnum(hive.get('worker_buy_sol'), 0.0) + fnum(hive.get('soft_worker_sol'), 0.0) if hive else 0.0
                queen_sell = fnum(hive.get('queen_sell_sol'), 0.0) if hive else 0.0
                if worker_sol < 1.5 and recent_buys <= recent_sells:
                    return False
                if queen_sell > 0 and worker_sol <= 0 and sell_pressure >= 0.35:
                    return False
        if sell_pressure >= fnum(self.cfg.get('LIVE_MAX_SELL_PRESSURE'), 0.20):
            return False
        if ratio >= fnum(self.cfg.get('LIVE_MAX_SELL_BUY_RATIO'), 0.35):
            return False
        return True

    async def _fast_sniper_exit_check(self, mint: str, pos: Dict[str, Any], row: Dict[str, Any], hive: Dict[str, Any], pnl_pct: float, age: float, now: int, do_sell) -> Dict[str, Any] | None:
        """v11.2.36: bite fast, extract, and only let proven flow run.
        Min hold gates added: soft exits must wait for fee-breakeven age."""
        if not self.cfg.get('FAST_SNIPER_ENABLED', True):
            return None
        recent_buys = inum(row.get('recent_buys'), 0)
        recent_sells = inum(row.get('recent_sells'), 0)
        last_buy_age = fnum(row.get('last_buy_age_sec'), fnum(row.get('seconds_since_last_buy'), 0.0))
        stale_flow_sec = fnum(self.cfg.get('FAST_SNIPER_STALE_FLOW_SEC'), 24.0)
        max_hold = fnum(self.cfg.get('FAST_SNIPER_MAX_HOLD_SEC'), 150.0)
        # v11.2.36: use config values (0.20 ideal, 0.12 min) not old code defaults (0.06/0.035)
        ideal = fnum(self.cfg.get('FAST_SNIPER_IDEAL_NET_PCT'), 0.20)
        min_net = fnum(self.cfg.get('FAST_SNIPER_MIN_NET_PCT'), 0.12)
        sell_pct = fnum(self.cfg.get('FAST_SNIPER_SELL_PCT'), 1.0)
        # v11.2.36: min hold before any soft exit — prevents sub-8s fee-negative exits
        min_soft_hold = fnum(self.cfg.get('FAST_SNIPER_MIN_SOFT_EXIT_AGE_SEC'), 8.0)
        runner_ok = self._runner_allowed(pos, row, hive, pnl_pct, age)
        if runner_ok:
            return None
        sold_sol_eval = fnum(pos.get('sol'), 0.0) * sell_pct
        _gross_sol, _cost_sol, net_eval_pct = self._estimated_net_pnl(sold_sol_eval, pnl_pct, sell_pct)
        eval_pct = net_eval_pct if self.cfg.get('PNL_EXIT_USE_NET_ESTIMATE', True) else pnl_pct
        if bool(self.cfg.get('FAST_SNIPER_EXIT_ON_IDEAL', True)) and eval_pct >= ideal:
            return await do_sell(sell_pct, 'fast_sniper_fee_safe_ideal_profit_exit')
        # v11.2.36: stale-flow and max-hold exits require age >= min_soft_hold
        if eval_pct >= min_net and age >= min_soft_hold and (recent_buys <= recent_sells or last_buy_age >= stale_flow_sec):
            return await do_sell(sell_pct, 'fast_sniper_fee_safe_stale_flow_exit')
        if age >= max_hold:
            # Max hold is a hard time stop; do not require fee-safe profit.
            return await do_sell(sell_pct, 'fast_sniper_max_hold_exit')
        return None


    def _force_max_hold_seconds(self, pos: Dict[str, Any]) -> float:
        """Universal hard cap for how long any position may remain open.

        This is intentionally independent of profit. The old fast-sniper max-hold
        only sold if the trade was already fee-safe green, which allowed dead
        red/flat positions to sit for many minutes. Fast sniper should move on.
        """
        setup = str(pos.get('setup') or '')
        caps = []
        # Global caps. POSITION_MAX_HOLD_SEC / MAX_POSITION_AGE_SEC are aliases
        # so config changes are honored even if older builds used different names.
        for key in ('POSITION_MAX_HOLD_SEC', 'MAX_POSITION_AGE_SEC', 'MAX_HOLD_SEC'):
            val = self.cfg.get(key)
            if val is not None:
                caps.append(fnum(val, 0.0))
        # SIM-specific hard cap used during testing before live.
        if str(self.cfg.get('MODE', '')).lower() == 'sim' and self.cfg.get('SIM_MAX_HOLD_SEC') is not None:
            caps.append(fnum(self.cfg.get('SIM_MAX_HOLD_SEC'), 0.0))
        # Fast-sniper cap should apply to the whole SIM/live fast-sniper profile,
        # not only positions whose setup string literally contains fast_sniper.
        if self.cfg.get('FAST_SNIPER_ENABLED', False) or self.cfg.get('FAST_SNIPER_MODE', False) or 'fast_sniper' in setup:
            caps.append(fnum(self.cfg.get('FAST_SNIPER_MAX_HOLD_SEC'), 60.0))
        # Per-setup override can make specific setups even faster.
        setup_caps = self.cfg.get('SETUP_MAX_HOLD_SEC') or {}
        if setup in setup_caps:
            caps.append(fnum(setup_caps.get(setup), 0.0))
        caps = [c for c in caps if c and c > 0]
        return min(caps) if caps else 0.0

    async def _force_max_hold_exit_async(self, mint: str, pos: Dict[str, Any], mc: float, age: float, now: int, do_sell) -> Dict[str, Any] | None:
        """Sell when the universal max-hold cap is exceeded, profit or loss."""
        if not (self.cfg.get('FORCE_POSITION_MAX_HOLD_EXIT', True) or self.cfg.get('EXIT_ON_MAX_HOLD', True) or self.cfg.get('SIM_FORCE_MAX_HOLD_EXIT', False)):
            return None
        cap = self._force_max_hold_seconds(pos)
        if cap > 0 and age >= cap:
            append_jsonl('force_max_hold_exits.jsonl', {
                'ts': now,
                'mint': mint,
                'setup': pos.get('setup'),
                'age': age,
                'cap': cap,
                'mc': mc,
                'entry_mc': pos.get('entry_mc'),
                'reason': 'force_max_hold_exit_profit_or_loss'
            })
            return await do_sell(1.0, 'force_max_hold_exit')
        return None

    async def stale_check_all_async(self, event_ts: int | None = None) -> List[Dict[str, Any]]:
        now = event_ts or now_ts()
        out=[]
        for mint,pos in list(self.positions.items()):
            if now < inum(pos.get('entry_ts'), now) - 1:
                now = now_ts()
            last_seen = inum(pos.get('last_seen_ts'), inum(pos.get('entry_ts'), now))
            age = now - inum(pos.get('entry_ts'), now)
            unseen = now - last_seen
            mc = fnum(pos.get('last_mc'), fnum(pos.get('entry_mc'),0.0))
            if self._pending_sell_recent(mint, now):
                continue
            # v11.2.17: global stale sweep is a last-resort safety only.
            # Do not dump brand-new runner candidates just because unrelated WSS
            # rows arrived. The normal per-mint update path handles trail / queen
            # exits when that mint actually updates.
            entry = fnum(pos.get('entry_mc'), mc)
            pnl_pct = (mc / entry - 1.0) if entry > 0 else 0.0
            cap = self._force_max_hold_seconds(pos)
            if cap > 0 and age >= cap:
                async def _sweep_sell(pct, reason):
                    return await self.sell_async(mint, pct, mc, reason, now)
                res = await self._force_max_hold_exit_async(mint, pos, mc, age, now, _sweep_sell)
                if res:
                    out.append(res)
                    continue
            min_age = fnum(self.cfg.get('GLOBAL_STALE_SWEEP_MIN_AGE_SEC'), 75.0)
            allow_profit_stale = bool(self.cfg.get('GLOBAL_STALE_SWEEP_SELL_PROFIT', False))
            no_flow_sec = fnum((self.cfg.get('SETUP_NO_BUY_FLOW_EXIT_SEC') or {}).get(str(pos.get('setup')), self.cfg.get('NO_BUY_FLOW_EXIT_SEC')), 35.0)
            stale_sec = fnum((self.cfg.get('SETUP_STALE_EXIT_SEC') or {}).get(str(pos.get('setup')), self.cfg.get('STALE_EXIT_SEC')), 55.0)
            if age >= min_age and (unseen >= no_flow_sec or age >= stale_sec) and (allow_profit_stale or pnl_pct <= fnum(self.cfg.get('GLOBAL_STALE_SWEEP_MAX_PNL'), -0.02)):
                res = await self.sell_async(mint, 1.0, mc, 'stale_unseen_flow_exit', now)
                if res: out.append(res)
        return out

    def stale_check_all(self, event_ts: int | None = None) -> List[Dict[str, Any]]:
        now = event_ts or now_ts()
        out=[]
        for mint,pos in list(self.positions.items()):
            if now < inum(pos.get('entry_ts'), now) - 1:
                now = now_ts()
            last_seen = inum(pos.get('last_seen_ts'), inum(pos.get('entry_ts'), now))
            age = now - inum(pos.get('entry_ts'), now)
            unseen = now - last_seen
            mc = fnum(pos.get('last_mc'), fnum(pos.get('entry_mc'),0.0))
            if self._pending_sell_recent(mint, now):
                continue
            entry = fnum(pos.get('entry_mc'), mc)
            pnl_pct = (mc / entry - 1.0) if entry > 0 else 0.0
            cap = self._force_max_hold_seconds(pos)
            if cap > 0 and age >= cap and (self.cfg.get('FORCE_POSITION_MAX_HOLD_EXIT', True) or self.cfg.get('EXIT_ON_MAX_HOLD', True) or self.cfg.get('SIM_FORCE_MAX_HOLD_EXIT', False)):
                append_jsonl('force_max_hold_exits.jsonl', {'ts': now, 'mint': mint, 'setup': pos.get('setup'), 'age': age, 'cap': cap, 'mc': mc, 'entry_mc': pos.get('entry_mc'), 'reason': 'force_max_hold_exit_profit_or_loss_sync_sweep'})
                res = self.sell(mint, 1.0, mc, 'force_max_hold_exit', now)
                if res:
                    out.append(res)
                    continue
            min_age = fnum(self.cfg.get('GLOBAL_STALE_SWEEP_MIN_AGE_SEC'), 75.0)
            allow_profit_stale = bool(self.cfg.get('GLOBAL_STALE_SWEEP_SELL_PROFIT', False))
            no_flow_sec = fnum((self.cfg.get('SETUP_NO_BUY_FLOW_EXIT_SEC') or {}).get(str(pos.get('setup')), self.cfg.get('NO_BUY_FLOW_EXIT_SEC')), 35.0)
            stale_sec = fnum((self.cfg.get('SETUP_STALE_EXIT_SEC') or {}).get(str(pos.get('setup')), self.cfg.get('STALE_EXIT_SEC')), 55.0)
            if age >= min_age and (unseen >= no_flow_sec or age >= stale_sec) and (allow_profit_stale or pnl_pct <= fnum(self.cfg.get('GLOBAL_STALE_SWEEP_MAX_PNL'), -0.02)):
                res = self.sell(mint, 1.0, mc, 'stale_unseen_flow_exit', now)
                if res: out.append(res)
        return out

    def _hive_exit_state(self, mint: str, row: Dict[str, Any]) -> Dict[str, Any]:
        if not self.hive_graph:
            return {}
        try:
            return self.hive_graph.analyze_events(mint, row.get('live_wallet_events') or [], write=True)
        except Exception as e:
            append_jsonl('runtime_errors.jsonl', {'ts': now_ts(), 'where': 'executor_hive_exit_state', 'mint': mint, 'error': repr(e)})
            return {}


    def _swarm_exit_warning_hit(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """Return mined exit-warning wallet info when one is currently selling."""
        if not self.cfg.get('SWARM_EDGE_EXIT_WARNING_ENABLED', True):
            return {}
        wallet = str(row.get('last_event_wallet') or row.get('last_wallet') or '').strip()
        side = str(row.get('last_side') or '').lower()
        if side == 'sell' and wallet in self.swarm_exit_wallets:
            prof = dict(self.swarm_exit_wallets.get(wallet) or {})
            prof['wallet'] = wallet
            prof['source'] = 'last_event_wallet'
            return prof
        # If the row has a live window, catch any profiled seller in the latest few seconds.
        now = inum(row.get('ts'), now_ts())
        max_age = fnum(self.cfg.get('SWARM_EDGE_EXIT_WARNING_WINDOW_SEC'), 5.0)
        for e in reversed(row.get('live_wallet_events') or []):
            eside = str(e.get('side') or e.get('txType') or '').lower()
            ew = e.get('wallet') or e.get('traderPublicKey') or ''
            if eside == 'sell' and ew in self.swarm_exit_wallets and now - inum(e.get('ts'), 0) <= max_age:
                prof = dict(self.swarm_exit_wallets.get(ew) or {})
                prof['wallet'] = ew
                prof['source'] = 'window_wallet'
                return prof
        return {}



    def _follow_money_exit_hit(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """Return a local follow-money exit wallet selling in the current window."""
        if not self.cfg.get('FOLLOW_MONEY_EXIT_ENABLED', True):
            return {}
        exit_set = getattr(self, 'follow_money_exit_wallets', set()) | set(getattr(self, 'swarm_exit_wallets', {}).keys())
        if not exit_set:
            return {}
        now = inum(row.get('ts'), now_ts())
        max_age = fnum(self.cfg.get('FOLLOW_MONEY_EXIT_EVENT_MAX_AGE_SEC'), 8.0)
        candidates = []
        if str(row.get('last_side') or '').lower() == 'sell':
            candidates.append({'ts': now, 'side': 'sell', 'wallet': row.get('last_event_wallet') or row.get('last_wallet') or '', 'sol': row.get('last_event_sol')})
        candidates.extend(list(reversed(row.get('live_wallet_events') or [])))
        for e in candidates:
            side = str(e.get('side') or e.get('txType') or '').lower()
            wallet = str(e.get('wallet') or e.get('traderPublicKey') or e.get('user') or '').strip()
            if side == 'sell' and wallet in exit_set and now - inum(e.get('ts'), now) <= max_age:
                return {'wallet': wallet, 'event': e, 'source': 'follow_money_exit_wallet'}
        return {}

    def _creator_cluster_sell_hit(self, mint: str, row: Dict[str, Any]) -> Dict[str, Any]:
        """Return the first creator/controller cluster wallet selling this mint in the live row window."""
        if not self.cfg.get('CREATOR_CLUSTER_SELL_EXIT_ENABLED', True):
            return {}
        try:
            tracker = self.creator_tracker or get_global_creator_tracker()
            if not tracker:
                return {}
            cluster = tracker.get_creator_cluster(mint)
            if not cluster:
                return {}
            now = inum(row.get('ts'), now_ts())
            max_age = fnum(self.cfg.get('CREATOR_CLUSTER_SELL_EVENT_MAX_AGE_SEC'), 8.0)
            # Check last event first, then the rolling window.
            candidates = []
            if str(row.get('last_side') or '').lower() == 'sell':
                candidates.append({'ts': now, 'side': 'sell', 'wallet': row.get('last_event_wallet') or row.get('last_wallet') or '', 'sol': row.get('last_event_sol')})
            candidates.extend(list(reversed(row.get('live_wallet_events') or [])))
            for e in candidates:
                side = str(e.get('side') or e.get('txType') or '').lower()
                wallet = str(e.get('wallet') or e.get('traderPublicKey') or e.get('user') or '').strip()
                if side == 'sell' and wallet in cluster and now - inum(e.get('ts'), now) <= max_age:
                    return {'wallet': wallet, 'event': e, 'cluster_size': len(cluster)}
        except Exception as e:
            try:
                append_jsonl('creator_tracker_warnings.jsonl', {'ts': now_ts(), 'where': 'executor_creator_cluster_sell_hit', 'mint': mint, 'error': str(e)[:400]})
            except Exception:
                pass
        return {}

    async def update_and_maybe_exit_async(self, row: Dict[str, Any]) -> List[Dict[str, Any]]:
        return await self._update_and_maybe_exit(row, async_mode=True)

    def update_and_maybe_exit(self, row: Dict[str, Any]) -> List[Dict[str, Any]]:
        # sync paper path
        import asyncio
        coro = self._update_and_maybe_exit(row, async_mode=False)
        try:
            return asyncio.run(coro)
        except RuntimeError:
            # Should not happen in sync sim mode; fallback no exits rather than stop.
            return []

    async def _update_and_maybe_exit(self, row: Dict[str, Any], async_mode: bool) -> List[Dict[str, Any]]:
        mint = row.get('mint','')
        pos = self.positions.get(mint)
        if not pos: return []
        mc = fnum(row.get('mc') if row.get('mc') is not None else row.get('current_mc'), fnum(pos.get('last_mc'),0.0))
        if mc <= 0: return []
        now = inum(row.get('ts'), now_ts())
        if now < inum(pos.get('entry_ts'), now) - 1:
            append_jsonl('ignored_old_position_events.jsonl', {'ts': now_ts(), 'row_ts': now, 'entry_ts': inum(pos.get('entry_ts'), 0), 'mint': mint, 'reason': 'event_older_than_entry'})
            return []
        pos['last_seen_ts'] = now
        pos['last_mc'] = mc
        pos['high_mc'] = max(fnum(pos.get('high_mc'),mc), mc)
        self.positions[mint] = pos
        save_json(self.positions_file, self.positions)
        entry = fnum(pos.get('entry_mc'), mc)
        pnl_pct = (mc / entry - 1.0) if entry > 0 else 0.0
        age = now - inum(pos.get('entry_ts'), now)
        sell_pressure = fnum(row.get('sell_pressure'),0.0)
        ratio = fnum(row.get('total_sell_buy_ratio'),0.0)
        recent_buys = inum(row.get('recent_buys'),0)
        recent_sells = inum(row.get('recent_sells'),0)
        hive = self._hive_exit_state(mint, row)
        out=[]
        async def do_sell(pct, reason):
            if async_mode:
                return await self.sell_async(mint, pct, mc, reason, now)
            return self.sell(mint, pct, mc, reason, now)
        if self._pending_sell_recent(mint, now):
            return out
        # Universal hard max-hold comes before all profit-gated exits.
        # This prevents SIM/live from holding dead flat/red tokens for 5+ minutes.
        force_hold_res = await self._force_max_hold_exit_async(mint, pos, mc, age, now, do_sell)
        if force_hold_res:
            out.append(force_hold_res)
            return out
        follow_exit = self._follow_money_exit_hit(row)
        if follow_exit:
            append_jsonl('follow_money_exit_events.jsonl', {'ts': now, 'mint': mint, 'wallet': follow_exit.get('wallet'), 'our_pnl_pct': pnl_pct, 'hold_time_sec': age, 'setup': pos.get('setup'), 'sell_pressure': sell_pressure, 'ratio': ratio})
            _gross_sol, _cost_sol, net_eval_pct = self._estimated_net_pnl(fnum(pos.get('sol'), 0.0), pnl_pct, 1.0)
            if age >= fnum(self.cfg.get('FOLLOW_MONEY_EXIT_MIN_AGE_SEC'), 1.0) and (net_eval_pct >= fnum(self.cfg.get('FOLLOW_MONEY_EXIT_TAKE_NET_PCT'), 0.0) or sell_pressure >= fnum(self.cfg.get('FOLLOW_MONEY_EXIT_SELL_PRESSURE'), 0.45) or ratio >= fnum(self.cfg.get('FOLLOW_MONEY_EXIT_SELL_BUY_RATIO'), 0.85)):
                res = await do_sell(1.0, 'follow_money_exit_wallet_sold')
                if res:
                    out.append(res)
                return out

        creator_sell = self._creator_cluster_sell_hit(mint, row)
        if creator_sell:
            feed_trusted = True
            feed_p90_ms = 0.0
            try:
                mon = get_global_feed_latency_monitor()
                if mon is not None:
                    stats = mon.get_stats()
                    feed_p90_ms = fnum(stats.get('p90_ms'), 0.0)
                    feed_trusted = bool(mon.should_cluster_exit_be_trusted())
                    if not feed_trusted:
                        append_jsonl('creator_cluster_exits.jsonl', {'ts': now, 'warn': 'cluster_sell_exit_skipped_slow_feed', 'latency_p90_ms': feed_p90_ms, 'mint': mint})
            except Exception as e:
                append_jsonl('feed_latency_errors.jsonl', {'ts': now_ts(), 'where': 'executor_cluster_sell_latency_check', 'mint': mint, 'error': str(e)[:400]})
                feed_trusted = False
            append_jsonl('creator_cluster_exits.jsonl', {
                'ts': now,
                'mint': mint,
                'cluster_wallet_that_sold': creator_sell.get('wallet'),
                'our_pnl_pct': pnl_pct,
                'hold_time_sec': age,
                'cluster_size': creator_sell.get('cluster_size', 0),
                'setup': pos.get('setup'),
                'feed_trusted': feed_trusted,
                'latency_p90_ms': feed_p90_ms,
            })
            res = await do_sell(1.0, 'creator_cluster_sell_detected' + ('' if feed_trusted else '_low_confidence_slow_feed'))
            if res:
                out.append(res)
            return out
        swarm_exit_warn = self._swarm_exit_warning_hit(row)
        if swarm_exit_warn:
            append_jsonl('swarm_edge_exit_warning_events.jsonl', {'ts': now, 'mint': mint, 'setup': pos.get('setup'), 'wallet': swarm_exit_warn.get('wallet'), 'pnl_pct': pnl_pct, 'profile': swarm_exit_warn, 'sell_pressure': sell_pressure, 'ratio': ratio})
            # Exit-warning wallets are wallets the miner found often sell before drawdown.
            # Do not churn a fee-negative position on a tiny warning; but if green after fees,
            # or if tape pressure is severe, take the exit.
            _gross_sol, _cost_sol, net_eval_pct = self._estimated_net_pnl(fnum(pos.get('sol'), 0.0), pnl_pct, 1.0)
            if age >= fnum(self.cfg.get('SWARM_EDGE_EXIT_WARNING_MIN_AGE_SEC'), 2.0) and net_eval_pct >= fnum(self.cfg.get('SWARM_EDGE_EXIT_WARNING_TAKE_NET_PCT'), 0.025):
                res = await do_sell(1.0, 'swarm_edge_exit_warning_fee_safe')
                if res:
                    out.append(res)
                return out
            if age >= fnum(self.cfg.get('SWARM_EDGE_EXIT_WARNING_SEVERE_MIN_AGE_SEC'), 4.0) and (sell_pressure >= fnum(self.cfg.get('SWARM_EDGE_EXIT_WARNING_SEVERE_SELL_PRESSURE'), 0.62) or ratio >= fnum(self.cfg.get('SWARM_EDGE_EXIT_WARNING_SEVERE_SELL_BUY_RATIO'), 1.25)):
                res = await do_sell(1.0, 'swarm_edge_exit_warning_severe_pressure')
                if res:
                    out.append(res)
                return out
        hard_stop = fnum((self.cfg.get('SETUP_HARD_STOP_PCT') or {}).get(str(pos.get('setup')), self.cfg.get('HARD_STOP_PCT')),-0.22)
        hard_stop_min_age = fnum((self.cfg.get('SETUP_HARD_STOP_MIN_AGE_SEC') or {}).get(str(pos.get('setup')), self.cfg.get('HARD_STOP_MIN_AGE_SEC')), 10.0)
        trail_only = bool(self.cfg.get('TRAIL_ONLY_MODE', False))
        enable_post_tp1_stop = bool(self.cfg.get('ENABLE_POST_TP1_STOP', not trail_only)) and not bool(self.cfg.get('DISABLE_POST_TP1_STOP', False))
        enable_tp1 = bool(self.cfg.get('ENABLE_TP1', not trail_only)) and not bool(self.cfg.get('DISABLE_TP1', False))
        enable_tp2 = bool(self.cfg.get('ENABLE_TP2', not trail_only)) and not bool(self.cfg.get('DISABLE_TP2', False))
        enable_breakeven_lock = (bool(self.cfg.get('ENABLE_BREAKEVEN_LOCK', not trail_only)) or bool(self.cfg.get('BREAKEVEN_LOCK_ENABLED', False))) and not bool(self.cfg.get('DISABLE_BREAKEVEN_LOCK', False))
        trail_activation = fnum(self.cfg.get('TRAIL_ACTIVATION_PCT'), 0.08)
        trail_min_age = fnum(self.cfg.get('TRAIL_MIN_AGE_SEC'), 8.0)
        trail_pct = fnum(self.cfg.get('RUNNER_TRAIL_PCT'), 0.18)
        high = fnum(pos.get('high_mc'), mc)
        high_pnl_pct = (high / entry - 1.0) if entry > 0 else 0.0
        # v11.2.15: dynamic trail lets small runners breathe but protects big spikes harder.
        effective_trail_pct = trail_pct
        if high_pnl_pct >= fnum(self.cfg.get('TRAIL_TIGHTEN_AFTER_PCT_2'), 1.00):
            effective_trail_pct = min(effective_trail_pct, fnum(self.cfg.get('RUNNER_TRAIL_PCT_AFTER_100'), 0.10))
        elif high_pnl_pct >= fnum(self.cfg.get('TRAIL_TIGHTEN_AFTER_PCT_1'), 0.50):
            effective_trail_pct = min(effective_trail_pct, fnum(self.cfg.get('RUNNER_TRAIL_PCT_AFTER_50'), 0.12))
        if hive and self.cfg.get('QUEEN_PRESSURE_TRAIL_TIGHTEN_ENABLED', True) and (hive.get('queen_exit_now') or hive.get('queen_sells',0) or hive.get('queen_sell_sol',0.0) > 0):
            effective_trail_pct = min(effective_trail_pct, fnum(self.cfg.get('QUEEN_PRESSURE_TRAIL_PCT'), 0.08))
            append_jsonl('queen_worker_exit_pressure.jsonl', {'ts': now, 'mint': mint, 'event': 'queen_pressure_trail_tighten', 'setup': pos.get('setup'), 'pnl_pct': pnl_pct, 'high_pnl_pct': high_pnl_pct, 'trail_pct': effective_trail_pct, 'hive': hive})
        # v11.2.18: pre-exit warning — queen buying heavily, tighten trail before she sells
        elif hive and self.cfg.get('QUEEN_PRE_EXIT_TRAIL_TIGHTEN_ENABLED', True) and hive.get('queen_pre_exit_warning') and pos.get('trail_active'):
            effective_trail_pct = min(effective_trail_pct, fnum(self.cfg.get('QUEEN_PRE_EXIT_TRAIL_PCT'), 0.09))
            append_jsonl('queen_worker_exit_pressure.jsonl', {'ts': now, 'mint': mint, 'event': 'queen_pre_exit_trail_tighten', 'setup': pos.get('setup'), 'pnl_pct': pnl_pct, 'trail_pct': effective_trail_pct, 'hive': hive})
        elif hive and self.cfg.get('WORKER_FLOW_STALL_TIGHTEN_ENABLED', True) and pos.get('trail_active') and hive.get('worker_buys',0) <= hive.get('queen_sells',0):
            effective_trail_pct = min(effective_trail_pct, fnum(self.cfg.get('WORKER_FLOW_STALL_TRAIL_PCT'), 0.10))
        trail_active = bool(pos.get('trail_active')) or (high_pnl_pct >= trail_activation and age >= trail_min_age)
        if trail_active and not pos.get('trail_active'):
            pos['trail_active'] = True
            pos['trail_peak_mc'] = high
            pos['trail_activated_ts'] = now
            self.positions[mint] = pos
            save_json(self.positions_file, self.positions)
            append_jsonl('trail_only_events.jsonl', {'ts': now, 'mint': mint, 'event': 'trail_activated', 'setup': pos.get('setup'), 'entry_mc': entry, 'high_mc': high, 'high_pnl_pct': high_pnl_pct, 'trail_pct': effective_trail_pct})
        elif trail_active:
            # Keep an explicit peak field for dashboards/debug bundles.
            if high >= fnum(pos.get('trail_peak_mc'), 0.0):
                pos['trail_peak_mc'] = high
                self.positions[mint] = pos
                save_json(self.positions_file, self.positions)
        if hive and self.cfg.get('SELL_ON_QUEEN_EXIT_SHADOW', True) and self.cfg.get('QUEEN_EXIT_SHADOW_ENABLED', True) and hive.get('queen_exit_now') and age >= fnum(self.cfg.get('QUEEN_EXIT_MIN_POSITION_AGE_SEC'), 1.0):
            if str(pos.get('setup')) == 'queen_dump_recovery_scout' and self.cfg.get('QUEEN_DUMP_RECOVERY_RUNNER_GUARD_ENABLED', True):
                sold_sol_eval = fnum(pos.get('sol'), 0.0)
                _gross_sol, _cost_sol, net_eval_pct = self._estimated_net_pnl(sold_sol_eval, pnl_pct, 1.0)
                severe = (
                    sell_pressure >= fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_HARD_EXIT_SELL_PRESSURE'), 0.62) or
                    ratio >= fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_HARD_EXIT_SELL_BUY_RATIO'), 1.25) or
                    fnum(hive.get('sell_buy_sol_ratio'), 0.0) >= fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_HARD_HIVE_SELL_BUY_RATIO'), 0.65)
                )
                if severe and age >= fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_SEVERE_EXIT_MIN_AGE_SEC'), 3.0):
                    res=await do_sell(1.0, 'queen_dump_recovery_severe_pressure_exit')
                    if res:
                        out.append(res)
                        append_jsonl('queen_worker_exit_pressure.jsonl', {'ts': now, 'mint': mint, 'event': 'queen_dump_recovery_severe_pressure_exit', 'setup': pos.get('setup'), 'gross_pnl_pct': pnl_pct, 'net_eval_pct': net_eval_pct, 'sell_pressure': sell_pressure, 'ratio': ratio, 'hive': hive})
                    return out
                if net_eval_pct >= fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_TAKE_NET_PROFIT_PCT'), 0.025) and age >= fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_MIN_PROFIT_EXIT_AGE_SEC'), 4.0):
                    res=await do_sell(1.0, 'queen_dump_recovery_fee_safe_profit_exit')
                    if res:
                        out.append(res)
                        append_jsonl('queen_worker_exit_pressure.jsonl', {'ts': now, 'mint': mint, 'event': 'queen_dump_recovery_fee_safe_profit_exit', 'setup': pos.get('setup'), 'gross_pnl_pct': pnl_pct, 'net_eval_pct': net_eval_pct, 'hive': hive})
                    return out
                if age <= fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_IGNORE_QUEEN_EXIT_SEC'), 12.0):
                    append_jsonl('queen_worker_exit_pressure.jsonl', {'ts': now, 'mint': mint, 'event': 'queen_dump_recovery_ignored_early_queen_shadow', 'setup': pos.get('setup'), 'gross_pnl_pct': pnl_pct, 'net_eval_pct': net_eval_pct, 'age': age, 'sell_pressure': sell_pressure, 'ratio': ratio, 'hive': hive})
                    # Keep holding the refill. Fast-sniper/trail/hard-stop checks below will manage the exit.
                else:
                    # After the refill grace window, still avoid fee-negative churn unless pressure is severe.
                    append_jsonl('queen_worker_exit_pressure.jsonl', {'ts': now, 'mint': mint, 'event': 'queen_dump_recovery_shadow_seen_not_fee_safe', 'setup': pos.get('setup'), 'gross_pnl_pct': pnl_pct, 'net_eval_pct': net_eval_pct, 'age': age, 'sell_pressure': sell_pressure, 'ratio': ratio, 'hive': hive})
            else:
                res=await do_sell(1.0, 'queen_exit_shadow')
                if res:
                    out.append(res)
                    append_jsonl('queen_worker_exit_pressure.jsonl', {'ts': now, 'mint': mint, 'event': 'queen_exit_shadow', 'setup': pos.get('setup'), 'pnl_pct': pnl_pct, 'hive': hive})
                return out
        if hive and self.cfg.get('SELL_ON_WORKER_DUMP', True) and self.cfg.get('HIVE_FLIP_EXIT_ENABLED', True) and hive.get('hive_flip_exit') and age >= fnum(self.cfg.get('HIVE_FLIP_MIN_POSITION_AGE_SEC'), 1.0):
            if str(pos.get('setup')) in ('queen_dump_recovery_scout','queen_cycle_ride','swarm_edge_auto_ride') and age <= fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_IGNORE_HIVE_FLIP_SEC'), 15.0):
                append_jsonl('queen_worker_exit_pressure.jsonl', {'ts': now, 'mint': mint, 'event': 'ignored_early_hive_flip_for_queen_cycle', 'setup': pos.get('setup'), 'age': age, 'pnl_pct': pnl_pct, 'sell_pressure': sell_pressure, 'ratio': ratio, 'hive': hive})
            else:
                res=await do_sell(1.0, 'hive_flip_exit')
                if res:
                    out.append(res)
                    append_jsonl('queen_worker_exit_pressure.jsonl', {'ts': now, 'mint': mint, 'event': 'hive_flip_exit', 'setup': pos.get('setup'), 'pnl_pct': pnl_pct, 'hive': hive})
                return out
        # v11.2.20: fast sniper then runner. This takes profit quickly unless
        # current flow graduates the trade into a runner.
        sniper_res = await self._fast_sniper_exit_check(mint, pos, row, hive, pnl_pct, age, now, do_sell)
        if sniper_res:
            out.append(sniper_res)
            append_jsonl('hive_fast_sniper_events.jsonl', {'ts': now, 'mint': mint, 'setup': pos.get('setup'), 'pnl_pct': pnl_pct, 'age': age, 'reason': sniper_res.get('reason'), 'hive': hive, 'recent_buys': recent_buys, 'recent_sells': recent_sells, 'sell_pressure': sell_pressure, 'ratio': ratio})
            return out

        # v11.2.41 strict SIM edge: the deep-dive showed stale/dead flow was a major
        # loss source. Cut quickly when buy flow disappears instead of waiting for
        # long runner or hard-stop timers. This is gated by STALE_NO_BUY_EXIT_SEC.
        stale_no_buy_sec = fnum(self.cfg.get('STALE_NO_BUY_EXIT_SEC'), 0.0)
        last_buy_age = fnum(row.get('last_buy_age_sec'), fnum(row.get('seconds_since_last_buy'), 0.0))
        if stale_no_buy_sec > 0 and age >= fnum(self.cfg.get('STALE_NO_BUY_EXIT_MIN_AGE_SEC'), 3.0) and last_buy_age >= stale_no_buy_sec and recent_buys <= recent_sells:
            _gross_sol, _cost_sol, net_eval_pct = self._estimated_net_pnl(fnum(pos.get('sol'), 0.0), pnl_pct, 1.0)
            if net_eval_pct >= fnum(self.cfg.get('STALE_NO_BUY_EXIT_MIN_NET_PCT'), -0.08) or sell_pressure >= fnum(self.cfg.get('STALE_NO_BUY_EXIT_SELL_PRESSURE'), 0.45) or ratio >= fnum(self.cfg.get('STALE_NO_BUY_EXIT_SELL_BUY_RATIO'), 0.85):
                res = await do_sell(1.0, 'strict_edge_stale_no_buy_exit')
                if res:
                    out.append(res)
                    append_jsonl('strict_edge_exit_events.jsonl', {'ts': now, 'mint': mint, 'setup': pos.get('setup'), 'pnl_pct': pnl_pct, 'net_eval_pct': net_eval_pct, 'age': age, 'last_buy_age_sec': last_buy_age, 'recent_buys': recent_buys, 'recent_sells': recent_sells, 'sell_pressure': sell_pressure, 'ratio': ratio})
                return out

        if enable_post_tp1_stop and pos.get('tp1_done') and pnl_pct <= fnum(self.cfg.get('POST_TP1_STOP_BUFFER_PCT'), -0.03):
            res=await do_sell(1.0, 'post_tp1_protective_stop')
            if res: out.append(res)
            return out
        if (bool(self.cfg.get('ATH_DROP_EXIT_ENABLED', True)) and high > entry and
            high_pnl_pct >= fnum(self.cfg.get('ATH_DROP_MIN_HIGH_PNL_PCT'), 0.075) and
            mc <= high * (1.0 - fnum(self.cfg.get('ATH_DROP_EXIT_PCT'), 0.025))):
            res=await do_sell(1.0, 'ath_drop_runner_protect_exit')
            if res:
                out.append(res)
                append_jsonl('trail_only_events.jsonl', {'ts': now, 'mint': mint, 'event': 'ath_drop_exit', 'setup': pos.get('setup'), 'entry_mc': entry, 'high_mc': high, 'exit_mc': mc, 'pnl_pct': pnl_pct, 'drawdown_from_high_pct': (mc/high-1.0) if high>0 else 0.0, 'ath_drop_pct': fnum(self.cfg.get('ATH_DROP_EXIT_PCT'), 0.025)})
            return out
        if trail_active and high > entry and mc <= high * (1.0 - effective_trail_pct):
            res=await do_sell(1.0, 'trail_only_runner_exit' if trail_only else 'runner_trail_exit')
            if res:
                out.append(res)
                append_jsonl('trail_only_events.jsonl', {'ts': now, 'mint': mint, 'event': 'trail_exit', 'setup': pos.get('setup'), 'entry_mc': entry, 'high_mc': high, 'exit_mc': mc, 'pnl_pct': pnl_pct, 'drawdown_from_high_pct': (mc/high-1.0) if high>0 else 0.0, 'trail_pct': effective_trail_pct})
            return out
        # Early rug/yank stop: cuts obvious fresh collapses before the slower hard-stop age gate.
        if bool(self.cfg.get('EARLY_DUMP_STOP_ENABLED', True)) and age >= fnum(self.cfg.get('EARLY_DUMP_MIN_AGE_SEC'), 2.0) and pnl_pct <= fnum(self.cfg.get('EARLY_DUMP_STOP_PCT'), -0.16):
            if str(pos.get('setup')) in ('queen_dump_recovery_scout','queen_cycle_ride','swarm_edge_auto_ride') and age <= fnum(self.cfg.get('QUEEN_CYCLE_IGNORE_EARLY_DUMP_SEC'), 12.0):
                append_jsonl('queen_worker_exit_pressure.jsonl', {'ts': now, 'mint': mint, 'event': 'ignored_early_dump_for_queen_cycle', 'setup': pos.get('setup'), 'age': age, 'pnl_pct': pnl_pct, 'mc': mc, 'entry_mc': entry})
            else:
                res=await do_sell(1.0, 'early_dump_stop')
                if res: out.append(res)
                return out
        if pnl_pct <= hard_stop and age >= hard_stop_min_age:
            res=await do_sell(1.0, 'hard_stop')
            if res: out.append(res)
            return out
        elif pnl_pct <= hard_stop and age < hard_stop_min_age:
            append_jsonl('runner_guard_hard_stop_grace.jsonl', {'ts': now, 'mint': mint, 'age': age, 'pnl_pct': pnl_pct, 'hard_stop': hard_stop, 'min_age': hard_stop_min_age, 'setup': pos.get('setup')})
        if enable_tp1 and (not pos.get('tp1_done')) and pnl_pct >= fnum((self.cfg.get('SETUP_TP1_PCT') or {}).get(str(pos.get('setup')), self.cfg.get('TP1_PCT')),0.10):
            sell_pct = fnum((self.cfg.get('SETUP_TP1_SELL_PCT') or {}).get(str(pos.get('setup')), self.cfg.get('TP1_SELL_PCT')),0.65)
            res=await do_sell(sell_pct, 'tp1_fast_harvest')
            if res:
                out.append(res)
                if mint in self.positions:
                    self.positions[mint]['tp1_done'] = True; save_json(self.positions_file,self.positions)
            elif self.cfg.get('LIVE_SELL_ABORT_OTHER_EXITS_WHEN_PENDING', True) and mint in self.positions and self.positions[mint].get('pending_live_sell'):
                return out
        if mint not in self.positions: return out
        pos = self.positions[mint]
        if enable_tp2 and (not pos.get('tp2_done')) and pnl_pct >= fnum((self.cfg.get('SETUP_TP2_PCT') or {}).get(str(pos.get('setup')), self.cfg.get('TP2_PCT')),0.24):
            res=await do_sell(fnum(self.cfg.get('TP2_SELL_PCT'),0.25), 'tp2_runner_trim')
            if res:
                out.append(res)
                if mint in self.positions:
                    self.positions[mint]['tp2_done'] = True; save_json(self.positions_file,self.positions)
            elif self.cfg.get('LIVE_SELL_ABORT_OTHER_EXITS_WHEN_PENDING', True) and mint in self.positions and self.positions[mint].get('pending_live_sell'):
                return out
        if mint not in self.positions: return out
        pos = self.positions[mint]
        if enable_breakeven_lock and pos.get('tp1_done') and pnl_pct <= fnum(self.cfg.get('BREAKEVEN_LOCK_BUFFER_PCT'),0.015):
            res=await do_sell(1.0, 'breakeven_lock')
            if res: out.append(res)
            return out
        runner_max_hold = fnum(self.cfg.get('RUNNER_MAX_HOLD_SEC'), 180.0)
        if self.cfg.get('RUNNER_ENABLED', True) and age >= runner_max_hold:
            res=await do_sell(1.0, 'runner_max_hold_exit')
            if res: out.append(res)
            return out
        severe_stale = fnum(self.cfg.get('RUNNER_SEVERE_STALE_FLOW_SEC'), 30.0)
        if self.cfg.get('SELL_ON_STALE_FLOW', True) and age >= severe_stale and recent_buys <= recent_sells and pnl_pct > 0:
            res=await do_sell(1.0, 'runner_positive_stale_flow_exit')
            if res: out.append(res)
            return out

        dump_pressure_hit = sell_pressure >= fnum(self.cfg.get('WALLET_DUMP_EXIT_SELL_PRESSURE'),0.55)
        dump_ratio_hit = ratio >= fnum(self.cfg.get('WALLET_DUMP_EXIT_SELL_BUY_RATIO'),1.75)
        dump_severe_hit = (
            sell_pressure >= fnum(self.cfg.get('WALLET_DUMP_EXIT_SEVERE_SELL_PRESSURE'),0.75) or
            ratio >= fnum(self.cfg.get('WALLET_DUMP_EXIT_SEVERE_SELL_BUY_RATIO'),2.5)
        )
        dump_exit_age_ok = age >= fnum(self.cfg.get('WALLET_DUMP_EXIT_MIN_AGE_SEC'),0.0)
        dump_exit_pnl_ok = pnl_pct <= fnum(self.cfg.get('WALLET_DUMP_EXIT_MAX_PNL_PCT'),999.0)
        if (dump_pressure_hit or dump_ratio_hit) and dump_exit_age_ok and (dump_exit_pnl_ok or dump_severe_hit):
            # v11.2.27: the queen-refill lane was selling almost as fast as it
            # bought because normal dump pressure triggers fired before runners
            # had time to form. For queen/refill setups, only obey this exit on
            # true severe pressure or after the grace window; otherwise let the
            # runner/trail/hard-stop logic handle it.
            if str(pos.get('setup')) in ('queen_dump_recovery_scout','queen_cycle_ride','swarm_edge_auto_ride'):
                grace = fnum(self.cfg.get('QUEEN_DUMP_RECOVERY_IGNORE_QUEEN_EXIT_SEC'), 22.0)
                if (not dump_severe_hit) and age <= grace:
                    append_jsonl('queen_worker_exit_pressure.jsonl', {'ts': now, 'mint': mint, 'event': 'ignored_regular_dump_pressure_for_runner_grace', 'setup': pos.get('setup'), 'age': age, 'pnl_pct': pnl_pct, 'sell_pressure': sell_pressure, 'ratio': ratio, 'hive': hive})
                else:
                    res=await do_sell(1.0, 'wallet_dump_or_sell_pressure_exit')
                    if res: out.append(res)
                    return out
            else:
                res=await do_sell(1.0, 'wallet_dump_or_sell_pressure_exit')
                if res: out.append(res)
                return out
        no_buy_flow_max_pnl = fnum(self.cfg.get('TRAIL_ONLY_NO_BUY_FLOW_MAX_PNL'), 0.0) if trail_only else 999.0
        stale_max_pnl = fnum(self.cfg.get('TRAIL_ONLY_STALE_EXIT_MAX_PNL'), 0.0) if trail_only else 0.03
        if age >= fnum((self.cfg.get('SETUP_NO_BUY_FLOW_EXIT_SEC') or {}).get(str(pos.get('setup')), self.cfg.get('NO_BUY_FLOW_EXIT_SEC')),35.0) and recent_buys <= recent_sells and pnl_pct <= no_buy_flow_max_pnl:
            res=await do_sell(1.0, 'no_buy_flow_exit')
            if res: out.append(res)
            return out
        if age >= fnum((self.cfg.get('SETUP_STALE_EXIT_SEC') or {}).get(str(pos.get('setup')), self.cfg.get('STALE_EXIT_SEC')),55.0) and pnl_pct <= stale_max_pnl:
            res=await do_sell(1.0, 'stale_no_profit_exit')
            if res: out.append(res)
            return out
        return out
