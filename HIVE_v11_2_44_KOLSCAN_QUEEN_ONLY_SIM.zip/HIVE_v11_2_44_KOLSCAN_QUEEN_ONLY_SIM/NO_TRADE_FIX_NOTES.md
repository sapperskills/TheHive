# HIVE v11.2.40 No-Trade Unclog Patch

What was wrong:

1. `HIVE_BEHAVIOR_DIAGNOSTICS.jsonl` had 8,188 decisions and 0 approved trades.
2. The bot was detecting candidate lanes, but the AI gate was turning them back into `setup=none`.
3. `hive_ai_blocks.jsonl` showed these AI blocks:
   - `ai_setup_not_allowed_queen_hunter_swarm_quorum`: 528 times
   - `ai_setup_not_allowed_hive_state_scout`: 45 times
   - `ai_setup_not_allowed_follow_money_creation_snipe`: 30 times
   - `ai_setup_not_allowed_post_sell_recovery_scout`: 27 times
4. The token WSS subscription cap could also cause the bot to stop following fresh token trades after the first batch of mints.

Patch applied:

- AI can still score/rank trades, but it no longer blocks all entries by default.
- Added the real produced lane names to the allowed setup list.
- Relaxed swarm quorum and live tracked wallet thresholds for SIM/PAPER testing.
- Increased active token subscriptions and added token subscription rotation in `main.py`.
- Added explicit PumpDev/PumpPortal feed URLs while keeping RPC WSS separate from the market feed.

Run:

```bat
START_SIM.bat
```

For live, fill in `RPC_URL`, `WSS_URL`, and either `MAIN_PRIVATE_KEY_BASE58` or `MAIN_SECRET_JSON` in `config.json`, then run:

```bat
START_LIVE.bat
```
